import 'package:flutter/material.dart';

class CategoryFilterWidget extends StatefulWidget {
  final List<String> categories;
  final String selectedCategory;
  final Function(String) onCategorySelected;

  const CategoryFilterWidget({
    Key? key,
    required this.categories,
    required this.selectedCategory,
    required this.onCategorySelected,
  }) : super(key: key);

  @override
  _CategoryFilterWidgetState createState() => _CategoryFilterWidgetState();
}

class _CategoryFilterWidgetState extends State<CategoryFilterWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: Duration(milliseconds: 600),
      vsync: this,
    );
    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));
    _animationController.forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollToSelected() {
    int selectedIndex = widget.categories.indexOf(widget.selectedCategory);
    if (selectedIndex != -1 && _scrollController.hasClients) {
      double offset = (selectedIndex * 120.0) - (MediaQuery.of(context).size.width / 2);
      _scrollController.animateTo(
        offset.clamp(0.0, _scrollController.position.maxScrollExtent),
        duration: Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    }
  }

  Color _getCategoryColor(String category) {
    switch (category.toLowerCase()) {
      case 'toutes':
        return Colors.grey;
      case 'nom':
        return Colors.blue;
      case 'verbe':
        return Colors.green;
      case 'adjectif':
        return Colors.orange;
      case 'adverbe':
        return Colors.purple;
      case 'pronom':
        return Colors.red;
      case 'préposition':
        return Colors.brown;
      case 'conjonction':
        return Colors.blueGrey;
      case 'interjection':
        return Colors.pink;
      default:
        return Colors.teal;
    }
  }

  IconData _getCategoryIcon(String category) {
    switch (category.toLowerCase()) {
      case 'toutes':
        return Icons.all_inclusive;
      case 'nom':
        return Icons.label;
      case 'verbe':
        return Icons.play_arrow;
      case 'adjectif':
        return Icons.palette;
      case 'adverbe':
        return Icons.speed;
      case 'pronom':
        return Icons.person;
      case 'préposition':
        return Icons.arrow_forward;
      case 'conjonction':
        return Icons.link;
      case 'interjection':
        return Icons.mood;
      default:
        return Icons.category;
    }
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _fadeAnimation,
      child: Container(
        height: 80,
        margin: EdgeInsets.symmetric(vertical: 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  Icon(Icons.filter_list, color: Colors.grey[600], size: 18),
                  SizedBox(width: 8),
                  Text(
                    'Catégories',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: Colors.grey[700],
                    ),
                  ),
                  Spacer(),
                  if (widget.selectedCategory != 'Toutes')
                    GestureDetector(
                      onTap: () => widget.onCategorySelected('Toutes'),
                      child: Container(
                        padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.grey[200],
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.clear, size: 14, color: Colors.grey[600]),
                            SizedBox(width: 4),
                            Text(
                              'Effacer',
                              style: TextStyle(
                                fontSize: 12,
                                color: Colors.grey[600],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                ],
              ),
            ),
            SizedBox(height: 8),
            Expanded(
              child: ListView.builder(
                controller: _scrollController,
                scrollDirection: Axis.horizontal,
                padding: EdgeInsets.symmetric(horizontal: 12),
                itemCount: widget.categories.length,
                itemBuilder: (context, index) {
                  String category = widget.categories[index];
                  bool isSelected = widget.selectedCategory == category;
                  Color categoryColor = _getCategoryColor(category);
                  
                  return AnimatedContainer(
                    duration: Duration(milliseconds: 300),
                    margin: EdgeInsets.only(right: 8),
                    child: GestureDetector(
                      onTap: () {
                        widget.onCategorySelected(category);
                        Future.delayed(Duration(milliseconds: 100), _scrollToSelected);
                      },
                      child: Container(
                        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        decoration: BoxDecoration(
                          color: isSelected 
                              ? categoryColor.withOpacity(0.2) 
                              : Colors.grey[100],
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: isSelected 
                                ? categoryColor 
                                : Colors.grey.shade300,
                            width: isSelected ? 2 : 1,
                          ),
                          boxShadow: isSelected ? [
                            BoxShadow(
                              color: categoryColor.withOpacity(0.3),
                              blurRadius: 8,
                              offset: Offset(0, 2),
                            ),
                          ] : null,
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              _getCategoryIcon(category),
                              size: 18,
                              color: isSelected 
                                  ? categoryColor 
                                  : Colors.grey[600],
                            ),
                            SizedBox(width: 6),
                            Text(
                              category,
                              style: TextStyle(
                                color: isSelected 
                                    ? categoryColor 
                                    : Colors.grey[700],
                                fontWeight: isSelected 
                                    ? FontWeight.bold 
                                    : FontWeight.normal,
                                fontSize: 14,
                              ),
                            ),
                            if (isSelected) ...[
                              SizedBox(width: 4),
                              Container(
                                width: 6,
                                height: 6,
                                decoration: BoxDecoration(
                                  color: categoryColor,
                                  shape: BoxShape.circle,
                                ),
                              ),
                            ],
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Widget alternatif avec style chips
class CategoryChipsWidget extends StatelessWidget {
  final List<String> categories;
  final String selectedCategory;
  final Function(String) onCategorySelected;

  const CategoryChipsWidget({
    Key? key,
    required this.categories,
    required this.selectedCategory,
    required this.onCategorySelected,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 60,
      margin: EdgeInsets.symmetric(vertical: 8),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: EdgeInsets.symmetric(horizontal: 16),
        itemCount: categories.length,
        itemBuilder: (context, index) {
          String category = categories[index];
          bool isSelected = selectedCategory == category;
          
          return Container(
            margin: EdgeInsets.only(right: 8),
            child: FilterChip(
              label: Text(category),
              selected: isSelected,
              onSelected: (selected) => onCategorySelected(category),
              backgroundColor: Colors.grey[200],
              selectedColor: Colors.teal.withOpacity(0.2),
              checkmarkColor: Colors.teal,
              elevation: isSelected ? 4 : 1,
              pressElevation: 8,
              labelStyle: TextStyle(
                color: isSelected ? Colors.teal : Colors.grey[700],
                fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
              ),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
                side: BorderSide(
                  color: isSelected ? Colors.teal : Colors.grey.shade300,
                  width: isSelected ? 2 : 1,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}