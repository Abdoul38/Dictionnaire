import 'package:flutter/material.dart';
import '../models/historiquerecherche.dart';
import '../data/database_helper.dart';

class SearchHistoryWidget extends StatefulWidget {
  final Function(String) onSearchSelected;
  final Function() onClearHistory;
  final String currentQuery;
  final VoidCallback? onClose;

  const SearchHistoryWidget({
    Key? key,
    required this.onSearchSelected,
    required this.onClearHistory,
    this.currentQuery = '',
    this.onClose,
  }) : super(key: key);

  @override
  _SearchHistoryWidgetState createState() => _SearchHistoryWidgetState();
}

class _SearchHistoryWidgetState extends State<SearchHistoryWidget> {
  final CacheDatabaseHelper _cacheHelper = CacheDatabaseHelper();
  List<SearchHistoryItem> _history = [];
  List<SearchHistoryItem> _popularSearches = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  Future<void> _loadHistory() async {
    setState(() => _isLoading = true);
    
    try {
      final history = await _cacheHelper.getSearchHistory();
      final popular = await _cacheHelper.getPopularSearches();
      
      setState(() {
        _history = history;
        _popularSearches = popular;
        _isLoading = false;
      });
    } catch (e) {
      print('Erreur chargement historique: $e');
      setState(() => _isLoading = false);
    }
  }

  Future<void> _removeItem(int id) async {
    try {
      await _cacheHelper.removeFromSearchHistory(id);
      await _loadHistory();
    } catch (e) {
      print('Erreur suppression historique: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return Container(
        padding: EdgeInsets.all(16),
        child: Center(child: CircularProgressIndicator()),
      );
    }

    return Container(
      constraints: BoxConstraints(maxHeight: 400),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // En-tête
            Padding(
              padding: EdgeInsets.all(16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Historique des recherches',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.teal,
                    ),
                  ),
                  Row(
                    children: [
                      if (_history.isNotEmpty)
                        TextButton(
                          onPressed: () async {
                            await _cacheHelper.clearSearchHistory();
                            widget.onClearHistory();
                            await _loadHistory();
                          },
                          child: Text('Tout effacer'),
                        ),
                      if (widget.onClose != null)
                        IconButton(
                          icon: Icon(Icons.close),
                          onPressed: widget.onClose,
                        ),
                    ],
                  ),
                ],
              ),
            ),

            // Recherches populaires
            if (_popularSearches.isNotEmpty) ...[
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 16),
                child: Text(
                  'Recherches populaires',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Colors.grey[700],
                  ),
                ),
              ),
              SizedBox(height: 8),
              Container(
                height: 40,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  padding: EdgeInsets.symmetric(horizontal: 16),
                  itemCount: _popularSearches.length,
                  itemBuilder: (context, index) {
                    final item = _popularSearches[index];
                    return Container(
                      margin: EdgeInsets.only(right: 8),
                      child: ActionChip(
                        label: Text(
                          '${item.query} (${item.searchCount})',
                          style: TextStyle(fontSize: 12),
                        ),
                        onPressed: () => widget.onSearchSelected(item.query),
                        backgroundColor: Colors.blue.withOpacity(0.1),
                      ),
                    );
                  },
                ),
              ),
              SizedBox(height: 16),
            ],

            // Historique récent
            if (_history.isNotEmpty) ...[
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 16),
                child: Text(
                  'Récent',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Colors.grey[700],
                  ),
                ),
              ),
              SizedBox(height: 8),
              ListView.builder(
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                itemCount: _history.length,
                itemBuilder: (context, index) {
                  final item = _history[index];
                  return ListTile(
                    leading: Icon(Icons.history, color: Colors.grey),
                    title: Text(
                      item.query,
                      style: TextStyle(fontWeight: FontWeight.w500),
                    ),
                    subtitle: Text(
                      '${item.resultsCount} résultat${item.resultsCount > 1 ? 's' : ''} • ${item.timeAgo}',
                      style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (item.searchCount > 1)
                          Container(
                            padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: Colors.orange.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Text(
                              '${item.searchCount}x',
                              style: TextStyle(
                                fontSize: 10,
                                color: Colors.orange[800],
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        SizedBox(width: 8),
                        InkWell(
                          onTap: () => _removeItem(item.id),
                          child: Icon(Icons.close, color: Colors.grey[400], size: 18),
                        ),
                      ],
                    ),
                    onTap: () => widget.onSearchSelected(item.query),
                  );
                },
              ),
            ] else
              Padding(
                padding: EdgeInsets.all(32),
                child: Column(
                  children: [
                    Icon(Icons.search_off, size: 64, color: Colors.grey[400]),
                    SizedBox(height: 16),
                    Text(
                      'Aucun historique de recherche',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.grey[600],
                      ),
                    ),
                    Text(
                      'Vos recherches apparaîtront ici',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey[500],
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}