import 'dart:convert';
import 'dart:async';
import 'package:http/http.dart' as http;

class ApiService {
  static final ApiService _instance = ApiService._internal();
  factory ApiService() => _instance;
  static ApiService get instance => _instance;
  
  ApiService._internal();

  // Configuration de l'API - MODIFIER CETTE URL SELON VOTRE SERVEUR
  static const String PRODUCTION_URL = 'https://dictionnaire-zarma-api.onrender.com/api';

static const String _baseUrl = 'https://dictionnaire-zarma-api.onrender.com/api';
  final Map<String, String> _headers = {
    'Content-Type': 'application/json',
  };

  // MÉTHODES POUR LES QUIZ

  /// Récupérer tous les quizzes
  Future<List<dynamic>> getQuizzes() async {
    try {
      print('📄 Récupération des quizzes...');
      
      final response = await http.get(
        Uri.parse('$_baseUrl/quiz'),
        headers: _headers,
      ).timeout(Duration(seconds: 10));
      
      print('📊 Statut réponse quizzes: ${response.statusCode}');
      print('📦 Corps réponse: ${response.body}');
      
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        
        if (data is Map && data.containsKey('quizzes')) {
          final quizzes = data['quizzes'] as List;
          print('✅ ${quizzes.length} quizzes récupérés');
          return quizzes;
        } else if (data is List) {
          print('✅ ${data.length} quizzes récupérés (format direct)');
          return data;
        } else {
          throw ApiException('Format de réponse inattendu: ${data.runtimeType}');
        }
      } else {
        throw ApiException('Erreur HTTP ${response.statusCode}: ${response.body}');
      }
    } catch (e) {
      print('❌ Erreur récupération quizzes: $e');
      rethrow;
    }
  }

  /// Récupérer un quiz avec toutes ses questions et options
  Future<Map<String, dynamic>> getQuizWithDetails(String quizId) async {
    try {
      print('🔍 Récupération quiz détaillé: $quizId');
      
      final response = await http.get(
        Uri.parse('$_baseUrl/quiz/$quizId'),
        headers: _headers,
      ).timeout(Duration(seconds: 10));
      
      print('📊 Statut quiz détaillé: ${response.statusCode}');
      
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        print('📦 Données quiz reçues: ${data.keys.toList()}');
        
        // Traiter et normaliser les données
        return _processQuizData(data);
      } else {
        throw ApiException('Erreur HTTP ${response.statusCode}: ${response.body}');
      }
    } catch (e) {
      print('❌ Erreur récupération quiz détaillé $quizId: $e');
      rethrow;
    }
  }

  /// Traiter les données du quiz pour assurer la compatibilité
  Map<String, dynamic> _processQuizData(Map<String, dynamic> rawData) {
    final processedData = <String, dynamic>{
      'id': rawData['id']?.toString(),
      'title': rawData['title'] ?? 'Quiz sans titre',
      'description': rawData['description'] ?? 'Description non disponible',
      'category': rawData['category'] ?? 'general',
      'quiz_type': rawData['quizType'] ?? rawData['quiz_type'] ?? 'general',
      'difficulty': rawData['difficulty'] ?? 'Débutant',
      'time_limit': rawData['timeLimit'] ?? rawData['time_limit'] ?? 30,
      'primary_color': rawData['primaryColor'] ?? rawData['primary_color'],
      'questions': [],
    };

    // Traiter les questions
    final questions = rawData['questions'] as List? ?? [];
    for (int i = 0; i < questions.length; i++) {
      final question = questions[i] as Map<String, dynamic>;
      processedData['questions'].add(_processQuestionData(question, i));
    }

    print('✅ Quiz traité: ${processedData['title']} avec ${processedData['questions'].length} questions');
    return processedData;
  }

  /// Traiter une question individuelle
  Map<String, dynamic> _processQuestionData(Map<String, dynamic> rawQuestion, int index) {
    final options = <String>[];
    int correctIndex = 0;

    // Traiter les options selon différents formats possibles
    final rawOptions = rawQuestion['options'] as List? ?? [];
    
    for (int i = 0; i < rawOptions.length; i++) {
      final option = rawOptions[i];
      
      if (option is Map<String, dynamic>) {
        // Format avec objet option
        final optionText = option['optionText']?.toString() ?? 
                          option['option_text']?.toString() ?? 
                          option['text']?.toString() ?? 
                          'Option ${i + 1}';
        options.add(optionText);
        
        // Vérifier si c'est la bonne réponse
        if (option['isCorrect'] == true || option['is_correct'] == true) {
          correctIndex = i;
        }
      } else {
        // Format direct string
        options.add(option.toString());
      }
    }

    // Vérifier l'index correct depuis d'autres champs possibles
    if (rawQuestion['correct_answer'] != null) {
      final correctValue = rawQuestion['correct_answer'];
      if (correctValue is int) {
        correctIndex = correctValue;
      } else if (correctValue is String) {
        correctIndex = int.tryParse(correctValue) ?? 0;
      }
    }

    // S'assurer qu'on a au moins 2 options
    while (options.length < 2) {
      options.add('Option ${options.length + 1}');
    }

    return {
      'id': rawQuestion['id']?.toString(),
      'question_text': rawQuestion['questionText']?.toString() ?? 
                      rawQuestion['question_text']?.toString() ?? 
                      rawQuestion['question']?.toString() ?? 
                      'Question ${index + 1}',
      'explanation': rawQuestion['explanation']?.toString() ?? 
                    'Pas d\'explication disponible.',
      'audio_path': rawQuestion['audioPath']?.toString() ?? 
                   rawQuestion['audio_path']?.toString(),
      'options': options,
      'correct_answer': correctIndex,
      'order': rawQuestion['order'] ?? index,
    };
  }

  // MÉTHODES POUR LES EXERCICES

  /// Récupérer tous les exercices
  Future<List<dynamic>> getExercises() async {
    try {
      print('📄 Récupération des exercices...');
      
      final response = await http.get(
        Uri.parse('$_baseUrl/exercise'),
        headers: _headers,
      ).timeout(Duration(seconds: 10));
      
      print('📊 Statut réponse exercices: ${response.statusCode}');
      
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        
        if (data is Map && data.containsKey('exercises')) {
          final exercises = data['exercises'] as List;
          print('✅ ${exercises.length} exercices récupérés');
          return exercises;
        } else if (data is List) {
          print('✅ ${data.length} exercices récupérés (format direct)');
          return data;
        } else {
          throw ApiException('Format de réponse exercices inattendu');
        }
      } else {
        throw ApiException('Erreur HTTP ${response.statusCode}: ${response.body}');
      }
    } catch (e) {
      print('❌ Erreur récupération exercices: $e');
      rethrow;
    }
  }

  /// Récupérer un exercice avec tous ses items
  Future<Map<String, dynamic>> getExerciseWithDetails(String exerciseId) async {
    try {
      print('🔍 Récupération exercice détaillé: $exerciseId');
      
      final response = await http.get(
        Uri.parse('$_baseUrl/exercise/$exerciseId'),
        headers: _headers,
      ).timeout(Duration(seconds: 10));
      
      print('📊 Statut exercice détaillé: ${response.statusCode}');
      
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        print('📦 Données exercice reçues: ${data.keys.toList()}');
        
        // Traiter et normaliser les données
        return _processExerciseData(data);
      } else {
        throw ApiException('Erreur HTTP ${response.statusCode}: ${response.body}');
      }
    } catch (e) {
      print('❌ Erreur récupération exercice détaillé $exerciseId: $e');
      rethrow;
    }
  }

  /// Traiter les données de l'exercice
  Map<String, dynamic> _processExerciseData(Map<String, dynamic> rawData) {
    final processedData = <String, dynamic>{
      'id': rawData['id']?.toString(),
      'title': rawData['title'] ?? 'Exercice sans titre',
      'description': rawData['description'] ?? 'Description non disponible',
      'exercise_type': rawData['exerciseType'] ?? rawData['exercise_type'] ?? 'general',
      'primary_color': rawData['primaryColor'] ?? rawData['primary_color'],
      'items': [],
    };

    // Traiter les items
    final items = rawData['items'] as List? ?? [];
    for (int i = 0; i < items.length; i++) {
      final item = items[i] as Map<String, dynamic>;
      processedData['items'].add(_processItemData(item, i));
    }

    print('✅ Exercice traité: ${processedData['title']} avec ${processedData['items'].length} items');
    return processedData;
  }

  /// Traiter un item individuel
  Map<String, dynamic> _processItemData(Map<String, dynamic> rawItem, int index) {
    return {
      'id': rawItem['id']?.toString(),
      'zarma_text': rawItem['zarmaText']?.toString() ?? 
                   rawItem['zarma_text']?.toString() ?? 
                   'Texte zarma ${index + 1}',
      'french_text': rawItem['frenchText']?.toString() ?? 
                    rawItem['french_text']?.toString() ?? 
                    'Texte français ${index + 1}',
      'tip': rawItem['tip']?.toString() ?? 
             'Conseil ${index + 1}',
      'audio_path': rawItem['audioPath']?.toString() ?? 
                   rawItem['audio_path']?.toString(),
      'order': rawItem['order'] ?? index,
    };
  }

  // MÉTHODES UTILITAIRES

  /// Test de connexion à l'API
  Future<bool> testConnection() async {
    try {
      final response = await http.get(
        Uri.parse('$_baseUrl/health'),
        headers: _headers,
      ).timeout(Duration(seconds: 5));
      
      final isConnected = response.statusCode == 200;
      print('🔗 Test connexion: ${isConnected ? "OK" : "KO"} (${response.statusCode})');
      return isConnected;
    } catch (e) {
      print('❌ Test connexion échoué: $e');
      return false;
    }
  }

  /// Debug complet des endpoints
  Future<Map<String, dynamic>> debugAllEndpoints() async {
    final results = <String, dynamic>{};
    
    try {
      // Test endpoint quizzes
      final quizzesResponse = await http.get(
        Uri.parse('$_baseUrl/quiz'),
        headers: _headers,
      ).timeout(Duration(seconds: 5));
      
      results['quizzes'] = {
        'status': quizzesResponse.statusCode,
        'body_preview': quizzesResponse.body.length > 200 
          ? '${quizzesResponse.body.substring(0, 200)}...'
          : quizzesResponse.body,
      };
      
      // Test endpoint exercices
      final exercisesResponse = await http.get(
        Uri.parse('$_baseUrl/exercise'),
        headers: _headers,
      ).timeout(Duration(seconds: 5));
      
      results['exercises'] = {
        'status': exercisesResponse.statusCode,
        'body_preview': exercisesResponse.body.length > 200 
          ? '${exercisesResponse.body.substring(0, 200)}...'
          : exercisesResponse.body,
      };
      
    } catch (e) {
      results['error'] = e.toString();
    }
    
    return results;
  }

  /// Diagnostic complet pour Flutter
  Future<void> fullDiagnostic() async {
    print('=== DIAGNOSTIC COMPLET ===');
    
    // Test connectivité
    final connected = await testConnection();
    print('Connexion API: ${connected ? "OK" : "ÉCHEC"}');
    
    if (!connected) return;
    
    // Test quiz
    try {
      final quizzes = await getQuizzes();
      print('Quizzes récupérés: ${quizzes.length}');
      
      if (quizzes.isNotEmpty) {
        final firstQuizId = quizzes[0]['id'].toString();
        final quizDetails = await getQuizWithDetails(firstQuizId);
        print('Détails quiz $firstQuizId: ${quizDetails['questions']?.length ?? 0} questions');
      }
    } catch (e) {
      print('Erreur quiz: $e');
    }
    
    // Test exercices
    try {
      final exercises = await getExercises();
      print('Exercices récupérés: ${exercises.length}');
      
      if (exercises.isNotEmpty) {
        final firstExerciseId = exercises[0]['id'].toString();
        final exerciseDetails = await getExerciseWithDetails(firstExerciseId);
        print('Détails exercice $firstExerciseId: ${exerciseDetails['items']?.length ?? 0} items');
      }
    } catch (e) {
      print('Erreur exercice: $e');
    }
  }

  Future<void> initialize() async {}
}

/// Exception personnalisée pour les erreurs d'API
class ApiException implements Exception {
  final String message;
  
  ApiException(this.message);
  
  @override
  String toString() => 'ApiException: $message';
}