// lib/main.dart
import 'package:flutter/material.dart';
import 'screens/home_screen.dart'; // Utilisez la version avec sync

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Dictionnaire Zarma',
      theme: ThemeData(
        primarySwatch: Colors.teal,
      ),
      home: CentralizedHomeScreen(), // Utilisez SyncHomeScreen au lieu de HomeScreen
    );
  }
}