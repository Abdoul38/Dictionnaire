class UserNoteModel {
  final int? id;
  final int wordId;
  final String noteText;
  final List<String> tags;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  UserNoteModel({
    this.id,
    required this.wordId,
    required this.noteText,
    this.tags = const [],
    this.createdAt,
    this.updatedAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'word_id': wordId,
      'note_text': noteText,
      'tags': tags.join(','),
      'created_at': createdAt?.millisecondsSinceEpoch ?? DateTime.now().millisecondsSinceEpoch,
      'updated_at': updatedAt?.millisecondsSinceEpoch ?? DateTime.now().millisecondsSinceEpoch,
    };
  }

  static UserNoteModel fromMap(Map<String, dynamic> map) {
    return UserNoteModel(
      id: map['id'],
      wordId: map['word_id'],
      noteText: map['note_text'] ?? '',
      tags: _parseCommaSeparated(map['tags']),
      createdAt: map['created_at'] != null 
          ? DateTime.fromMillisecondsSinceEpoch(map['created_at']) 
          : null,
      updatedAt: map['updated_at'] != null 
          ? DateTime.fromMillisecondsSinceEpoch(map['updated_at']) 
          : null,
    );
  }

  static List<String> _parseCommaSeparated(String? value) {
    if (value == null || value.isEmpty) return [];
    return value.split(',').where((s) => s.trim().isNotEmpty).map((s) => s.trim()).toList();
  }

  // Méthodes utilitaires
  bool get hasContent => noteText.trim().isNotEmpty;
  bool get hasTags => tags.isNotEmpty;
  
  String get formattedCreatedDate {
    if (createdAt == null) return '';
    return '${createdAt!.day}/${createdAt!.month}/${createdAt!.year}';
  }
  
  String get formattedUpdatedDate {
    if (updatedAt == null) return '';
    return '${updatedAt!.day}/${updatedAt!.month}/${updatedAt!.year}';
  }

  int get wordCount => noteText.trim().split(RegExp(r'\s+')).length;
  
  bool containsTag(String tag) {
    return tags.any((t) => t.toLowerCase() == tag.toLowerCase());
  }
  
  UserNoteModel addTag(String tag) {
    if (!containsTag(tag)) {
      return copyWith(tags: [...tags, tag.trim()]);
    }
    return this;
  }
  
  UserNoteModel removeTag(String tag) {
    return copyWith(
      tags: tags.where((t) => t.toLowerCase() != tag.toLowerCase()).toList(),
    );
  }

  UserNoteModel copyWith({
    int? id,
    int? wordId,
    String? noteText,
    List<String>? tags,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return UserNoteModel(
      id: id ?? this.id,
      wordId: wordId ?? this.wordId,
      noteText: noteText ?? this.noteText,
      tags: tags ?? this.tags,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  @override
  String toString() {
    return 'UserNoteModel{id: $id, wordId: $wordId, wordCount: $wordCount, tags: $tags}';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is UserNoteModel &&
        other.id == id &&
        other.wordId == wordId &&
        other.noteText == noteText;
  }

  @override
  int get hashCode => id.hashCode ^ wordId.hashCode ^ noteText.hashCode;
}