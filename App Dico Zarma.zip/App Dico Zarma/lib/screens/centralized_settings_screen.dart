// lib/screens/centralized_settings_screen.dart
import 'package:flutter/material.dart';
import '../services/apiservice.dart';
import '../data/database_helper.dart';

class CentralizedSettingsScreen extends StatefulWidget {
  @override
  _CentralizedSettingsScreenState createState() => _CentralizedSettingsScreenState();
}

class _CentralizedSettingsScreenState extends State<CentralizedSettingsScreen> {
  final ApiService _apiService = ApiService.instance;
  final CacheDatabaseHelper _cacheHelper = CacheDatabaseHelper();
  
  bool _isLoading = false;
  String _currentUrl = '';
  Map<String, dynamic> _cacheInfo = {};
  Map<String, dynamic> _connectionDiagnosis = {};
  
  final TextEditingController _urlController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadCurrentSettings();
  }

  @override
  void dispose() {
    _urlController.dispose();
    super.dispose();
  }

  Future<void> _loadCurrentSettings() async {
    setState(() => _isLoading = true);
    
    try {
      _currentUrl = _apiService.apiUrl;
      _urlController.text = _currentUrl;
      
      _cacheInfo = await _cacheHelper.getCacheInfo();
      _connectionDiagnosis = await _apiService.diagnosisConnection();
      
      setState(() {});
    } catch (e) {
      _showErrorSnackBar('Erreur chargement paramètres: $e');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _updateApiUrl() async {
    final newUrl = _urlController.text.trim();
    if (newUrl.isEmpty) {
      _showErrorSnackBar('URL ne peut pas être vide');
      return;
    }

    setState(() => _isLoading = true);
    
    try {
      await _apiService.setApiUrl(newUrl);
      await _loadCurrentSettings();
      _showSuccessSnackBar('URL mise à jour avec succès');
    } catch (e) {
      _showErrorSnackBar('Erreur mise à jour URL: $e');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _testConnection() async {
    setState(() => _isLoading = true);
    
    try {
      final isConnected = await _apiService.testConnection();
      _connectionDiagnosis = await _apiService.diagnosisConnection();
      
      setState(() {});
      
      if (isConnected) {
        _showSuccessSnackBar('Connexion au serveur réussie');
      } else {
        _showErrorSnackBar('Impossible de se connecter au serveur');
      }
    } catch (e) {
      _showErrorSnackBar('Erreur test connexion: $e');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _clearCache() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Vider le cache'),
        content: Text('Êtes-vous sûr de vouloir vider tout le cache local ?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: Text('Annuler'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: Text('Vider', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (confirm == true) {
      setState(() => _isLoading = true);
      try {
        await _cacheHelper.clearCache();
        await _loadCurrentSettings();
        _showSuccessSnackBar('Cache vidé avec succès');
      } catch (e) {
        _showErrorSnackBar('Erreur vidage cache: $e');
      } finally {
        setState(() => _isLoading = false);
      }
    }
  }

  Future<void> _refreshCache() async {
    setState(() => _isLoading = true);
    try {
      await _cacheHelper.refreshCache();
      await _loadCurrentSettings();
      _showSuccessSnackBar('Cache actualisé avec succès');
    } catch (e) {
      _showErrorSnackBar('Erreur actualisation cache: $e');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _showErrorSnackBar(String message) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              Icon(Icons.error_outline, color: Colors.white),
              SizedBox(width: 8),
              Expanded(child: Text(message)),
            ],
          ),
          backgroundColor: Colors.red,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      );
    }
  }

  void _showSuccessSnackBar(String message) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              Icon(Icons.check_circle_outline, color: Colors.white),
              SizedBox(width: 8),
              Expanded(child: Text(message)),
            ],
          ),
          backgroundColor: Colors.green,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Paramètres'),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: _isLoading
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(color: Colors.teal),
                  SizedBox(height: 16),
                  Text('Chargement des paramètres...'),
                ],
              ),
            )
          : SingleChildScrollView(
              padding: EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildServerSection(),
                  SizedBox(height: 24),
                  _buildCacheSection(),
                  SizedBox(height: 24),
                  _buildDiagnosticSection(),
                ],
              ),
            ),
    );
  }

  Widget _buildServerSection() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.dns, color: Colors.blue),
                SizedBox(width: 8),
                Text(
                  'Configuration du serveur',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ],
            ),
            SizedBox(height: 16),
            TextField(
              controller: _urlController,
              decoration: InputDecoration(
                labelText: 'URL du serveur API',
                hintText: 'https://votre-serveur.com/api',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                suffixIcon: IconButton(
                  icon: Icon(Icons.save),
                  onPressed: _updateApiUrl,
                  tooltip: 'Sauvegarder l\'URL',
                ),
                prefixIcon: Icon(Icons.link),
              ),
              keyboardType: TextInputType.url,
            ),
            SizedBox(height: 8),
            Text(
              'URL actuelle: $_currentUrl',
              style: TextStyle(fontSize: 12, color: Colors.grey[600]),
            ),
            SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _isLoading ? null : _testConnection,
                    icon: Icon(Icons.network_check),
                    label: Text('Tester la connexion'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),
                ),
                SizedBox(width: 12),
                ElevatedButton.icon(
                  onPressed: _isLoading ? null : _updateApiUrl,
                  icon: Icon(Icons.save),
                  label: Text('Sauvegarder'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCacheSection() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.storage, color: Colors.teal),
                SizedBox(width: 8),
                Text(
                  'Gestion du cache',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ],
            ),
            SizedBox(height: 16),
            _buildInfoRow('Mots en cache', '${_cacheInfo['words_cached'] ?? 0}'),
            _buildInfoRow('Favoris en cache', '${_cacheInfo['favorites_cached'] ?? 0}'),
            _buildInfoRow('Statut connexion', _cacheInfo['is_online'] == true ? 'En ligne' : 'Hors ligne'),
            if (_cacheInfo['last_cache_update'] != null)
              _buildInfoRow(
                'Dernière mise à jour',
                _formatTimestamp(_cacheInfo['last_cache_update']),
              ),
            SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _isLoading ? null : _refreshCache,
                    icon: Icon(Icons.refresh),
                    label: Text('Actualiser'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.teal,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _isLoading ? null : _clearCache,
                    icon: Icon(Icons.delete_sweep),
                    label: Text('Vider'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.orange,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDiagnosticSection() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.bug_report, color: Colors.purple),
                SizedBox(width: 8),
                Text(
                  'Diagnostic de connexion',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                Spacer(),
                IconButton(
                  icon: Icon(Icons.refresh),
                  onPressed: _isLoading ? null : _testConnection,
                  tooltip: 'Actualiser le diagnostic',
                ),
              ],
            ),
            SizedBox(height: 16),
            if (_connectionDiagnosis.isNotEmpty) ...[
              _buildInfoRow('URL configurée', _connectionDiagnosis['configured_url']?.toString() ?? 'N/A'),
              _buildConnectionStatusRow('Test de connexion', _connectionDiagnosis['connection_test']),
              
              if (_connectionDiagnosis['words_endpoint'] != null)
                _buildEndpointStatusRow('API /words', _connectionDiagnosis['words_endpoint']),
              
              if (_connectionDiagnosis['categories_endpoint'] != null)
                _buildEndpointStatusRow('API /categories', _connectionDiagnosis['categories_endpoint']),
              
              if (_connectionDiagnosis['sample_word_count'] != null)
                _buildInfoRow('Mots disponibles', '${_connectionDiagnosis['sample_word_count']}'),
              
              if (_connectionDiagnosis['categories_count'] != null)
                _buildInfoRow('Catégories disponibles', '${_connectionDiagnosis['categories_count']}'),
              
              if (_connectionDiagnosis['error'] != null)
                _buildErrorDisplay(_connectionDiagnosis['error'].toString()),
              
              SizedBox(height: 12),
              Text(
                'Dernière vérification: ${_formatDiagnosticTime(_connectionDiagnosis['timestamp'])}',
                style: TextStyle(fontSize: 12, color: Colors.grey[600]),
              ),
            ] else
              Container(
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.grey.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    Icon(Icons.info_outline, color: Colors.grey),
                    SizedBox(width: 8),
                    Expanded(
                      child: Text('Aucun diagnostic disponible. Cliquez sur "Tester la connexion".'),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            flex: 2,
            child: Text(
              label,
              style: TextStyle(fontWeight: FontWeight.w500),
            ),
          ),
          Expanded(
            flex: 3,
            child: Text(
              value,
              style: TextStyle(color: Colors.grey[700]),
              textAlign: TextAlign.right,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildConnectionStatusRow(String label, dynamic status) {
    final isConnected = status == true;
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Expanded(
            flex: 2,
            child: Text(
              label,
              style: TextStyle(fontWeight: FontWeight.w500),
            ),
          ),
          Expanded(
            flex: 3,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Icon(
                  isConnected ? Icons.check_circle : Icons.error,
                  color: isConnected ? Colors.green : Colors.red,
                  size: 16,
                ),
                SizedBox(width: 4),
                Text(
                  isConnected ? 'Connecté' : 'Échec',
                  style: TextStyle(
                    color: isConnected ? Colors.green : Colors.red,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEndpointStatusRow(String label, dynamic status) {
    final isOk = status == 'OK';
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Expanded(
            flex: 2,
            child: Text(
              label,
              style: TextStyle(fontWeight: FontWeight.w500),
            ),
          ),
          Expanded(
            flex: 3,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Icon(
                  isOk ? Icons.check_circle : Icons.warning,
                  color: isOk ? Colors.green : Colors.orange,
                  size: 16,
                ),
                SizedBox(width: 4),
                Expanded(
                  child: Text(
                    status.toString(),
                    style: TextStyle(
                      color: isOk ? Colors.green : Colors.orange,
                      fontSize: 12,
                    ),
                    textAlign: TextAlign.right,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildErrorDisplay(String error) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 8),
      child: Container(
        padding: EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.red.withOpacity(0.1),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.red.withOpacity(0.3)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.error_outline, color: Colors.red, size: 16),
                SizedBox(width: 8),
                Text(
                  'Erreur détectée:',
                  style: TextStyle(fontWeight: FontWeight.bold, color: Colors.red),
                ),
              ],
            ),
            SizedBox(height: 8),
            Text(
              error,
              style: TextStyle(fontSize: 12, color: Colors.red[700]),
            ),
          ],
        ),
      ),
    );
  }

  String _formatTimestamp(dynamic timestamp) {
    if (timestamp == null) return 'Jamais';
    try {
      final date = timestamp is int 
          ? DateTime.fromMillisecondsSinceEpoch(timestamp * 1000)
          : DateTime.parse(timestamp.toString());
      return date.toLocal().toString().split('.')[0];
    } catch (e) {
      return 'Format invalide';
    }
  }

  String _formatDiagnosticTime(dynamic timestamp) {
    if (timestamp == null) return 'N/A';
    try {
      final date = DateTime.parse(timestamp.toString());
      return date.toLocal().toString().split('.')[0];
    } catch (e) {
      return timestamp.toString();
    }
  }
}