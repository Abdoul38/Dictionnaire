import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:zarma_dictionary/services/apiservice-quiz.dart';

// Modèles de données pour les exercices
class PracticeWord {
  final String zarma;
  final String french;
  final String tip;

  PracticeWord({
    required this.zarma,
    required this.french,
    required this.tip,
  });
}

class PracticeSentence {
  final String zarma;
  final String french;

  PracticeSentence({
    required this.zarma,
    required this.french,
  });
}

class PracticeExercisesScreen extends StatefulWidget {
  final String? exerciseId;
  final String exerciseType;

  const PracticeExercisesScreen({
    Key? key,
    this.exerciseId,
    required this.exerciseType,
  }) : super(key: key);

  @override
  _PracticeExercisesScreenState createState() => _PracticeExercisesScreenState();
}

class _PracticeExercisesScreenState extends State<PracticeExercisesScreen>
    with TickerProviderStateMixin {
  late FlutterTts _flutterTts;
  late AnimationController _slideController;
  late AnimationController _fadeController;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _fadeAnimation;
  
  List<PracticeWord> pronunciationWords = [];
  List<PracticeSentence> translationSentences = [];
  bool isLoading = true;
  bool _isPlaying = false;
  int _currentWordIndex = 0;
  bool _showTranslation = false;

  @override
  void initState() {
    super.initState();
    
    // VÉRIFICATION SILENCIEUSE
    if (widget.exerciseType.isEmpty) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Navigator.pop(context);
      });
      return;
    }
    
    _setupTTS();
    _setupAnimations();
    _loadExerciseData();
  }

  void _setupTTS() async {
    _flutterTts = FlutterTts();
    await _flutterTts.setLanguage("fr-FR");
    await _flutterTts.setSpeechRate(0.4);
    await _flutterTts.setVolume(1.0);
    await _flutterTts.setPitch(1.0);

    _flutterTts.setStartHandler(() {
      setState(() {
        _isPlaying = true;
      });
    });

    _flutterTts.setCompletionHandler(() {
      setState(() {
        _isPlaying = false;
      });
    });
  }

  void _setupAnimations() {
    _slideController = AnimationController(
      duration: Duration(milliseconds: 800),
      vsync: this,
    );
    _fadeController = AnimationController(
      duration: Duration(milliseconds: 600),
      vsync: this,
    );

    _slideAnimation = Tween<Offset>(
      begin: Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _slideController,
      curve: Curves.easeOutCubic,
    ));

    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeOut,
    ));

    _slideController.forward();
    _fadeController.forward();
  }

  // CHARGEMENT SILENCIEUX DES DONNÉES
  Future<void> _loadExerciseData() async {
    setState(() {
      isLoading = true;
    });
    
    try {
      if (widget.exerciseId != null && widget.exerciseId!.isNotEmpty) {
        final exerciseDetails = await ApiService.instance.getExerciseWithDetails(widget.exerciseId!);
        
        final success = await _processExerciseDetails(exerciseDetails);
        
        if (success) {
          setState(() {
            isLoading = false;
          });
          return;
        }
      }
      
      // ÉCHEC SILENCIEUX - Charger des données par défaut
      _loadDefaultData();
      
    } catch (e) {
      // ÉCHEC SILENCIEUX - Charger des données par défaut
      _loadDefaultData();
    }
  }

  // DONNÉES PAR DÉFAUT EN CAS D'ÉCHEC
  void _loadDefaultData() {
    if (widget.exerciseType.toLowerCase().contains('pronunciation') ||
        widget.exerciseType.toLowerCase().contains('prononciation')) {
      pronunciationWords = [
        PracticeWord(
          zarma: 'fooro',
          french: 'bonjour',
          tip: 'Prononcer "fo-ro" avec un o ouvert',
        ),
        PracticeWord(
          zarma: 'baani',
          french: 'merci',
          tip: 'Prononcer "ba-ni" avec accent sur le premier a',
        ),
        PracticeWord(
          zarma: 'salam',
          french: 'paix',
          tip: 'Prononcer "sa-lam" comme en arabe',
        ),
      ];
    } else {
      translationSentences = [
        PracticeSentence(
          zarma: 'Ni baani',
          french: 'Merci beaucoup',
        ),
        PracticeSentence(
          zarma: 'Nga tuuri?',
          french: 'Comment allez-vous?',
        ),
        PracticeSentence(
          zarma: 'Ay goo hane',
          french: 'Je vais bien',
        ),
      ];
    }
    
    setState(() {
      isLoading = false;
    });
  }

  Future<bool> _processExerciseDetails(Map<String, dynamic> exerciseDetails) async {
    try {
      final String exerciseType = exerciseDetails['exercise_type']?.toString().toLowerCase() ?? 
                                 widget.exerciseType.toLowerCase();
      
      // Extraire les items selon la structure
      List<dynamic> items = [];
      
      if (exerciseDetails.containsKey('items') && exerciseDetails['items'] is List) {
        items = exerciseDetails['items'];
      } 
      else if (exerciseDetails.containsKey('exercise_items') && exerciseDetails['exercise_items'] is List) {
        items = exerciseDetails['exercise_items'];
      }
      else {
        for (final key in exerciseDetails.keys) {
          if (exerciseDetails[key] is List && 
              !['created_at', 'updated_at', 'id', 'title', 'description'].contains(key)) {
            items = exerciseDetails[key];
            break;
          }
        }
      }
      
      if (items.isEmpty) {
        return false;
      }
      
      // Traiter les items selon le type d'exercice
      if (exerciseType.contains('pronunciation') || exerciseType.contains('prononciation')) {
        return await _processPronunciationItems(items);
      } 
      else if (exerciseType.contains('translation') || exerciseType.contains('traduction')) {
        return await _processTranslationItems(items);
      }
      else {
        return await _guessAndProcessItems(items, exerciseDetails);
      }
      
    } catch (e) {
      return false;
    }
  }

  Future<bool> _processPronunciationItems(List<dynamic> items) async {
    final List<PracticeWord> words = [];
    
    for (final item in items) {
      try {
        final itemMap = item is Map<String, dynamic> ? item : {};
        
        final word = PracticeWord(
          zarma: itemMap['zarma_text']?.toString() ?? 
                 itemMap['zarmaText']?.toString() ?? 
                 itemMap['zarma']?.toString() ?? 
                 itemMap['word']?.toString() ?? 
                 itemMap['text']?.toString() ??
                 'Mot zarma',
          french: itemMap['french_text']?.toString() ?? 
                  itemMap['frenchText']?.toString() ?? 
                  itemMap['french']?.toString() ?? 
                  itemMap['translation']?.toString() ?? 
                  itemMap['meaning']?.toString() ??
                  'Traduction française',
          tip: itemMap['tip']?.toString() ?? 
               itemMap['hint']?.toString() ?? 
               itemMap['pronunciation_tip']?.toString() ??
               'Conseil de prononciation',
        );
        
        words.add(word);
        
      } catch (e) {
        continue;
      }
    }
    
    if (words.isNotEmpty) {
      pronunciationWords = words;
      return true;
    }
    
    return false;
  }

  Future<bool> _processTranslationItems(List<dynamic> items) async {
    final List<PracticeSentence> sentences = [];
    
    for (final item in items) {
      try {
        final itemMap = item is Map<String, dynamic> ? item : {};
        
        final sentence = PracticeSentence(
          zarma: itemMap['zarma_text']?.toString() ?? 
                 itemMap['zarmaText']?.toString() ?? 
                 itemMap['zarma']?.toString() ?? 
                 itemMap['sentence_zarma']?.toString() ??
                 'Phrase zarma',
          french: itemMap['french_text']?.toString() ?? 
                  itemMap['frenchText']?.toString() ?? 
                  itemMap['french']?.toString() ?? 
                  itemMap['sentence_french']?.toString() ??
                  'Traduction française',
        );
        
        sentences.add(sentence);
        
      } catch (e) {
        continue;
      }
    }
    
    if (sentences.isNotEmpty) {
      translationSentences = sentences;
      return true;
    }
    
    return false;
  }

  Future<bool> _guessAndProcessItems(List<dynamic> items, Map<String, dynamic> exerciseDetails) async {
    if (items.isNotEmpty) {
      final firstItem = items[0];
      if (firstItem is Map) {
        if (firstItem.containsKey('zarma_text') && firstItem.containsKey('french_text')) {
          return await _processTranslationItems(items);
        }
        else if (firstItem.containsKey('tip') || firstItem.containsKey('pronunciation_tip')) {
          return await _processPronunciationItems(items);
        }
      }
    }
    
    final declaredType = exerciseDetails['exercise_type']?.toString().toLowerCase() ?? 
                        widget.exerciseType.toLowerCase();
    
    if (declaredType.contains('prononciation') || declaredType.contains('pronunciation')) {
      return await _processPronunciationItems(items);
    } else {
      return await _processTranslationItems(items);
    }
  }

  Future<void> _playAudio(String text) async {
    try {
      if (_isPlaying) {
        await _flutterTts.stop();
        return;
      }
      await _flutterTts.speak(text);
      HapticFeedback.lightImpact();
    } catch (e) {
      // Pas de message d'erreur TTS
    }
  }

  @override
  void dispose() {
    _slideController.dispose();
    _fadeController.dispose();
    _flutterTts.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              widget.exerciseType.toLowerCase().contains('pronunciation') ||
              widget.exerciseType.toLowerCase().contains('prononciation')
                ? Colors.purple.shade600 
                : Colors.orange.shade600,
              Colors.blue.shade600,
              Colors.teal.shade600,
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              Expanded(
                child: isLoading 
                  ? _buildLoadingView()
                  : SingleChildScrollView(
                      padding: EdgeInsets.all(20),
                      child: widget.exerciseType.toLowerCase().contains('pronunciation') ||
                             widget.exerciseType.toLowerCase().contains('prononciation')
                          ? _buildPronunciationExercise()
                          : _buildTranslationExercise(),
                    ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLoadingView() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircularProgressIndicator(color: Colors.white),
          SizedBox(height: 24),
          Text(
            'Chargement de l\'exercice...',
            style: TextStyle(
              fontSize: 18,
              color: Colors.white,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    String title = widget.exerciseType.toLowerCase().contains('pronunciation') ||
                  widget.exerciseType.toLowerCase().contains('prononciation')
        ? 'Exercice de prononciation'
        : 'Exercice de traduction';
    
    String description = widget.exerciseType.toLowerCase().contains('pronunciation') ||
                        widget.exerciseType.toLowerCase().contains('prononciation')
        ? 'Entraînez-vous à prononcer correctement'
        : 'Traduisez ces phrases courantes';

    return Container(
      padding: EdgeInsets.all(20),
      child: Column(
        children: [
          Row(
            children: [
              IconButton(
                onPressed: () => Navigator.pop(context),
                icon: Icon(Icons.arrow_back, color: Colors.white),
              ),
              Expanded(
                child: Text(
                  title,
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              SizedBox(width: 48),
            ],
          ),
          SizedBox(height: 8),
          Text(
            description,
            style: TextStyle(
              fontSize: 16,
              color: Colors.white.withOpacity(0.9),
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildPronunciationExercise() {
    if (pronunciationWords.isEmpty) {
      return _buildEmptyState('Aucun exercice de prononciation disponible');
    }
    
    return FadeTransition(
      opacity: _fadeAnimation,
      child: Column(
        children: [
          // Progress indicator
          Container(
            padding: EdgeInsets.all(16),
            margin: EdgeInsets.only(bottom: 20),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.1),
              borderRadius: BorderRadius.circular(15),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Mot ${_currentWordIndex + 1} sur ${pronunciationWords.length}',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Expanded(
                  child: Container(
                    margin: EdgeInsets.only(left: 16),
                    child: LinearProgressIndicator(
                      value: (_currentWordIndex + 1) / pronunciationWords.length,
                      backgroundColor: Colors.white.withOpacity(0.3),
                      valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Current word card
          SlideTransition(
            position: _slideAnimation,
            child: _buildPronunciationCard(pronunciationWords[_currentWordIndex]),
          ),

          SizedBox(height: 30),

          // Navigation buttons
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              ElevatedButton.icon(
                onPressed: _currentWordIndex > 0 ? _previousWord : null,
                icon: Icon(Icons.skip_previous),
                label: Text('Précédent'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  foregroundColor: Colors.purple,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
              ElevatedButton.icon(
                onPressed: _currentWordIndex < pronunciationWords.length - 1 
                    ? _nextWord 
                    : _finishExercise,
                icon: Icon(_currentWordIndex < pronunciationWords.length - 1 
                    ? Icons.skip_next 
                    : Icons.check),
                label: Text(_currentWordIndex < pronunciationWords.length - 1 
                    ? 'Suivant' 
                    : 'Terminer'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  foregroundColor: Colors.purple,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildPronunciationCard(PracticeWord word) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 20,
            offset: Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        children: [
          // Zarma word
          Container(
            padding: EdgeInsets.symmetric(vertical: 20),
            child: Text(
              word.zarma,
              style: TextStyle(
                fontSize: 36,
                fontWeight: FontWeight.bold,
                color: Colors.purple.shade800,
              ),
              textAlign: TextAlign.center,
            ),
          ),

          // French translation
          Container(
            padding: EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.purple.shade50,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              word.french,
              style: TextStyle(
                fontSize: 18,
                color: Colors.purple.shade700,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),

          SizedBox(height: 24),

          // Play button
          GestureDetector(
            onTap: () => _playAudio(word.zarma),
            child: Container(
              padding: EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: _isPlaying ? Colors.red.shade400 : Colors.purple.shade500,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: Colors.purple.withOpacity(0.3),
                    blurRadius: 15,
                    offset: Offset(0, 5),
                  ),
                ],
              ),
              child: _isPlaying
                  ? SizedBox(
                      width: 30,
                      height: 30,
                      child: CircularProgressIndicator(
                        strokeWidth: 3,
                        valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                      ),
                    )
                  : Icon(
                      Icons.play_arrow,
                      color: Colors.white,
                      size: 40,
                    ),
            ),
          ),

          SizedBox(height: 24),

          // Pronunciation tip
          Container(
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.orange.shade50,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.orange.shade200),
            ),
            child: Row(
              children: [
                Icon(Icons.lightbulb_outline, color: Colors.orange.shade700, size: 20),
                SizedBox(width: 8),
                Expanded(
                  child: Text(
                    word.tip,
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.orange.shade800,
                      fontStyle: FontStyle.italic,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTranslationExercise() {
    if (translationSentences.isEmpty) {
      return _buildEmptyState('Aucun exercice de traduction disponible');
    }

    return FadeTransition(
      opacity: _fadeAnimation,
      child: Column(
        children: translationSentences.map((sentence) => 
          SlideTransition(
            position: _slideAnimation,
            child: _buildTranslationCard(sentence),
          ),
        ).toList(),
      ),
    );
  }

  Widget _buildTranslationCard(PracticeSentence sentence) {
    return Container(
      width: double.infinity,
      margin: EdgeInsets.only(bottom: 20),
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 15,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              Container(
                padding: EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.orange.shade100,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(Icons.translate, color: Colors.orange.shade700, size: 20),
              ),
              SizedBox(width: 12),
              Text(
                'Traduisez :',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.orange.shade800,
                ),
              ),
              Spacer(),
              IconButton(
                onPressed: () => _playAudio(sentence.zarma),
                icon: Icon(Icons.volume_up, color: Colors.orange.shade700),
                tooltip: 'Écouter',
              ),
            ],
          ),

          SizedBox(height: 16),

          // Zarma sentence
          Container(
            width: double.infinity,
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.grey.shade50,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.grey.shade200),
            ),
            child: Text(
              sentence.zarma,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
                color: Colors.grey.shade800,
              ),
            ),
          ),

          SizedBox(height: 16),

          // Show/Hide translation button
          GestureDetector(
            onTap: () {
              setState(() {
                _showTranslation = !_showTranslation;
              });
              HapticFeedback.lightImpact();
            },
            child: Container(
              width: double.infinity,
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.orange.shade500,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                _showTranslation ? 'Masquer la réponse' : 'Voir la réponse',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w600,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ),

          // Translation (conditional)
          if (_showTranslation) ...[
            SizedBox(height: 12),
            Container(
              width: double.infinity,
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.green.shade50,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.green.shade200),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Traduction :',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      color: Colors.green.shade700,
                    ),
                  ),
                  SizedBox(height: 4),
                  Text(
                    sentence.french,
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      color: Colors.green.shade800,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildEmptyState(String message) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.school, size: 64, color: Colors.white.withOpacity(0.7)),
          SizedBox(height: 16),
          Text(
            'Exercice indisponible',
            style: TextStyle(
              fontSize: 18,
              color: Colors.white,
              fontWeight: FontWeight.w500,
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 24),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              ElevatedButton.icon(
                onPressed: () => Navigator.pop(context),
                icon: Icon(Icons.arrow_back),
                label: Text('Retour'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  foregroundColor: Colors.purple,
                  padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                ),
              ),
              ElevatedButton.icon(
                onPressed: () => _loadExerciseData(),
                icon: Icon(Icons.refresh),
                label: Text('Actualiser'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  foregroundColor: Colors.purple,
                  padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _previousWord() {
    if (_currentWordIndex > 0) {
      setState(() {
        _currentWordIndex--;
      });
      _slideController.reset();
      _slideController.forward();
    }
  }

  void _nextWord() {
    if (_currentWordIndex < pronunciationWords.length - 1) {
      setState(() {
        _currentWordIndex++;
      });
      _slideController.reset();
      _slideController.forward();
    }
  }

  void _finishExercise() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            Icon(Icons.celebration, color: Colors.orange, size: 28),
            SizedBox(width: 8),
            Text('Exercice terminé !'),
          ],
        ),
        content: Text(
          widget.exerciseType.toLowerCase().contains('pronunciation') ||
          widget.exerciseType.toLowerCase().contains('prononciation')
              ? 'Félicitations ! Vous avez terminé l\'exercice de prononciation.'
              : 'Félicitations ! Vous avez terminé l\'exercice de traduction.',
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: Text('Retour au menu'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              setState(() {
                _currentWordIndex = 0;
                _showTranslation = false;
              });
            },
            child: Text('Recommencer'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.orange,
              foregroundColor: Colors.white,
            ),
          ),
        ],
      ),
    );
  }}