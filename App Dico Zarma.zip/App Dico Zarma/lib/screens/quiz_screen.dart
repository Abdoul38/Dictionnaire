import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'dart:async';
import 'package:zarma_dictionary/services/apiservice-quiz.dart';

// Modèles de données pour les quiz
class QuizData {
  final String title;
  final String description;
  final String difficulty;
  final List<QuizQuestion> questions;

  QuizData({
    required this.title,
    required this.description,
    required this.difficulty,
    required this.questions,
  });
}

class QuizQuestion {
  final String question;
  final List<String> options;
  final int correct;
  final String explanation;
  final String? audio;

  QuizQuestion({
    required this.question,
    required this.options,
    required this.correct,
    required this.explanation,
    this.audio,
  });
}

class QuizScreen extends StatefulWidget {
  final Map<String, dynamic>? quizData;
  final String category;
  final String quizType;

  const QuizScreen.fromApi({
    Key? key,
    required this.quizData,
    this.category = '',
    this.quizType = '',
  }) : super(key: key);

  const QuizScreen({
    Key? key,
    required this.category,
    required this.quizType,
  }) : quizData = null, super(key: key);

  @override
  _QuizScreenState createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen>
    with TickerProviderStateMixin {
  QuizData? currentQuiz;
  int currentQuestion = 0;
  int? selectedAnswer;
  bool showResult = false;
  int score = 0;
  List<Map<String, dynamic>> userAnswers = [];
  int timeLeft = 30;
  bool timerActive = false;
  Timer? _timer;
  bool isLoading = true;

  // Animation controllers
  late AnimationController _slideController;
  late AnimationController _progressController;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _progressAnimation;

  // TTS
  FlutterTts? _flutterTts; // Make nullable to handle initialization failures

  @override
  void initState() {
    super.initState();
    _setupAnimations();
    _setupTTS();
    _loadQuizData();
  }

  void _setupAnimations() {
    _slideController = AnimationController(
      duration: Duration(milliseconds: 600),
      vsync: this,
    );
    _progressController = AnimationController(
      duration: Duration(milliseconds: 800),
      vsync: this,
    );

    _slideAnimation = Tween<Offset>(
      begin: Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _slideController,
      curve: Curves.easeOutCubic,
    ));

    _progressAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _progressController,
      curve: Curves.easeInOut,
    ));

    _slideController.forward();
  }

  void _setupTTS() async {
    try {
      _flutterTts = FlutterTts();
      await _flutterTts?.setLanguage("fr-FR");
      await _flutterTts?.setSpeechRate(0.5);
      await _flutterTts?.setVolume(1.0);
      await _flutterTts?.setPitch(1.0);
    } catch (e) {
      print('Erreur initialisation TTS: $e');
      _flutterTts = null; // Set to null if initialization fails
    }
  }

  void _loadQuizData() async {
    if (!mounted) return;
    
    setState(() {
      isLoading = true;
    });

    try {
      if (widget.quizData != null) {
        await _loadFromApi();
      } else {
        throw Exception('Aucune donnée de quiz fournie');
      }
      
      // Add null safety check
      if (currentQuiz != null && currentQuiz!.questions.isNotEmpty) {
        _updateProgress();
        _startTimer();
      } else {
        throw Exception('Quiz vide ou invalide');
      }
    } catch (e) {
      print('Erreur chargement quiz: $e');
      _showErrorAndLoadDefault('Erreur de chargement: $e');
    } finally {
      if (mounted) {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  Future<void> _loadFromApi() async {
    final apiData = widget.quizData;
    if (apiData == null) {
      throw Exception('Données API nulles');
    }
    
    print('Données quiz reçues: $apiData');
    
    try {
      final quizId = apiData['id']?.toString();
      Map<String, dynamic> quizDetails;
      
      if (quizId != null && quizId.isNotEmpty && quizId != 'default_1' && quizId != 'default_2') {
        print('Tentative de récupération des détails du quiz: $quizId');
        try {
          quizDetails = await ApiService.instance.getQuizWithDetails(quizId);
        } catch (e) {
          print('Erreur API, utilisation des données de base: $e');
          quizDetails = apiData;
        }
      } else {
        // Utiliser les données de base pour les quiz par défaut
        quizDetails = apiData;
      }
      
      // Créer les questions à partir des données
      final List<QuizQuestion> questions = [];
      final questionsData = quizDetails['questions'];
      
      if (questionsData is List) {
        for (int i = 0; i < questionsData.length; i++) {
          try {
            final questionData = questionsData[i];
            if (questionData is Map<String, dynamic>) {
              final question = _createQuestionFromData(questionData, i);
              questions.add(question);
              print('Question ajoutée: ${question.question}');
            }
          } catch (e) {
            print('Erreur traitement question $i: $e');
            continue;
          }
        }
      }
      
      if (questions.isEmpty) {
        throw Exception('Aucune question valide trouvée');
      }
      
      currentQuiz = QuizData(
        title: quizDetails['title']?.toString() ?? 'Quiz Sans Titre',
        description: quizDetails['description']?.toString() ?? 'Description non disponible',
        difficulty: quizDetails['difficulty']?.toString() ?? 'Débutant',
        questions: questions,
      );
      
      print('Quiz final: ${currentQuiz!.title} avec ${currentQuiz!.questions.length} questions');
      
    } catch (e) {
      print('Erreur lors du chargement détaillé: $e');
      rethrow;
    }
  }

  QuizQuestion _createQuestionFromData(Map<String, dynamic> questionMap, int index) {
    print('Traitement question $index: ${questionMap.keys.toList()}');
    
    // Extraction du texte de la question avec null safety
    final questionText = questionMap['question_text']?.toString() ?? 
                        questionMap['question']?.toString() ?? 
                        questionMap['text']?.toString() ?? 
                        'Question ${index + 1}';
    
    // Extraction des options avec null safety
    List<String> options = [];
    int correctIndex = 0;
    
    final rawOptions = questionMap['options'];
    if (rawOptions != null) {
      if (rawOptions is List) {
        for (int j = 0; j < rawOptions.length; j++) {
          final option = rawOptions[j];
          
          if (option is Map<String, dynamic>) {
            // Format avec objet option
            final optionText = option['option_text']?.toString() ?? 
                              option['optionText']?.toString() ?? 
                              option['text']?.toString() ?? 
                              'Option ${j + 1}';
            options.add(optionText);
            
            if (option['is_correct'] == true || option['isCorrect'] == true) {
              correctIndex = j;
            }
          } else if (option != null) {
            // Format direct string
            options.add(option.toString());
          }
        }
      }
    }
    
    // Vérifier l'index correct depuis d'autres champs possibles
    final correctAnswer = questionMap['correct_answer'];
    if (correctAnswer != null) {
      if (correctAnswer is int) {
        correctIndex = correctAnswer;
      } else if (correctAnswer is String) {
        correctIndex = int.tryParse(correctAnswer) ?? 0;
      }
    }
    
    // S'assurer qu'on a au moins 2 options
    if (options.length < 2) {
      options = ['Option A', 'Option B', 'Option C', 'Option D'];
    }
    
    // S'assurer que l'index correct est valide
    correctIndex = correctIndex.clamp(0, options.length - 1);
    
    return QuizQuestion(
      question: questionText,
      options: options,
      correct: correctIndex,
      explanation: questionMap['explanation']?.toString() ?? 
                  'Pas d\'explication disponible.',
      audio: questionMap['audio_path']?.toString(),
    );
  }

  void _showErrorAndLoadDefault(String error) {
    if (!mounted) return;
    
    setState(() {
      isLoading = false;
    });
    
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Row(
            children: [
              Icon(Icons.wifi_off, color: Colors.orange),
              SizedBox(width: 8),
              Text('Quiz non disponible'),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Les quiz ne peuvent pas être chargés actuellement.',
                style: TextStyle(
                  fontWeight: FontWeight.w500,
                  fontSize: 16,
                ),
              ),
              SizedBox(height: 16),
              Container(
                padding: EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.blue.shade50,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.blue.shade200),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Veuillez vérifier :',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.blue.shade800,
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      '• Votre connexion Internet',
                      style: TextStyle(color: Colors.blue.shade700),
                    ),
                    Text(
                      '• La disponibilité du serveur',
                      style: TextStyle(color: Colors.blue.shade700),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 12),
              Text(
                'Puis réessayez.',
                style: TextStyle(
                  fontWeight: FontWeight.w500,
                  color: Colors.grey[700],
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Fermer le dialog
                Navigator.of(context).pop(); // Retourner à l'écran précédent
              },
              child: Text('Retour'),
              style: TextButton.styleFrom(
                foregroundColor: Colors.grey[600],
              ),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop(); // Fermer le dialog
                _loadQuizData(); // Réessayer le chargement
              },
              child: Text('Réessayer'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.teal,
                foregroundColor: Colors.white,
              ),
            ),
          ],
        );
      },
    );
  }

  void _startTimer() {
    if (!mounted) return;
    
    timerActive = true;
    timeLeft = 30;
    _timer?.cancel(); // Cancel existing timer if any
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      if (mounted) {
        setState(() {
          if (timeLeft > 0) {
            timeLeft--;
          } else {
            _handleTimeUp();
          }
        });
      }
    });
  }

  void _handleTimeUp() {
    if (!mounted) return;
    
    timerActive = false;
    _timer?.cancel();
    if (selectedAnswer == null) {
      selectedAnswer = -1; // Aucune réponse
    }
    setState(() {
      showResult = true;
    });
  }

  void _updateProgress() {
    if (currentQuiz?.questions.isEmpty ?? true) {
      _progressController.animateTo(0.0);
      return;
    }
    
    double progress = (currentQuestion + 1) / currentQuiz!.questions.length;
    progress = progress.clamp(0.0, 1.0);
    
    _progressController.animateTo(progress);
  }

  void _handleAnswer(int answerIndex) {
    if (selectedAnswer != null || currentQuiz == null) return;

    _timer?.cancel();
    timerActive = false;

    setState(() {
      selectedAnswer = answerIndex;
    });

    final question = currentQuiz!.questions[currentQuestion];
    final isCorrect = answerIndex == question.correct;

    userAnswers.add({
      'question': currentQuestion,
      'answer': answerIndex,
      'correct': isCorrect,
    });

    if (isCorrect) {
      score++;
    }

    HapticFeedback.lightImpact();

    Future.delayed(Duration(milliseconds: 500), () {
      if (mounted) {
        setState(() {
          showResult = true;
        });
      }
    });
  }

  void _nextQuestion() {
    if (currentQuiz == null) return;
    
    if (currentQuestion < currentQuiz!.questions.length - 1) {
      setState(() {
        currentQuestion++;
        selectedAnswer = null;
        showResult = false;
        timeLeft = 30;
      });
      _slideController.reset();
      _slideController.forward();
      _updateProgress();
      _startTimer();
    } else {
      _finishQuiz();
    }
  }

  void _finishQuiz() {
    if (!mounted || currentQuiz == null) return;
    
    _timer?.cancel();
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => QuizResultsScreen(
          quiz: currentQuiz!,
          score: score,
          totalQuestions: currentQuiz!.questions.length,
          userAnswers: userAnswers,
        ),
      ),
    );
  }

  Future<void> _playAudio(String text) async {
    try {
      if (text.isEmpty || _flutterTts == null) return;
      
      await _flutterTts!.stop();
      await _flutterTts!.speak(text);
    } catch (e) {
      print('Erreur TTS: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Erreur lors de la lecture audio'),
            duration: Duration(seconds: 2),
            backgroundColor: Colors.orange,
          ),
        );
      }
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    _slideController.dispose();
    _progressController.dispose();
    _flutterTts?.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return Scaffold(
        body: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Colors.teal.shade600,
                Colors.blue.shade600,
                Colors.purple.shade600,
              ],
            ),
          ),
          child: SafeArea(
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(color: Colors.white),
                  SizedBox(height: 24),
                  Text(
                    'Chargement du quiz...',
                    style: TextStyle(
                      fontSize: 18,
                      color: Colors.white,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    }

    // Vérification de sécurité avec null safety
    if (currentQuiz?.questions.isEmpty ?? true) {
      return Scaffold(
        body: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Colors.teal.shade600,
                Colors.blue.shade600,
                Colors.purple.shade600,
              ],
            ),
          ),
          child: SafeArea(
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.error_outline, size: 64, color: Colors.white),
                  SizedBox(height: 16),
                  Text(
                    'Aucune question disponible',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: () => Navigator.pop(context),
                    child: Text('Retour'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: Colors.teal,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    }

    // Validation de l'index de la question courante
    if (currentQuestion < 0 || currentQuestion >= currentQuiz!.questions.length) {
      currentQuestion = 0;
    }

    final question = currentQuiz!.questions[currentQuestion];

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Colors.teal.shade600,
              Colors.blue.shade600,
              Colors.purple.shade600,
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              _buildProgressBar(),
              Expanded(
                child: SingleChildScrollView(
                  padding: EdgeInsets.all(20),
                  child: SlideTransition(
                    position: _slideAnimation,
                    child: _buildQuestionCard(question),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: EdgeInsets.all(20),
      child: Row(
        children: [
          IconButton(
            onPressed: () => Navigator.pop(context),
            icon: Icon(Icons.arrow_back, color: Colors.white),
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  currentQuiz?.title ?? 'Quiz',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                Text(
                  'Question ${currentQuestion + 1} sur ${currentQuiz?.questions.length ?? 0}',
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.white.withOpacity(0.8),
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              color: timeLeft <= 10 ? Colors.red : Colors.blue,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.timer, color: Colors.white, size: 18),
                SizedBox(width: 4),
                Text(
                  '${timeLeft}s',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProgressBar() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 20),
      child: AnimatedBuilder(
        animation: _progressAnimation,
        builder: (context, child) {
          return LinearProgressIndicator(
            value: _progressAnimation.value,
            backgroundColor: Colors.white.withOpacity(0.3),
            valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
            minHeight: 4,
          );
        },
      ),
    );
  }

  Widget _buildQuestionCard(QuizQuestion question) {
    return Container(
      margin: EdgeInsets.only(top: 20),
      padding: EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 20,
            offset: Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Question
          Text(
            question.question,
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.grey[800],
              height: 1.4,
            ),
          ),
          
          SizedBox(height: 16),

          // Bouton audio si disponible
          if (question.audio != null && question.audio!.isNotEmpty)
            Container(
              margin: EdgeInsets.only(bottom: 20),
              child: ElevatedButton.icon(
                onPressed: () => _playAudio(question.audio!),
                icon: Icon(Icons.volume_up, size: 18),
                label: Text('Écouter la prononciation'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.purple,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ),

          // Options
          ...question.options.asMap().entries.map((entry) {
            int index = entry.key;
            String option = entry.value;
            return _buildOptionButton(index, option, question);
          }).toList(),

          // Explication si résultat affiché
          if (showResult) ...[
            SizedBox(height: 20),
            Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.blue.shade50,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.blue.shade200),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Explication :',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.blue.shade900,
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    question.explanation,
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.blue.shade800,
                      height: 1.4,
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 20),
            Center(
              child: ElevatedButton(
                onPressed: _nextQuestion,
                child: Text(
                  currentQuestion < (currentQuiz?.questions.length ?? 1) - 1
                      ? 'Question suivante'
                      : 'Voir les résultats',
                  style: TextStyle(fontSize: 16),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.teal,
                  foregroundColor: Colors.white,
                  padding: EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildOptionButton(int index, String option, QuizQuestion question) {
    bool isSelected = selectedAnswer == index;
    bool isCorrect = index == question.correct;
    bool showCorrect = showResult && isCorrect;
    bool showIncorrect = showResult && isSelected && !isCorrect;

    Color backgroundColor = Colors.grey.shade50;
    Color borderColor = Colors.grey.shade300;
    Color textColor = Colors.grey.shade800;
    Widget? trailing;

    if (showCorrect) {
      backgroundColor = Colors.green.shade50;
      borderColor = Colors.green.shade300;
      textColor = Colors.green.shade800;
      trailing = Icon(Icons.check_circle, color: Colors.green);
    } else if (showIncorrect) {
      backgroundColor = Colors.red.shade50;
      borderColor = Colors.red.shade300;
      textColor = Colors.red.shade800;
      trailing = Icon(Icons.cancel, color: Colors.red);
    } else if (selectedAnswer != null) {
      backgroundColor = Colors.grey.shade100;
      borderColor = Colors.grey.shade400;
      textColor = Colors.grey.shade600;
    }

    return Container(
      margin: EdgeInsets.only(bottom: 12),
      child: InkWell(
        onTap: selectedAnswer == null ? () => _handleAnswer(index) : null,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: backgroundColor,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: borderColor, width: 2),
          ),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  option,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                    color: textColor,
                  ),
                ),
              ),
              if (trailing != null) trailing,
            ],
          ),
        ),
      ),
    );
  }
}
class QuizResultsScreen extends StatefulWidget {
  final QuizData quiz;
  final int score;
  final int totalQuestions;
  final List<Map<String, dynamic>> userAnswers;

  const QuizResultsScreen({
    Key? key,
    required this.quiz,
    required this.score,
    required this.totalQuestions,
    required this.userAnswers,
  }) : super(key: key);

  @override
  _QuizResultsScreenState createState() => _QuizResultsScreenState();
}

class _QuizResultsScreenState extends State<QuizResultsScreen>
    with TickerProviderStateMixin {
  late AnimationController _scaleController;
  late AnimationController _slideController;
  late Animation<double> _scaleAnimation;
  late Animation<Offset> _slideAnimation;

  @override
  void initState() {
    super.initState();
    _setupAnimations();
  }

  void _setupAnimations() {
    _scaleController = AnimationController(
      duration: Duration(milliseconds: 800),
      vsync: this,
    );
    _slideController = AnimationController(
      duration: Duration(milliseconds: 600),
      vsync: this,
    );

    _scaleAnimation = Tween<double>(
      begin: 0.5,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _scaleController,
      curve: Curves.elasticOut,
    ));

    _slideAnimation = Tween<Offset>(
      begin: Offset(0, 0.5),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _slideController,
      curve: Curves.easeOutCubic,
    ));

    _scaleController.forward();
    _slideController.forward();
  }

  @override
  void dispose() {
    _scaleController.dispose();
    _slideController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    int percentage = 0;
    if (widget.totalQuestions > 0 && widget.score >= 0) {
      percentage = ((widget.score / widget.totalQuestions) * 100).round();
    }
    percentage = percentage.clamp(0, 100);
    
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Colors.teal.shade600,
              Colors.blue.shade600,
              Colors.purple.shade600,
            ],
          ),
        ),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: EdgeInsets.all(20),
              child: Column(
                children: [
                  ScaleTransition(
                    scale: _scaleAnimation,
                    child: _buildTrophyIcon(percentage),
                  ),
                  SizedBox(height: 30),
                  SlideTransition(
                    position: _slideAnimation,
                    child: _buildResultsCard(percentage),
                  ),
                  SizedBox(height: 30),
                  SlideTransition(
                    position: _slideAnimation,
                    child: _buildActionButtons(),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTrophyIcon(int percentage) {
    IconData icon;
    Color color;
    
    if (percentage >= 80) {
      icon = Icons.emoji_events;
      color = Colors.amber;
    } else if (percentage >= 60) {
      icon = Icons.stars;
      color = Colors.orange;
    } else {
      icon = Icons.psychology;
      color = Colors.blue;
    }

    return Container(
      padding: EdgeInsets.all(30),
      decoration: BoxDecoration(
        color: Colors.white,
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 20,
            offset: Offset(0, 10),
          ),
        ],
      ),
      child: Icon(
        icon,
        size: 80,
        color: color,
      ),
    );
  }

  Widget _buildResultsCard(int percentage) {
    return Container(
      padding: EdgeInsets.all(30),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 20,
            offset: Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        children: [
          Text(
            'Quiz terminé !',
            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.bold,
              color: Colors.grey[800],
            ),
          ),
          SizedBox(height: 10),
          Text(
            widget.quiz.title,
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey[600],
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 30),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _buildStatColumn('Score', '${widget.score}/${widget.totalQuestions}', Colors.teal),
              _buildStatColumn('Pourcentage', '$percentage%', Colors.blue),
              _buildStatColumn('Temps', 'Terminé', Colors.purple),
            ],
          ),
          SizedBox(height: 20),
          Text(
            _getEncouragementMessage(percentage),
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w500,
              color: Colors.grey[700],
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildStatColumn(String label, String value, Color color) {
    return Column(
      children: [
        Container(
          padding: EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Text(
            value,
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
        ),
        SizedBox(height: 8),
        Text(
          label,
          style: TextStyle(
            fontSize: 14,
            color: Colors.grey[600],
          ),
        ),
      ],
    );
  }

  Widget _buildActionButtons() {
    return Column(
      children: [
        Row(
          children: [
            Expanded(
              child: ElevatedButton(
                onPressed: () {
                  Navigator.popUntil(context, (route) => route.isFirst);
                },
                child: Text('Retour au menu', style: TextStyle(fontSize: 16)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.grey[600],
                  foregroundColor: Colors.white,
                  padding: EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ),
            SizedBox(width: 16),
            Expanded(
              child: ElevatedButton(
                onPressed: () => Navigator.pop(context),
                child: Text('Nouveau quiz', style: TextStyle(fontSize: 16)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.teal,
                  foregroundColor: Colors.white,
                  padding: EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ),
          ],
        ),
        SizedBox(height: 16),
        ElevatedButton.icon(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => QuizReviewScreen(
                  quiz: widget.quiz,
                  userAnswers: widget.userAnswers,
                ),
              ),
            );
          },
          icon: Icon(Icons.preview),
          label: Text('Revoir les réponses'),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.blue,
            foregroundColor: Colors.white,
            padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
        ),
      ],
    );
  }

  String _getEncouragementMessage(int percentage) {
    if (percentage >= 80) {
      return "Excellent travail ! Vous maîtrisez bien le sujet.";
    } else if (percentage >= 60) {
      return "Bon travail ! Continuez à vous entraîner.";
    } else {
      return "Continuez vos efforts ! La pratique mène à la perfection.";
    }
  }
}

class QuizReviewScreen extends StatelessWidget {
  final QuizData quiz;
  final List<Map<String, dynamic>> userAnswers;

  const QuizReviewScreen({
    Key? key,
    required this.quiz,
    required this.userAnswers,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Révision - ${quiz.title}'),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: ListView.builder(
        padding: EdgeInsets.all(16),
        itemCount: quiz.questions.length,
        itemBuilder: (context, index) {
          final question = quiz.questions[index];
          final userAnswer = userAnswers[index];
          final isCorrect = userAnswer['correct'] as bool;
          
          return Card(
            margin: EdgeInsets.only(bottom: 16),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: isCorrect ? Colors.green : Colors.red,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Icon(
                          isCorrect ? Icons.check : Icons.close,
                          color: Colors.white,
                          size: 20,
                        ),
                      ),
                      SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          'Question ${index + 1}',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 16),
                  Text(
                    question.question,
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  SizedBox(height: 12),
                  ...question.options.asMap().entries.map((entry) {
                    final optionIndex = entry.key;
                    final option = entry.value;
                    final isUserAnswer = userAnswer['answer'] == optionIndex;
                    final isCorrectAnswer = optionIndex == question.correct;
                    
                    Color backgroundColor = Colors.grey.shade50;
                    Color borderColor = Colors.grey.shade300;
                    Widget? trailing;
                    
                    if (isCorrectAnswer) {
                      backgroundColor = Colors.green.shade50;
                      borderColor = Colors.green.shade300;
                      trailing = Icon(Icons.check_circle, color: Colors.green);
                    } else if (isUserAnswer && !isCorrectAnswer) {
                      backgroundColor = Colors.red.shade50;
                      borderColor = Colors.red.shade300;
                      trailing = Icon(Icons.cancel, color: Colors.red);
                    }
                    
                    return Container(
                      margin: EdgeInsets.only(bottom: 8),
                      padding: EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: backgroundColor,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: borderColor),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(
                              option,
                              style: TextStyle(fontSize: 14),
                            ),
                          ),
                          if (trailing != null) trailing,
                        ],
                      ),
                    );
                  }).toList(),
                  SizedBox(height: 12),
                  Container(
                    padding: EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.blue.shade50,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Explication :',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.blue.shade900,
                          ),
                        ),
                        SizedBox(height: 4),
                        Text(
                          question.explanation,
                          style: TextStyle(
                            color: Colors.blue.shade800,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}