// lib/services/notification_service.dart
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:math';
import 'dart:convert';
import '../models/word_model.dart';
import '../data/database_helper.dart';

 // Types de notifications
  enum NotificationType {
    dailyWord,
    studyReminder,
    syncAlert,
    quizChallenge,
    favoriteUpdate,
  }
  

class NotificationService {
  static const String channelId = 'zarma_dictionary_channel';
  static const String channelName = 'Dictionnaire Zarma';
  static const String channelDescription = 'Notifications pour l\'apprentissage du Zarma';
  
  static NotificationService? _instance;
  static NotificationService get instance => _instance ??= NotificationService._();
  
  final FlutterLocalNotificationsPlugin _notifications = FlutterLocalNotificationsPlugin();
  final CacheDatabaseHelper _dbHelper = CacheDatabaseHelper();
  
  NotificationService._();
  
 
  // Configuration des notifications
  final Map<NotificationType, NotificationConfig> _configs = {
    NotificationType.dailyWord: NotificationConfig(
      title: 'Mot du jour',
      defaultBody: 'Découvrez un nouveau mot en Zarma aujourd\'hui!',
      icon: 'ic_book',
      priority: Priority.defaultPriority,
    ),
    NotificationType.studyReminder: NotificationConfig(
      title: 'Temps d\'étudier',
      defaultBody: 'Il est temps de réviser vos mots favoris!',
      icon: 'ic_study',
      priority: Priority.defaultPriority,
    ),
    NotificationType.syncAlert: NotificationConfig(
      title: 'Synchronisation disponible',
      defaultBody: 'Nouvelles données disponibles, synchronisez maintenant!',
      icon: 'ic_sync',
      priority: Priority.high,
    ),
    NotificationType.quizChallenge: NotificationConfig(
      title: 'Défi Quiz',
      defaultBody: 'Testez vos connaissances avec un quiz!',
      icon: 'ic_quiz',
      priority: Priority.defaultPriority,
    ),
  };

  Future<void> initialize() async {
    print('🔔 Initialisation du service de notifications...');
    
    // Configuration Android
    const AndroidInitializationSettings androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    
    // Configuration iOS
    const DarwinInitializationSettings iosSettings = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );
    
    const InitializationSettings initSettings = InitializationSettings(
      android: androidSettings,
      iOS: iosSettings,
    );
    
    // Initialiser le plugin
    await _notifications.initialize(
      initSettings,
      onDidReceiveNotificationResponse: _onNotificationResponse,
    );
    
    // Créer le canal de notification pour Android
    await _createNotificationChannel();
    
    // Demander les permissions
    await _requestPermissions();
    
    print('✅ Service de notifications initialisé');
  }

  Future<void> _createNotificationChannel() async {
    const AndroidNotificationChannel channel = AndroidNotificationChannel(
      channelId,
      channelName,
      description: channelDescription,
      importance: Importance.defaultImportance,
      playSound: true,
      enableVibration: true,
    );

    await _notifications
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);
  }

  Future<bool> _requestPermissions() async {
    // Demander les permissions Android 13+
    if (await Permission.notification.isDenied) {
      final status = await Permission.notification.request();
      if (status.isDenied) {
        print('⚠️ Permissions de notification refusées');
        return false;
      }
    }
    
    // Permissions iOS
    await _notifications
        .resolvePlatformSpecificImplementation<IOSFlutterLocalNotificationsPlugin>()
        ?.requestPermissions(
          alert: true,
          badge: true,
          sound: true,
        );
        
    return true;
  }

  void _onNotificationResponse(NotificationResponse response) {
    print('🔔 Notification cliquée: ${response.payload}');
    
    if (response.payload != null) {
      final data = json.decode(response.payload!);
      _handleNotificationAction(data);
    }
  }

  void _handleNotificationAction(Map<String, dynamic> data) {
    final type = NotificationType.values.firstWhere(
      (e) => e.toString() == data['type'],
      orElse: () => NotificationType.dailyWord,
    );
    
    switch (type) {
      case NotificationType.dailyWord:
        // Navigation vers le mot du jour
        break;
      case NotificationType.studyReminder:
        // Navigation vers les favoris ou révisions
        break;
      case NotificationType.syncAlert:
        // Déclencher une synchronisation
        break;
      case NotificationType.quizChallenge:
        // Navigation vers les quiz
        break;
      case NotificationType.favoriteUpdate:
        // Navigation vers les favoris
        break;
    }
  }

  // === MÉTHODES PUBLIQUES ===

  /// Afficher une notification immédiate
  Future<void> showNotification({
    required NotificationType type,
    String? title,
    String? body,
    Map<String, dynamic>? payload,
    int? id,
  }) async {
    final config = _configs[type]!;
    final notificationId = id ?? Random().nextInt(1000000);
    
    final androidDetails = AndroidNotificationDetails(
      channelId,
      channelName,
      channelDescription: channelDescription,
      importance: Importance.defaultImportance,
      priority: config.priority,
      icon: config.icon,
      playSound: true,
      enableVibration: true,
    );
    
    const iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );
    
    final details = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );
    
    final payloadData = {
      'type': type.toString(),
      'timestamp': DateTime.now().millisecondsSinceEpoch,
      ...?payload,
    };
    
    await _notifications.show(
      notificationId,
      title ?? config.title,
      body ?? config.defaultBody,
      details,
      payload: json.encode(payloadData),
    );
    
    // Enregistrer la notification dans l'historique
    await _saveNotificationHistory(type, title ?? config.title, body ?? config.defaultBody);
  }

  /// Programmer une notification pour plus tard
  Future<void> scheduleNotification({
    required NotificationType type,
    required DateTime scheduledDate,
    String? title,
    String? body,
    Map<String, dynamic>? payload,
    int? id,
  }) async {
    final config = _configs[type]!;
    final notificationId = id ?? Random().nextInt(1000000);
    
    final androidDetails = AndroidNotificationDetails(
      channelId,
      channelName,
      channelDescription: channelDescription,
      importance: Importance.defaultImportance,
      priority: config.priority,
      icon: config.icon,
    );
    
    const iosDetails = DarwinNotificationDetails();
    
    final details = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );
    
    final payloadData = {
      'type': type.toString(),
      'timestamp': DateTime.now().millisecondsSinceEpoch,
      ...?payload,
    };
    
    await _notifications.zonedSchedule(
      notificationId,
      title ?? config.title,
      body ?? config.defaultBody,
      scheduledDate,
      details,
      payload: json.encode(payloadData),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
    );
    
    print('📅 Notification programmée pour ${scheduledDate.toString()}');
  }

  /// Programmer des notifications récurrentes (quotidiennes)
  Future<void> scheduleDailyNotification({
    required NotificationType type,
    required int hour,
    required int minute,
    String? title,
    String? body,
    Map<String, dynamic>? payload,
  }) async {
    final config = _configs[type]!;
    final notificationId = type.index + 1000; // ID fixe pour les récurrences
    
    final time = Time(hour, minute, 0);
    
    final androidDetails = AndroidNotificationDetails(
      channelId,
      channelName,
      channelDescription: channelDescription,
      importance: Importance.defaultImportance,
      priority: config.priority,
      icon: config.icon,
    );
    
    const iosDetails = DarwinNotificationDetails();
    
    final details = NotificationDetails(
      android: androidDetails,
      iOS: iosDetails,
    );
    
    final payloadData = {
      'type': type.toString(),
      'recurring': true,
      'timestamp': DateTime.now().millisecondsSinceEpoch,
      ...?payload,
    };
    
    await _notifications.zonedSchedule(
      notificationId,
      title ?? config.title,
      body ?? config.defaultBody,
      _nextInstanceOfTime(time),
      details,
      payload: json.encode(payloadData),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: DateTimeComponents.time,
    );
    
    print('🔁 Notification quotidienne programmée à ${hour}:${minute}');
  }

  /// Annuler une notification
  Future<void> cancelNotification(int id) async {
    await _notifications.cancel(id);
  }

  /// Annuler toutes les notifications
  Future<void> cancelAllNotifications() async {
    await _notifications.cancelAll();
  }

  /// Annuler les notifications d'un type spécifique
  Future<void> cancelNotificationsByType(NotificationType type) async {
    final pendingNotifications = await _notifications.pendingNotificationRequests();
    
    for (final notification in pendingNotifications) {
      if (notification.payload != null) {
        final data = json.decode(notification.payload!);
        if (data['type'] == type.toString()) {
          await _notifications.cancel(notification.id);
        }
      }
    }
  }

  // === NOTIFICATIONS SPÉCIFIQUES AU DICTIONNAIRE ===

  /// Notification du mot du jour
  Future<void> showDailyWordNotification() async {
    try {
      // Récupérer un mot aléatoire
      final words = await _dbHelper.getAllWords(limit: 50);
      if (words.isEmpty) return;
      
      final randomWord = words[Random().nextInt(words.length)];
      
      await showNotification(
        type: NotificationType.dailyWord,
        title: 'Mot du jour : ${randomWord.zarmaWord}',
        body: '${randomWord.frenchMeaning}\nTouchez pour en savoir plus',
        payload: {'wordId': randomWord.id?.toString()},
      );
    } catch (e) {
      print('Erreur notification mot du jour: $e');
    }
  }

  /// Notification de rappel d'étude
  Future<void> showStudyReminderNotification() async {
    try {
      final favoriteCount = await _dbHelper.getFavoriteCount();
      
      String body;
      if (favoriteCount > 0) {
        body = 'Vous avez $favoriteCount mots favoris à réviser';
      } else {
        body = 'Explorez de nouveaux mots et ajoutez-les à vos favoris';
      }
      
      await showNotification(
        type: NotificationType.studyReminder,
        body: body,
      );
    } catch (e) {
      print('Erreur notification rappel étude: $e');
    }
  }

  /// Notification d'alerte de synchronisation
  Future<void> showSyncAlertNotification() async {
    await showNotification(
      type: NotificationType.syncAlert,
      body: 'Nouvelles données disponibles, synchronisez pour les obtenir',
    );
  }

  /// Notification de défi quiz
  Future<void> showQuizChallengeNotification() async {
    final messages = [
      'Testez vos connaissances avec un quiz rapide!',
      'Défi du jour : Pouvez-vous obtenir 100% au quiz?',
      'Révisez vos mots avec notre système de quiz interactif',
      'Temps de quiz ! Mesurez vos progrès en Zarma',
    ];
    
    final randomMessage = messages[Random().nextInt(messages.length)];
    
    await showNotification(
      type: NotificationType.quizChallenge,
      body: randomMessage,
    );
  }

  // === GESTION DES PRÉFÉRENCES ===

  /// Activer/désactiver les notifications
  Future<void> setNotificationsEnabled(bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('notifications_enabled', enabled);
    
    if (!enabled) {
      await cancelAllNotifications();
    }
  }

  /// Vérifier si les notifications sont activées
  Future<bool> areNotificationsEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool('notifications_enabled') ?? true;
  }

  /// Configurer l'heure du mot du jour
  Future<void> setDailyWordTime(int hour, int minute) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('daily_word_hour', hour);
    await prefs.setInt('daily_word_minute', minute);
    
    // Reprogrammer la notification
    if (await areNotificationsEnabled()) {
      await cancelNotificationsByType(NotificationType.dailyWord);
      await scheduleDailyNotification(
        type: NotificationType.dailyWord,
        hour: hour,
        minute: minute,
      );
    }
  }

  /// Récupérer l'heure du mot du jour
  Future<Map<String, int>> getDailyWordTime() async {
    final prefs = await SharedPreferences.getInstance();
    return {
      'hour': prefs.getInt('daily_word_hour') ?? 9,
      'minute': prefs.getInt('daily_word_minute') ?? 0,
    };
  }

  /// Configurer les rappels d'étude
  Future<void> setStudyReminderTime(int hour, int minute) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('study_reminder_hour', hour);
    await prefs.setInt('study_reminder_minute', minute);
    
    if (await areNotificationsEnabled()) {
      await cancelNotificationsByType(NotificationType.studyReminder);
      await scheduleDailyNotification(
        type: NotificationType.studyReminder,
        hour: hour,
        minute: minute,
      );
    }
  }

  // === HISTORIQUE DES NOTIFICATIONS ===

  Future<void> _saveNotificationHistory(NotificationType type, String title, String body) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final historyKey = 'notification_history';
      final existingHistory = prefs.getStringList(historyKey) ?? [];
      
      final notificationData = {
        'type': type.toString(),
        'title': title,
        'body': body,
        'timestamp': DateTime.now().millisecondsSinceEpoch,
      };
      
      existingHistory.insert(0, json.encode(notificationData));
      
      // Garder seulement les 50 dernières notifications
      if (existingHistory.length > 50) {
        existingHistory.removeRange(50, existingHistory.length);
      }
      
      await prefs.setStringList(historyKey, existingHistory);
    } catch (e) {
      print('Erreur sauvegarde historique notifications: $e');
    }
  }

  /// Récupérer l'historique des notifications
  Future<List<Map<String, dynamic>>> getNotificationHistory() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final historyStrings = prefs.getStringList('notification_history') ?? [];
      
      return historyStrings
          .map((str) => json.decode(str) as Map<String, dynamic>)
          .toList();
    } catch (e) {
      print('Erreur récupération historique notifications: $e');
      return [];
    }
  }

  /// Vider l'historique des notifications
  Future<void> clearNotificationHistory() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('notification_history');
  }

  // === UTILITAIRES ===

  DateTime _nextInstanceOfTime(Time time) {
    final now = DateTime.now();
    var scheduledDate = DateTime(now.year, now.month, now.day, time.hour, time.minute);
    
    if (scheduledDate.isBefore(now)) {
      scheduledDate = scheduledDate.add(Duration(days: 1));
    }
    
    return scheduledDate;
  }

  /// Obtenir les statistiques des notifications
  Future<Map<String, dynamic>> getNotificationStats() async {
    final history = await getNotificationHistory();
    final now = DateTime.now();
    
    final today = history.where((n) {
      final date = DateTime.fromMillisecondsSinceEpoch(n['timestamp']);
      return date.day == now.day && date.month == now.month && date.year == now.year;
    }).length;
    
    final thisWeek = history.where((n) {
      final date = DateTime.fromMillisecondsSinceEpoch(n['timestamp']);
      final weekAgo = now.subtract(Duration(days: 7));
      return date.isAfter(weekAgo);
    }).length;
    
    final byType = <String, int>{};
    for (final notification in history) {
      final type = notification['type'];
      byType[type] = (byType[type] ?? 0) + 1;
    }
    
    return {
      'total': history.length,
      'today': today,
      'thisWeek': thisWeek,
      'byType': byType,
      'enabled': await areNotificationsEnabled(),
    };
  }
}

// Configuration des notifications
class NotificationConfig {
  final String title;
  final String defaultBody;
  final String icon;
  final Priority priority;
  
  NotificationConfig({
    required this.title,
    required this.defaultBody,
    required this.icon,
    required this.priority,
  });
}