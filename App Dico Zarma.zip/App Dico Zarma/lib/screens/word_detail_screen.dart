import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:zarma_dictionary/screens/exercice_menu_screen.dart';
import 'package:zarma_dictionary/screens/quiz_menu_screen.dart';
import '../models/word_model.dart';

class WordDetailScreen extends StatefulWidget {
  final WordModel word;

  const WordDetailScreen({Key? key, required this.word}) : super(key: key);

  @override
  _WordDetailScreenState createState() => _WordDetailScreenState();
}

class _WordDetailScreenState extends State<WordDetailScreen>
    with TickerProviderStateMixin {
  bool _isFavorite = false;
  bool _isLearned = false;
  bool _isPlayingTTS = false;
  bool _isPlayingAudio = false;
  
  late AnimationController _slideController;
  late AnimationController _scaleController;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _scaleAnimation;

  final PageController _pageController = PageController();
  int _currentPage = 0;
  
  // Audio components
  late FlutterTts _flutterTts;
  late AudioPlayer _audioPlayer;

  @override
  void initState() {
    super.initState();
    _setupAnimations();
    _setupAudio();
    _loadWordStatus();
  }

  void _setupAnimations() {
    _slideController = AnimationController(
      duration: Duration(milliseconds: 800),
      vsync: this,
    );
    _scaleController = AnimationController(
      duration: Duration(milliseconds: 600),
      vsync: this,
    );

    _slideAnimation = Tween<Offset>(
      begin: Offset(0, 0.5),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _slideController,
      curve: Curves.easeOutCubic,
    ));

    _scaleAnimation = Tween<double>(
      begin: 0.8,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _scaleController,
      curve: Curves.easeOutBack,
    ));

    _slideController.forward();
    _scaleController.forward();
  }

  void _setupAudio() async {
    // Configuration TTS
    _flutterTts = FlutterTts();
    _audioPlayer = AudioPlayer();
    
    await _flutterTts.setLanguage("fr-FR"); // Français par défaut
    await _flutterTts.setSpeechRate(0.4);// Vitesse de parole
    await _flutterTts.setVolume(1.0);
    await _flutterTts.setPitch(1.0);
    
    // Callbacks TTS
    _flutterTts.setStartHandler(() {
      setState(() {
        _isPlayingTTS = true;
      });
    });

    _flutterTts.setCompletionHandler(() {
      setState(() {
        _isPlayingTTS = false;
      });
    });

    _flutterTts.setErrorHandler((msg) {
      setState(() {
        _isPlayingTTS = false;
      });
    });
    
    // Callbacks AudioPlayer
    _audioPlayer.onPlayerStateChanged.listen((PlayerState state) {
      setState(() {
        _isPlayingAudio = state == PlayerState.playing;
      });
    });
  }

  void _loadWordStatus() {
    setState(() {
      _isFavorite = false;
      _isLearned = false;
    });
  }

  Future<void> _playZarmaTTS() async {
    try {
      if (_isPlayingTTS) {
        await _flutterTts.stop();
        return;
      }
      
      // Essayer d'utiliser une langue locale si disponible
      await _flutterTts.setLanguage("fr-FR"); // Ou essayer "ha" pour Hausa qui pourrait être plus proche
      await _flutterTts.speak(widget.word.zarmaWord);
    } catch (e) {
      print('Erreur TTS: $e');
      _showErrorSnackBar('Impossible de lire le mot');
    }
  }

  Future<void> _playFrenchTTS() async {
    try {
      if (_isPlayingTTS) {
        await _flutterTts.stop();
        return;
      }
      
      await _flutterTts.setLanguage("fr-FR");
      await _flutterTts.speak(widget.word.frenchMeaning);
    } catch (e) {
      print('Erreur TTS: $e');
      _showErrorSnackBar('Impossible de lire la traduction');
    }
  }
Future<void> _playZarma() async {
    try {
      if (_isPlayingTTS) {
        await _flutterTts.stop();
        return;
      }
      
      // Essayer d'utiliser une langue locale si disponible
      await _flutterTts.setLanguage("fr-FR"); // Ou essayer "ha" pour Hausa qui pourrait être plus proche
      await _flutterTts.speak(widget.word.zarmaExample);
    } catch (e) {
      print('Erreur TTS: $e');
      _showErrorSnackBar('Impossible de lire le mot');
    }
  }

  Future<void> _playFrench() async {
    try {
      if (_isPlayingTTS) {
        await _flutterTts.stop();
        return;
      }
      
      await _flutterTts.setLanguage("fr-FR");
      await _flutterTts.speak(widget.word.frenchExample);
    } catch (e) {
      print('Erreur TTS: $e');
      _showErrorSnackBar('Impossible de lire la traduction');
    }
  }


  Future<void> _playAudioFile() async {
    try {
      if (widget.word.audioPath == null || widget.word.audioPath!.isEmpty) {
        _showErrorSnackBar('Aucun fichier audio disponible');
        return;
      }
      
      if (_isPlayingAudio) {
        await _audioPlayer.stop();
        return;
      }
      
      // Jouer le fichier audio local ou distant
      if (widget.word.audioPath!.startsWith('http')) {
        await _audioPlayer.play(UrlSource(widget.word.audioPath!));
      } else {
        await _audioPlayer.play(AssetSource(widget.word.audioPath!));
      }
    } catch (e) {
      print('Erreur lecture audio: $e');
      _showErrorSnackBar('Impossible de lire le fichier audio');
    }
  }

  void _toggleFavorite() {
    setState(() {
      _isFavorite = !_isFavorite;
    });
    
    HapticFeedback.lightImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(_isFavorite ? 'Ajouté aux favoris' : 'Retiré des favoris'),
        duration: Duration(seconds: 1),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  void _toggleLearned() {
    setState(() {
      _isLearned = !_isLearned;
    });
    
    HapticFeedback.mediumImpact();
    if (_isLearned) {
      _showCongratsDialog();
    }
  }

  void _showCongratsDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(
          children: [
            Icon(Icons.celebration, color: Colors.orange, size: 30),
            SizedBox(width: 8),
            Text('Félicitations !'),
          ],
        ),
        content: Text('Vous avez marqué ce mot comme appris !'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Super !', style: TextStyle(color: Colors.teal)),
          ),
        ],
      ),
    );
  }

  void _copyToClipboard(String text) {
    Clipboard.setData(ClipboardData(text: text));
    HapticFeedback.selectionClick();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Copié dans le presse-papiers'),
        duration: Duration(seconds: 1),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  void _shareWord() {
    String shareText = '''
${widget.word.zarmaWord} - ${widget.word.frenchMeaning}

Zarma: ${widget.word.zarmaExample}
Français: ${widget.word.frenchExample}

Via Dictionnaire Zarma-Français
    ''';
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Fonction de partage à implémenter'),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  @override
  void dispose() {
    _slideController.dispose();
    _scaleController.dispose();
    _pageController.dispose();
    _flutterTts.stop();
    _audioPlayer.dispose();
    super.dispose();
  }

  @override
Widget build(BuildContext context) {
  return Scaffold(
    backgroundColor: Colors.grey[50],
    body: NestedScrollView(
      headerSliverBuilder: (context, innerBoxIsScrolled) {
        return [_buildSliverAppBar()];
      },
      body: _buildMainContent(),
    ),
  );
}

  Widget _buildSliverAppBar() {
    return SliverAppBar(
      expandedHeight: 200,
      pinned: true,
      elevation: 0,
      backgroundColor: Colors.teal,
      flexibleSpace: FlexibleSpaceBar(
        background: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Colors.teal,
                Colors.teal.shade700,
                Colors.teal.shade800,
              ],
            ),
          ),
          child: Stack(
            children: [
              // Motif de fond
              Positioned(
                right: -100,
                top: -50,
                child: Container(
                  width: 200,
                  height: 200,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white.withOpacity(0.1),
                  ),
                ),
              ),
              Positioned(
                left: -50,
                bottom: -50,
                child: Container(
                  width: 150,
                  height: 150,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white.withOpacity(0.05),
                  ),
                ),
              ),
              // Contenu principal
              SafeArea(
                child: Padding(
                  padding: EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: ScaleTransition(
                              scale: _scaleAnimation,
                              child: Text(
                                widget.word.zarmaWord,
                                style: TextStyle(
                                  fontSize: 36,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ),
                          // Bouton audio principal dans le header
                          Container(
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(25),
                            ),
                            child: IconButton(
                              onPressed: _playZarmaTTS,
                              icon: _isPlayingTTS 
                                ? SizedBox(
                                    width: 20,
                                    height: 20,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                      valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                                    ),
                                  )
                                : Icon(Icons.volume_up, color: Colors.white, size: 24),
                              tooltip: 'Écouter en Zarma',
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 8),
                      SlideTransition(
                        position: _slideAnimation,
                        child: Text(
                          widget.word.frenchMeaning,
                          style: TextStyle(
                            fontSize: 20,
                            color: Colors.white.withOpacity(0.9),
                            fontWeight: FontWeight.w300,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      actions: [
        IconButton(
          icon: Icon(
            _isFavorite ? Icons.favorite : Icons.favorite_border,
            color: _isFavorite ? Colors.red : Colors.white,
          ),
          onPressed: _toggleFavorite,
        ),
        PopupMenuButton<String>(
          onSelected: (value) {
            switch (value) {
              case 'share':
                _shareWord();
                break;
              case 'copy':
                _copyToClipboard('${widget.word.zarmaWord} - ${widget.word.frenchMeaning}');
                break;
              case 'learned':
                _toggleLearned();
                break;
            }
          },
          itemBuilder: (context) => [
            PopupMenuItem(
              value: 'share',
              child: Row(
                children: [
                  Icon(Icons.share, color: Colors.blue),
                  SizedBox(width: 8),
                  Text('Partager'),
                ],
              ),
            ),
            PopupMenuItem(
              value: 'copy',
              child: Row(
                children: [
                  Icon(Icons.copy, color: Colors.green),
                  SizedBox(width: 8),
                  Text('Copier'),
                ],
              ),
            ),
            PopupMenuItem(
              value: 'learned',
              child: Row(
                children: [
                  Icon(
                    _isLearned ? Icons.check_circle : Icons.check_circle_outline,
                    color: _isLearned ? Colors.green : Colors.grey,
                  ),
                  SizedBox(width: 8),
                  Text(_isLearned ? 'Marquer comme non appris' : 'Marquer comme appris'),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }
  void _openQuizMenu() {
  Navigator.push(
    context,
    MaterialPageRoute(
      builder: (context) => QuizMenuScreen(),
    ),
  );
}

  Widget _buildMainContent() {
  return SingleChildScrollView(
    child: SlideTransition(
      position: _slideAnimation,
      child: Column(
        children: [
          _buildAudioControls(),
          _buildQuickActions(),
          _buildContentTabs(),
          _buildsynonyms(),
          _buildantonyms(),
          SizedBox(height: 100),
        ],
      ),
    ),
  );
}

  Widget _buildAudioControls() {
    return Container(
      margin: EdgeInsets.all(16),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.headphones, color: Colors.purple, size: 24),
              SizedBox(width: 8),
              Text(
                'Contrôles Audio',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.grey[800],
                ),
              ),
            ],
          ),
          SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: _buildAudioButton(
                  'Zarma',
                  Icons.record_voice_over,
                  Colors.teal,
                  _isPlayingTTS,
                  _playZarmaTTS,
                ),
              ),
              SizedBox(width: 12),
              Expanded(
                child: _buildAudioButton(
                  'Français',
                  Icons.translate,
                  Colors.blue,
                  _isPlayingTTS,
                  _playFrenchTTS,
                ),
              ),
              SizedBox(width: 12),
              Expanded(
                child: _buildAudioButton(
                  widget.word.hasAudio ? 'Audio Original' : 'Pas d\'audio',
                  Icons.audiotrack,
                  widget.word.hasAudio ? Colors.purple : Colors.grey,
                  _isPlayingAudio,
                  widget.word.hasAudio ? _playAudioFile : null,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildAudioButton(String label, IconData icon, Color color, bool isPlaying, VoidCallback? onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Column(
          children: [
            isPlaying
                ? SizedBox(
                    width: 24,
                    height: 24,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      valueColor: AlwaysStoppedAnimation<Color>(color),
                    ),
                  )
                : Icon(icon, color: color, size: 24),
            SizedBox(height: 8),
            Text(
              label,
              style: TextStyle(
                color: color,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
  void _openExerciceMenu() {
  Navigator.push(
    context,
    MaterialPageRoute(
      builder: (context) => ExerciceMenuScreen(),
    ),
  );
}

  Widget _buildQuickActions() {
  return Container(
    margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
    padding: EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(15),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.05),
          blurRadius: 10,
          offset: Offset(0, 2),
        ),
      ],
    ),
    child: Row(
      children: [
         _buildQuickActionButton(
          'Pratiquer',
          Icons.fitness_center,
          Colors.orange,
          _openExerciceMenu, // Nouvelle fonctionnalité
        ),
        SizedBox(width: 12),
        _buildQuickActionButton(
          'Quiz',
          Icons.quiz,
          Colors.green,
          _openQuizMenu, // Nouvelle fonctionnalité
        ),
        SizedBox(width: 12),
        _buildQuickActionButton(
          _isLearned ? 'Appris' : 'À apprendre',
          _isLearned ? Icons.check_circle : Icons.schedule,
          _isLearned ? Colors.green : Colors.grey,
          _toggleLearned,
        ),
      ],
    ),
  );
}

  Widget _buildQuickActionButton(String label, IconData icon, Color color, VoidCallback onTap) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(10),
        child: Container(
          padding: EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: color.withOpacity(0.3)),
          ),
          child: Column(
            children: [
              Icon(icon, color: color, size: 20),
              SizedBox(height: 4),
              Text(
                label,
                style: TextStyle(
                  color: color,
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }

Widget _buildContentTabs() {
  return Container(
    margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(15),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.05),
          blurRadius: 10,
          offset: Offset(0, 2),
        ),
      ],
    ),
    child: Column(
      children: [
        Container(
          decoration: BoxDecoration(
            color: Colors.grey[100],
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(15),
              topRight: Radius.circular(15),
            ),
          ),
          child: Row(
            children: [
              _buildTabButton('Exemples', 0),
              _buildTabButton('Détails', 1),
              _buildTabButton('Notes', 2),
            ],
          ),
        ),
        Container(
          height: 450, // Hauteur fixe pour le contenu des tabs
          child: PageView(
            controller: _pageController,
            onPageChanged: (page) => setState(() => _currentPage = page),
            children: [
              _buildExamplesTab(),
              _buildDetailsTab(),
              _buildNotesTab(),
            ],
          ),
        ),
      ],
    ),
  );
}

  Widget _buildTabButton(String title, int index) {
    bool isActive = _currentPage == index;
    return Expanded(
      child: InkWell(
        onTap: () {
          _pageController.animateToPage(
            index,
            duration: Duration(milliseconds: 300),
            curve: Curves.easeInOut,
          );
        },
        child: Container(
          padding: EdgeInsets.symmetric(vertical: 16),
          decoration: BoxDecoration(
            color: isActive ? Colors.teal : Colors.transparent,
            borderRadius: BorderRadius.only(
              topLeft: index == 0 ? Radius.circular(15) : Radius.zero,
              topRight: index == 2 ? Radius.circular(15) : Radius.zero,
            ),
          ),
          child: Text(
            title,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: isActive ? Colors.white : Colors.grey[700],
              fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildExamplesTab() {
  return SingleChildScrollView(
    padding: EdgeInsets.all(20),
    child: ConstrainedBox(
      constraints: BoxConstraints(
        minHeight: 400, // Hauteur minimale garantie
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildExampleCard(
            'Zarma',
            widget.word.zarmaExample,
            Colors.teal,
            Icons.translate,
            () => _playZarma(),
          ),
          SizedBox(height: 16),
          _buildExampleCard(
            'Français',
            widget.word.frenchExample,
            Colors.blue,
            Icons.language,
            () => _playFrench(),
          ),
          SizedBox(height: 20),
          _buildPronunciationGuide(),
          SizedBox(height: 20), // Espace supplémentaire
        ],
      ),
    ),
  );
}
  Widget _buildExampleCard(String language, String example, Color color, IconData icon, VoidCallback onPlayAudio) {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: color, size: 20),
              SizedBox(width: 8),
              Text(
                language,
                style: TextStyle(
                  color: color,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Spacer(),
              IconButton(
                icon: Icon(Icons.volume_up, color: color, size: 18),
                onPressed: onPlayAudio,
                padding: EdgeInsets.zero,
                constraints: BoxConstraints(),
                tooltip: 'Écouter',
              ),
              SizedBox(width: 8),
              IconButton(
                icon: Icon(Icons.copy, color: color, size: 18),
                onPressed: () => _copyToClipboard(example),
                padding: EdgeInsets.zero,
                constraints: BoxConstraints(),
                tooltip: 'Copier',
              ),
            ],
          ),
          SizedBox(height: 8),
          Text(
            example,
            style: TextStyle(
              fontSize: 16,
              fontStyle: FontStyle.italic,
              height: 1.4,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPronunciationGuide() {
    return Container(
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.purple.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.purple.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              Icon(Icons.record_voice_over, color: Colors.purple, size: 16),
              SizedBox(width: 8),
              Text(
                'Guide de prononciation',
                style: TextStyle(
                  color: Colors.purple,
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Spacer(),
              IconButton(
                icon: Icon(Icons.play_arrow, color: Colors.purple, size: 18),
                onPressed: _playZarmaTTS, // Lira l'exemple zarma complet
                padding: EdgeInsets.zero,
                constraints: BoxConstraints(),
                tooltip: 'Écouter l\'exemple complet',
              ),
            ],
          ),
          SizedBox(height: 6),
          Text(
            'Prononciation approximative : [${_generatePronunciation(widget.word.zarmaWord)}]',
            style: TextStyle(
              fontSize: 12,
              fontStyle: FontStyle.italic,
            ),
          ),
        ],
      ),
    );
  }

  String _generatePronunciation(String zarmaWord) {
    return zarmaWord.toLowerCase()
        .replaceAll('aa', 'aː')
        .replaceAll('ii', 'iː')
        .replaceAll('oo', 'oː')
        .replaceAll('uu', 'uː');
  }

  Widget _buildDetailsTab() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildDetailItem('Mot', widget.word.zarmaWord, Icons.text_fields),
          _buildDetailItem('Signification', widget.word.frenchMeaning, Icons.translate),
          _buildDetailItem('Longueur', '${widget.word.zarmaWord.length} caractères', Icons.straighten),
          _buildDetailItem('Voyelles', _countVowels(widget.word.zarmaWord).toString(), Icons.record_voice_over),
          if (widget.word.pronunciation != null && widget.word.pronunciation!.isNotEmpty)
            _buildDetailItem('Prononciation', widget.word.pronunciation!, Icons.volume_up),
          if (widget.word.etymology != null && widget.word.etymology!.isNotEmpty)
            _buildDetailItem('Étymologie', widget.word.etymology!, Icons.history),
        ],
      ),
    );
  }

  Widget _buildDetailItem(String label, String value, IconData icon) {
    return Container(
      margin: EdgeInsets.only(bottom: 16),
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey[50],
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.teal.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: Colors.teal, size: 20),
          ),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey[600],
                    fontWeight: FontWeight.w500,
                  ),
                ),
                Text(
                  value,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  int _countVowels(String word) {
    return word.toLowerCase().split('').where((char) => 
        'aeiou'.contains(char)).length;
  }

  Widget _buildNotesTab() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Notes personnelles',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.grey[800],
            ),
          ),
          SizedBox(height: 16),
          Container(
            height: 200,
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.yellow.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.yellow.withOpacity(0.3)),
            ),
            child: TextField(
              maxLines: null,
              expands: true,
              decoration: InputDecoration(
                hintText: 'Ajoutez vos notes personnelles sur ce mot...',
                border: InputBorder.none,
                hintStyle: TextStyle(color: Colors.grey[500]),
              ),
              style: TextStyle(fontSize: 14, height: 1.4),
            ),
          ),
          SizedBox(height: 16),
          ElevatedButton.icon(
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Notes sauvegardées'),
                  behavior: SnackBarBehavior.floating,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
              );
            },
            icon: Icon(Icons.save),
            label: Text('Sauvegarder les notes'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.teal,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildsynonyms() {
  // Récupérer les mots associés dynamiquement depuis le modèle
  
  List<String> synonyms = [];

  
  // Utiliser les données réelles du mot
  if (widget.word.synonyms != null && widget.word.synonyms!.isNotEmpty) {
    synonyms.addAll(widget.word.synonyms!);
  }
  
  
  // Si aucun mot associé n'est disponible, ne pas afficher la section
  if (synonyms.isEmpty) {
    return SizedBox.shrink();
  }
  
  return Container(
    margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Synonymes',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.grey[800],
          ),
        ),
        SizedBox(height: 12),
        Container(
          height: 50,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: synonyms.length,
            itemBuilder: (context, index) {
              return Container(
                margin: EdgeInsets.only(right: 8),
                child: ActionChip(
                  label: Text(synonyms[index]),
                  backgroundColor: Colors.teal.withOpacity(0.1),
                  labelStyle: TextStyle(color: Colors.teal),
                  onPressed: () {
                    _searchRelatedWord(synonyms[index]);
                  },
                  avatar: Icon(Icons.search, size: 16, color: Colors.teal),
                ),
              );
            },
          ),
        ),
      ],
    ),
  );
}

 Widget _buildantonyms() {
  // Récupérer les mots associés dynamiquement depuis le modèle
  
  List<String> antonyms = [];

  
  // Utiliser les données réelles du mot
  if (widget.word.synonyms != null && widget.word.synonyms!.isNotEmpty) {
    antonyms.addAll(widget.word.antonyms!);
  }
  
  
  // Si aucun mot associé n'est disponible, ne pas afficher la section
  if (antonyms.isEmpty) {
    return SizedBox.shrink();
  }
  
  return Container(
    margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Antonymes',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.grey[800],
          ),
        ),
        SizedBox(height: 12),
        Container(
          height: 50,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: antonyms.length,
            itemBuilder: (context, index) {
              return Container(
                margin: EdgeInsets.only(right: 8),
                child: ActionChip(
                  label: Text(antonyms[index]),
                  backgroundColor: Colors.teal.withOpacity(0.1),
                  labelStyle: TextStyle(color: Colors.teal),
                  onPressed: () {
                    _searchRelatedWord(antonyms[index]);
                  },
                  avatar: Icon(Icons.search, size: 16, color: Colors.teal),
                ),
              );
            },
          ),
        ),
      ],
    ),
  );
}

  void _searchRelatedWord(String word) {
  // Retourner à l'écran précédent avec le mot à rechercher
  Navigator.pop(context, word);
}

  Widget _buildLearningProgress() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.trending_up, color: Colors.green),
              SizedBox(width: 8),
              Text(
                'Progression d\'apprentissage',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: _buildProgressItem('Vu', 5, Colors.blue),
              ),
              Expanded(
                child: _buildProgressItem('Pratiqué', 2, Colors.orange),
              ),
              Expanded(
                child: _buildProgressItem('Maîtrisé', _isLearned ? 1 : 0, Colors.green),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildProgressItem(String label, int count, Color color) {
    return Column(
      children: [
        Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            shape: BoxShape.circle,
          ),
          child: Center(
            child: Text(
              count.toString(),
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
          ),
        ),
        SizedBox(height: 8),
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: Colors.grey[600],
          ),
        ),
      ],
    );
  }

  void _startQuizWithWord() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => QuizScreen(focusWord: widget.word),
      ),
    );
  }
}

// Écrans supplémentaires à implémenter
class PracticeScreen extends StatelessWidget {
  final WordModel word;

  const PracticeScreen({Key? key, required this.word}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Pratique - ${word.zarmaWord}'),
        backgroundColor: Colors.orange,
        foregroundColor: Colors.white,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.fitness_center, size: 100, color: Colors.orange),
            SizedBox(height: 20),
            Text(
              'Mode pratique pour',
              style: TextStyle(fontSize: 18, color: Colors.grey[600]),
            ),
            Text(
              word.zarmaWord,
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 40),
            ElevatedButton(
              onPressed: () {
                // Implémenter les exercices de pratique
              },
              child: Text('Commencer les exercices'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.orange,
                foregroundColor: Colors.white,
                padding: EdgeInsets.symmetric(horizontal: 32, vertical: 16),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class QuizScreen extends StatelessWidget {
  final WordModel focusWord;

  const QuizScreen({Key? key, required this.focusWord}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Quiz'),
        backgroundColor: Colors.green,
        foregroundColor: Colors.white,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.quiz, size: 100, color: Colors.green),
            SizedBox(height: 20),
            Text(
              'Quiz basé sur',
              style: TextStyle(fontSize: 18, color: Colors.grey[600]),
            ),
            Text(
              focusWord.zarmaWord,
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 40),
            ElevatedButton(
              onPressed: () {
                // Implémenter le quiz
              },
              child: Text('Démarrer le quiz'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                foregroundColor: Colors.white,
                padding: EdgeInsets.symmetric(horizontal: 32, vertical: 16),
              ),
            ),
          ],
        ),
      ),
    );
  }
}