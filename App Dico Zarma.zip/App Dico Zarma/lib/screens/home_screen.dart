// lib/screens/home_screen.dart - Version avec gestion silencieuse des erreurs
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:zarma_dictionary/screens/quiz_menu_screen.dart';
import 'package:zarma_dictionary/screens/exercice_menu_screen.dart';
import 'package:zarma_dictionary/widgets/recherche.dart';
import '../data/database_helper.dart';
import '../services/apiservice.dart';
import '../models/word_model.dart';
import 'word_detail_screen.dart';
import 'settings_screen.dart';
import 'about_screen.dart';
import '../models/sync_models.dart';
import '../models/historiquerecherche.dart';

class CentralizedHomeScreen extends StatefulWidget {
  @override
  _CentralizedHomeScreenState createState() => _CentralizedHomeScreenState();
}

class _CentralizedHomeScreenState extends State<CentralizedHomeScreen> with TickerProviderStateMixin {
  final CacheDatabaseHelper _cacheHelper = CacheDatabaseHelper();
  final FlutterTts _flutterTts = FlutterTts();
  
  List<WordModel> _words = [];
  List<WordModel> _filteredWords = [];
  bool _isLoading = true;
  bool _isRefreshing = false;
  bool _isInitializing = true;
  String _currentSearchQuery = '';
  bool _isGridView = false;
  bool _isOnline = false;
  String _connectionStatus = '';
  bool _isSpeaking = false;
  String? _currentSpeakingWord;
  Map<String, dynamic> _cacheInfo = {};
  AppStats? _appStats;
  SyncStatus? _syncStatus;
  bool _showSearchHistory = false;
  FocusNode _searchFocusNode = FocusNode();
  
  // Nouvelles variables pour la gestion silencieuse
  bool _hasTriedConnection = false;
  bool _isRetryingConnection = false;
  
  final TextEditingController _searchController = TextEditingController();
  late AnimationController _fabAnimationController;
  late Animation<double> _fabAnimation;
  late AnimationController _statusAnimationController;
  late Animation<Color?> _statusColorAnimation;

@override
void initState() {
  super.initState();
  _setupAnimations();
  _initializeTts();
  
  _searchFocusNode.addListener(() {
    
  });
  
  _initializeApp();
  
  // Rafraîchir les stats périodiquement
  WidgetsBinding.instance.addPostFrameCallback((_) {
    _refreshStatsPeriodically();
  });
}

void _refreshStatsPeriodically() {
  // Rafraîchir les stats toutes les 2 secondes (pour debug)
  Future.delayed(Duration(seconds: 2), () {
    if (mounted) {
      _loadStats();
      _refreshStatsPeriodically();
    }
  });
}

  void _setupAnimations() {
    _fabAnimationController = AnimationController(
      duration: Duration(milliseconds: 300),
      vsync: this,
    );
    _fabAnimation = CurvedAnimation(
      parent: _fabAnimationController,
      curve: Curves.easeInOut,
    );
    
    _statusAnimationController = AnimationController(
      duration: Duration(milliseconds: 500),
      vsync: this,
    );
    _statusColorAnimation = ColorTween(
      begin: Colors.orange,
      end: Colors.green,
    ).animate(_statusAnimationController);
    
    _fabAnimationController.forward();
  }

  void _initializeTts() async {
    try {
      await _flutterTts.setLanguage("fr-FR");
      await _flutterTts.setSpeechRate(0.4);
      await _flutterTts.setVolume(1.0);
      await _flutterTts.setPitch(1.0);
      
      _flutterTts.setCompletionHandler(() {
        if (mounted) {
          setState(() {
            _isSpeaking = false;
            _currentSpeakingWord = null;
          });
        }
      });
    } catch (e) {
      // Erreur silencieuse pour TTS
      print('TTS non disponible: $e');
    }
  }

  Future<void> _initializeApp() async {
    try {
      setState(() {
        _isInitializing = true;
        _isLoading = true;
      });

      print('🚀 Initialisation de l\'application...');
      
      // 1. Essayer d'initialiser avec connexion d'abord
      await _tryInitializeWithConnection();
      
      // 2. Si pas de connexion, essayer en mode offline
      if (!_hasTriedConnection) {
        await _initializeOfflineMode();
      }
      
      // 3. Charger les données disponibles
      await _loadAllData();
      
      setState(() {
        _isInitializing = false;
        _isLoading = false;
      });
      
      print('✅ Application initialisée avec succès');
      
      // 4. Continuer à essayer la connexion en arrière-plan si nécessaire
      if (!_isOnline) {
        _continueRetryingConnection();
      }
      
    } catch (e) {
      print('⚠️ Erreur lors de l\'initialisation: $e');
      
      // Même en cas d'erreur, on essaie de continuer en mode offline
      await _fallbackToOfflineMode();
      
      setState(() {
        _isInitializing = false;
        _isLoading = false;
      });
    }
  }

  Future<void> _tryInitializeWithConnection() async {
    try {
      // Test de connexion avec timeout court
      _isOnline = await ApiService.instance.testConnection().timeout(
        Duration(seconds: 5),
        onTimeout: () => false,
      );
      
      if (_isOnline) {
        await _cacheHelper.initializeApp();
        _hasTriedConnection = true;
        _connectionStatus = 'Connexion établie - Données synchronisées';
      }
    } catch (e) {
      print('Connexion non disponible: $e');
      _isOnline = false;
      _connectionStatus = 'Mode hors ligne - Utilisation du cache local';
    }
  }

  Future<void> _initializeOfflineMode() async {
    try {
      // Utiliser les méthodes existantes de votre CacheDatabaseHelper
      // Au lieu de initializeOfflineMode() qui n'existe pas, 
      // on utilise les données déjà en cache
      await _cacheHelper.getAllWords(forceOnline: false);
      _connectionStatus = 'Mode hors ligne - Données en cache utilisées';
      print('✅ Mode hors ligne initialisé');
    } catch (e) {
      print('Erreur initialisation offline: $e');
      _connectionStatus = 'Chargement des données...';
    }
  }

  Future<void> _fallbackToOfflineMode() async {
    try {
      await _initializeOfflineMode();
      await _loadAllData();
    } catch (e) {
      print('Erreur fallback offline: $e');
      _connectionStatus = 'Préparation des données en cours...';
    }
  }

  void _continueRetryingConnection() {
    // Essayer de reconnecter toutes les 30 secondes en silence
    Timer.periodic(Duration(seconds: 30), (timer) async {
      if (!mounted) {
        timer.cancel();
        return;
      }
      
      if (_isOnline) {
        timer.cancel();
        return;
      }
      
      try {
        final wasOnline = _isOnline;
        _isOnline = await ApiService.instance.testConnection().timeout(
          Duration(seconds: 3),
          onTimeout: () => false,
        );
        
        if (_isOnline && !wasOnline) {
          // Connexion rétablie - synchroniser silencieusement
          setState(() {
            _connectionStatus = 'Connexion rétablie - Synchronisation...';
          });
          
          await _performSilentSync();
          
          setState(() {
            _connectionStatus = 'En ligne - Données synchronisées';
          });
          
          _statusAnimationController.forward();
          timer.cancel();
        }
      } catch (e) {
        // Continuer silencieusement
      }
    });
  }

  Future<void> _performSilentSync() async {
    try {
      await _cacheHelper.performLightSync();
      await _loadAllData();
    } catch (e) {
      print('Sync silencieuse échouée: $e');
    }
  }

  Future<void> _loadAllData() async {
    await Future.wait([
      _checkConnectionStatus(),
      _loadWords(),
      _loadStats(),
      _loadCacheInfo(),
      _loadSyncStatus(),
    ]);
  }

  Future<void> _checkConnectionStatus() async {
    try {
      if (!_hasTriedConnection) {
        _isOnline = await ApiService.instance.testConnection().timeout(
          Duration(seconds: 3),
          onTimeout: () => false,
        );
      }
      
      if (_connectionStatus.isEmpty) {
        _connectionStatus = _isOnline 
          ? 'Connexion active - Données synchronisées'
          : 'Mode hors ligne - Utilisation du cache';
      }
      
      setState(() {});
      
      if (_isOnline) {
        _statusAnimationController.forward();
      } else {
        _statusAnimationController.reverse();
      }
    } catch (e) {
      // Erreur silencieuse
      _connectionStatus = 'Vérification de la connexion...';
    }
  }

  Future<void> _loadWords({bool forceRefresh = false}) async {
    try {
      print('📚 Chargement des mots - forceRefresh: $forceRefresh');
      
      if (forceRefresh) {
        setState(() => _isRefreshing = true);
      } else if (!_isInitializing) {
        setState(() => _isLoading = true);
      }

      final words = await _cacheHelper.getAllWords(forceOnline: forceRefresh && _isOnline);
      
      print('✅ ${words.length} mots chargés');

      setState(() {
        _words = words;
        _filteredWords = words;
        _isLoading = false;
        _isRefreshing = false;
      });
      
      _applyFilters();
      
    } catch (e, stackTrace) {
      print('⚠️ Erreur dans _loadWords: $e');
      print('Stack trace: $stackTrace');
      
      setState(() {
        _isLoading = false;
        _isRefreshing = false;
      });
      
      // Erreur silencieuse - ne pas montrer de SnackBar
    }
  }

  Future<void> _loadStats() async {
    try {
      final stats = await _cacheHelper.getStats();
      setState(() {
        _appStats = stats;
      });
    } catch (e) {
      print('Erreur chargement stats: $e');
      // En cas d'erreur, calculer les stats localement
      await _loadLocalStats();
    }
  }

  Future<void> _loadLocalStats() async {
    try {
      final favoriteCount = await _cacheHelper.getFavoriteCount();
      final wordsCount = _words.length;
      
      setState(() {
        _appStats = AppStats(
          totalWords: wordsCount,
          totalCategories: 0,
          avgDifficulty: 0.0,
          learnedWords: 0,
          totalFavorites: favoriteCount,
          wordsThisWeek: 0,
          completionRate: 0,
        );
      });
    } catch (e) {
      print('Erreur calcul stats locales: $e');
    }
  }

  Future<void> _loadCacheInfo() async {
    try {
      final cacheInfo = await _cacheHelper.getCacheInfo();
      setState(() {
        _cacheInfo = cacheInfo;
      });
    } catch (e) {
      print('Erreur info cache: $e');
    }
  }

  Future<void> _loadSyncStatus() async {
    try {
      final syncStatus = await _cacheHelper.getSyncStatus();
      setState(() {
        _syncStatus = syncStatus;
      });
    } catch (e) {
      print('Erreur sync status: $e');
    }
  }

  Future<void> _performFullSync() async {
    if (!_isOnline) {
      // Message discret au lieu d'une erreur
      _showInfoSnackBar('Connexion requise pour la synchronisation');
      return;
    }
    
    try {
      setState(() => _isRefreshing = true);
      
      await _cacheHelper.performFullSync();
      await _loadAllData();
      
      _showSuccessSnackBar('Synchronisation terminée');
    } catch (e) {
      print('Erreur sync: $e');
      _showInfoSnackBar('Synchronisation non disponible');
    } finally {
      setState(() => _isRefreshing = false);
    }
  }

  Future<void> _performLightSync() async {
    try {
      await _cacheHelper.performLightSync();
      await _loadAllData();
    } catch (e) {
      print('Erreur sync légère: $e');
      // Erreur silencieuse
    }
  }

  void _filterWords(String query) {
    setState(() {
      _currentSearchQuery = query;
    });
    
    if (query.isEmpty) {
      setState(() {
        _filteredWords = _words;
      });
      return;
    }
    
    _performSearch(query);
  }

  Future<void> _performSearch(String query) async {
    if (query.trim().isEmpty) return;
    
    try {
      setState(() => _isLoading = true);
      
      final results = await _cacheHelper.searchWords(query);
      
      setState(() {
        _filteredWords = results;
        _isLoading = false;
      });
      
    } catch (e) {
      setState(() => _isLoading = false);
      // Erreur silencieuse pour la recherche
      print('Erreur recherche: $e');
    }
  }

  void _applyFilters() {
    List<WordModel> filtered = _words;

    if (_currentSearchQuery.isNotEmpty) {
      filtered = filtered.where((word) {
        return word.zarmaWord.toLowerCase().contains(_currentSearchQuery.toLowerCase()) ||
            word.frenchMeaning.toLowerCase().contains(_currentSearchQuery.toLowerCase()) ||
            word.zarmaExample.toLowerCase().contains(_currentSearchQuery.toLowerCase()) ||
            word.frenchExample.toLowerCase().contains(_currentSearchQuery.toLowerCase());
      }).toList();
    }

    setState(() {
      _filteredWords = filtered;
    });
  }

  Future<void> _speakWord(String text, String wordKey) async {
    try {
      if (_isSpeaking) {
        await _flutterTts.stop();
      }
      
      setState(() {
        _isSpeaking = true;
        _currentSpeakingWord = wordKey;
      });
      
      await _flutterTts.speak(text);
    } catch (e) {
      print('TTS non disponible: $e');
      setState(() {
        _isSpeaking = false;
        _currentSpeakingWord = null;
      });
    }
  }

  void _toggleViewMode() {
    setState(() {
      _isGridView = !_isGridView;
    });
  }

  // Messages d'information discrets au lieu d'erreurs
  void _showInfoSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(Icons.info_outline, color: Colors.white),
            SizedBox(width: 8),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: Colors.blue,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        duration: Duration(seconds: 2), // Plus court
      ),
    );
  }

  void _showSuccessSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(Icons.check_circle_outline, color: Colors.white),
            SizedBox(width: 8),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: Colors.green,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        duration: Duration(seconds: 2),
      ),
    );
  }

  @override
  void dispose() {
    _searchController.dispose();
    _searchFocusNode.dispose();
    _fabAnimationController.dispose();
    _statusAnimationController.dispose();
    _flutterTts.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Écran d'initialisation amélioré
    if (_isInitializing) {
      return _buildLoadingScreen();
    }

    return Scaffold(
      backgroundColor: Colors.grey[50],
      body: RefreshIndicator(
        onRefresh: () => _performFullSync(),
        child: CustomScrollView(
          slivers: [
            _buildSliverAppBar(),
            SliverToBoxAdapter(child: _buildConnectionStatus()),
            if (_syncStatus != null && _syncStatus!.needsSync && _isOnline)
              SliverToBoxAdapter(child: _buildSyncAlert()),
            SliverToBoxAdapter(child: _buildQuickStats()),
            SliverToBoxAdapter(child: _buildSearchSection()),
            SliverToBoxAdapter(child: _buildQuickActions()),
            _buildWordsList(),
          ],
        ),
      ),
    );
  }

  Widget _buildLoadingScreen() {
    return Scaffold(
      backgroundColor: Colors.teal,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.book, size: 80, color: Colors.teal),
                  SizedBox(height: 20),
                  Text(
                    'Dictionnaire Zarma/Songhay',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.teal,
                    ),
                  ),
                  SizedBox(height: 20),
                  CircularProgressIndicator(color: Colors.teal),
                  SizedBox(height: 16),
                  Text(
                    'Chargement des mots...',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.grey[600],
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    _isRetryingConnection 
                        ? 'Tentative de connexion...'
                        : 'Préparation des données',
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey[500],
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Reste des widgets inchangés...
  Widget _buildSliverAppBar() {
    return SliverAppBar(
      expandedHeight: 120,
      floating: false,
      pinned: true,
      elevation: 0,
      backgroundColor: Colors.teal,
      flexibleSpace: FlexibleSpaceBar(
        title: Text(
          'Dictionnaire Zarma/Songhay',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 16,
          ),
        ),
        titlePadding: EdgeInsets.only(left: 16, bottom: 16),
        background: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Colors.teal, Colors.teal.shade700],
            ),
          ),
        ),
      ),
      actions: [
        if (_isRefreshing)
          Padding(
            padding: EdgeInsets.all(16),
            child: SizedBox(
              width: 20,
              height: 20,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
              ),
            ),
          )
        else if (_syncStatus?.needsSync == true && _isOnline)
          IconButton(
            icon: Stack(
              children: [
                Icon(Icons.sync),
                Positioned(
                  right: 0,
                  top: 0,
                  child: Container(
                    padding: EdgeInsets.all(2),
                    decoration: BoxDecoration(
                      color: Colors.orange,
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Icon(Icons.priority_high, size: 8, color: Colors.white),
                  ),
                ),
              ],
            ),
            onPressed: _performFullSync,
            tooltip: 'Synchronisation recommandée',
          )
        else
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: _isOnline ? _performFullSync : _performLightSync,
            tooltip: 'Actualiser',
          ),
        IconButton(
          icon: Icon(_isGridView ? Icons.list : Icons.grid_view),
          onPressed: _toggleViewMode,
        ),
        _buildAppBarMenu(),
      ],
    );
  }

  Widget _buildAppBarMenu() {
    return PopupMenuButton<String>(
      onSelected: (value) {
        switch (value) {
          case 'favorites':
            Navigator.push(context, MaterialPageRoute(
              builder: (context) => FavoritesScreen(),
            ));
            break;
          case 'search_history':
            _showSearchHistoryDialog();
            break;
          case 'sync_full':
            _performFullSync();
            break;
          case 'sync_light':
            _performLightSync();
            break;
          case 'cache_info':
            _showCacheInfoDialog();
            break;
          case 'clear_cache':
            _showClearCacheDialog();
            break;
          case 'settings':
            Navigator.push(context, MaterialPageRoute(
              builder: (context) => SyncSettingsScreen(),
            ));
            break;
          case 'favoris':
            Navigator.push(context, MaterialPageRoute(
              builder: (context) => FavoritesScreen(),
            ));
            break;
          case 'about':
            Navigator.push(context, MaterialPageRoute(
              builder: (context) => AboutScreen(),
            ));
            break;
        }
      },
      itemBuilder: (context) => [
        PopupMenuItem(
          value: 'search_history',
          child: Row(
            children: [
              Icon(Icons.history, color: Colors.grey),
              SizedBox(width: 8),
              Text('Historique des recherches'),
            ],
          ),
        ),
        if (_isOnline) ...[
          PopupMenuItem(
            value: 'sync_full',
            child: Row(
              children: [
                Icon(Icons.sync, color: Colors.blue),
                SizedBox(width: 8),
                Text('Synchronisation complète'),
              ],
            ),
          ),
        ],
        PopupMenuItem(
          value: 'settings',
          child: Row(
            children: [
              Icon(Icons.settings, color: Colors.grey),
              SizedBox(width: 8),
              Text('Paramètres'),
            ],
          ),
        ),
        PopupMenuItem(
          value: 'favoris',
          child: Row(
            children: [
              Icon(Icons.favorite, color: Colors.grey),
              SizedBox(width: 8),
              Text('Favoris'),
            ],
          ),
        ),
        PopupMenuItem(
          value: 'about',
          child: Row(
            children: [
              Icon(Icons.info_outline, color: Colors.grey),
              SizedBox(width: 8),
              Text('À propos'),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildConnectionStatus() {
    return AnimatedBuilder(
      animation: _statusColorAnimation,
      builder: (context, child) {
        Color statusColor = _isOnline ? Colors.green : Colors.orange;
        IconData statusIcon = _isOnline ? Icons.cloud_done : Icons.cloud_off;
        
        return Container(
          margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          padding: EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: statusColor.withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: statusColor.withOpacity(0.3)),
          ),
          child: Row(
            children: [
              Icon(statusIcon, color: statusColor, size: 16),
              SizedBox(width: 8),
              Expanded(
                child: Text(
                  _connectionStatus.isNotEmpty ? _connectionStatus : 'Préparation...',
                  style: TextStyle(
                    color: statusColor,
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
              if (!_isOnline && !_isRefreshing)
                TextButton(
                  onPressed: () => _checkConnectionStatus(),
                  child: Text('Réessayer', style: TextStyle(color: statusColor)),
                ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildSyncAlert() {
    if (_syncStatus == null || !_syncStatus!.needsSync) return SizedBox.shrink();
    
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.blue.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.blue.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Icon(Icons.sync_problem, color: Colors.blue, size: 20),
          SizedBox(width: 8),
          Expanded(
            child: Text(
              _syncStatus!.statusMessage,
              style: TextStyle(
                color: Colors.blue,
                fontSize: 13,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          if (_isOnline)
            ElevatedButton(
              onPressed: _performFullSync,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                foregroundColor: Colors.white,
                minimumSize: Size(80, 32),
              ),
              child: Text('Sync', style: TextStyle(fontSize: 12)),
            ),
        ],
      ),
    );
  }

  void _openQuizMenu() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => QuizMenuScreen(),
      ),
    );
  }

  void _openExerciceMenu() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ExerciceMenuScreen(),
      ),
    );
  }

  Widget _buildQuickStats() {
    return Container(
      margin: EdgeInsets.all(16),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          _buildStatItem(
            'Mots', 
            _appStats?.totalWords.toString() ?? _words.length.toString(), 
            Icons.book, 
            Colors.blue
          ),
          FutureBuilder<int>(
            future: _cacheHelper.getFavoriteCount(),
            builder: (context, snapshot) {
              final favoriteCount = snapshot.data ?? 0;
              return _buildStatItem(
                'Favoris', 
                favoriteCount.toString(), 
                Icons.favorite, 
                Colors.red,
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(
                    builder: (context) => FavoritesScreen(),
                  ));
                }
              );
            },
          ),
          _buildStatItem(
            'Catégories', 
            _appStats?.totalCategories.toString() ?? '6', 
            Icons.category, 
            Colors.green
          ),
          _buildStatItem(
            'Cache', 
            _cacheInfo['words_cached']?.toString() ?? '0', 
            _isOnline ? Icons.cloud_done : Icons.storage, 
            _isOnline ? Colors.green : Colors.amber
          ),
        ],
      ),
    );
  }

  Widget _buildStatItem(String label, String value, IconData icon, Color color, {VoidCallback? onTap}) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(10),
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, color: color, size: 24),
            ),
            SizedBox(height: 8),
            Text(
              value,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.grey[800],
              ),
            ),
            Text(
              label,
              style: TextStyle(
                fontSize: 12,
                color: Colors.grey[600],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSearchSection() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        children: [
          TextField(
            controller: _searchController,
            focusNode: _searchFocusNode,
            onChanged: _filterWords,
            decoration: InputDecoration(
              hintText: 'Rechercher un mot...',
              prefixIcon: Icon(Icons.search),
              suffixIcon: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (_currentSearchQuery.isNotEmpty)
                    IconButton(
                      icon: Icon(Icons.clear),
                      onPressed: () {
                        _searchController.clear();
                        _filterWords('');
                      },
                    ),
                  IconButton(
                    icon: Icon(Icons.history),
                    onPressed: _showSearchHistoryDialog,
                    tooltip: 'Historique des recherches',
                  ),
                ],
              ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(25),
              ),
              filled: true,
              fillColor: Colors.white,
            ),
          ),
          // Suggestions rapides basées sur l'historique
          if (_currentSearchQuery.isEmpty)
            FutureBuilder<List<SearchHistoryItem>>(
              future: _cacheHelper.getPopularSearches(limit: 5),
              builder: (context, snapshot) {
                if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return SizedBox.shrink();
                }
                
                return Container(
                  margin: EdgeInsets.only(top: 8),
                  height: 35,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: snapshot.data!.length,
                    itemBuilder: (context, index) {
                      final item = snapshot.data![index];
                      return Container(
                        margin: EdgeInsets.only(right: 8),
                        child: ActionChip(
                          label: Text(
                            item.query,
                            style: TextStyle(fontSize: 12),
                          ),
                          onPressed: () {
                            _searchController.text = item.query;
                            _filterWords(item.query);
                          },
                          backgroundColor: Colors.teal.withOpacity(0.1),
                          side: BorderSide(color: Colors.teal.withOpacity(0.3)),
                        ),
                      );
                    },
                  ),
                );
              },
            ),
        ],
      ),
    );
  }

  void _showSearchHistoryDialog() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: DraggableScrollableSheet(
          initialChildSize: 0.6,
          maxChildSize: 0.9,
          minChildSize: 0.3,
          builder: (context, scrollController) => SingleChildScrollView(
            controller: scrollController,
            child: SearchHistoryWidget(
              currentQuery: _currentSearchQuery,
              onSearchSelected: (selectedQuery) {
                Navigator.of(context).pop();
                _searchController.text = selectedQuery;
                _filterWords(selectedQuery);
              },
              onClearHistory: () {
                _loadAllData();
              },
              onClose: () => Navigator.of(context).pop(),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildQuickActions() {
    return Container(
      margin: EdgeInsets.all(16),
      child: Row(
        children: [
          _buildQuickActionButton(
            'Sync',
            _isRefreshing ? Icons.hourglass_empty : Icons.sync,
            _isOnline ? Colors.teal : Colors.teal,
            !_isRefreshing ? _performFullSync : null,
            isLoading: _isRefreshing,
          ),
          SizedBox(width: 12),
          _buildQuickActionButton(
            'Quiz',
            Icons.quiz,
            Colors.green,
            _openQuizMenu,
          ),
          SizedBox(width: 12),
          _buildQuickActionButton(
            'Pratiquer',
            Icons.fitness_center,
            Colors.orange,
            _openExerciceMenu,
          ),
          SizedBox(width: 12),
          _buildQuickActionButton(
            _isOnline ? 'En ligne' : 'Hors ligne',
            _isOnline ? Icons.cloud_done : Icons.cloud_off,
            _isOnline ? Colors.green : Colors.orange,
            () => _showConnectionInfoDialog(),
          ),
        ],
      ),
    );
  }

  Widget _buildQuickActionButton(String label, IconData icon, Color color, VoidCallback? onTap, {bool isLoading = false}) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: EdgeInsets.symmetric(vertical: 16),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: color.withOpacity(0.3)),
          ),
          child: Column(
            children: [
              isLoading
                  ? SizedBox(
                      width: 24,
                      height: 24,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor: AlwaysStoppedAnimation<Color>(color),
                      ),
                    )
                  : Icon(icon, color: color, size: 24),
              SizedBox(height: 4),
              Text(
                label,
                style: TextStyle(
                  color: color,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _toggleFavorite(WordModel word) async {
    try {
      if (word.id == null) {
        _showInfoSnackBar('Erreur: mot sans identifiant valide');
        return;
      }
      
      print('Toggle favori pour mot ID: ${word.id}, mot: ${word.zarmaWord}');
      
      final newStatus = await _cacheHelper.toggleFavorite(word);
      
      // Forcer le rafraîchissement des statistiques
      await _loadStats();
      
      _showSuccessSnackBar(
        newStatus ? 'Ajouté aux favoris' : 'Retiré des favoris'
      );
      
      print('Favori mis à jour: ${newStatus ? 'ajouté' : 'retiré'}');
      
    } catch (e) {
      print('Erreur toggle favori: $e');
      _showInfoSnackBar('Impossible de modifier les favoris');
    }
  }

  Widget _buildWordsList() {
    if (_isLoading) {
      return SliverFillRemaining(
        child: Center(
          child: Padding(
            padding: EdgeInsets.all(16.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: [
                CircularProgressIndicator(color: Colors.teal),
                SizedBox(height: 16),
                Text('Chargement du dictionnaire...'),
                if (!_isOnline)
                  Padding(
                    padding: EdgeInsets.only(top: 8),
                    child: Text(
                      'Mode hors ligne - Utilisation du cache',
                      style: TextStyle(fontSize: 12, color: Colors.orange),
                      textAlign: TextAlign.center,
                    ),
                  ),
              ],
            ),
          ),
        ),
      );
    }
    
    // Si pas de mots et pas de connexion, continuer à afficher le chargement
    if (_filteredWords.isEmpty && !_isOnline) {
      return SliverFillRemaining(
        child: Center(
          child: Padding(
            padding: EdgeInsets.all(16.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: [
                CircularProgressIndicator(color: Colors.orange),
                SizedBox(height: 16),
                Text('Chargement du dictionnaire...'),
                SizedBox(height: 8),
                Text(
                  'En attente de connexion...',
                  style: TextStyle(fontSize: 12, color: Colors.orange),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      );
    }
    
    // Seulement si en ligne ET aucun résultat de recherche
    if (_filteredWords.isEmpty && _isOnline && _currentSearchQuery.isNotEmpty) {
      return SliverFillRemaining(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.search_off, size: 80, color: Colors.grey[400]),
              SizedBox(height: 16),
              Text(
                'Aucun mot trouvé',
                style: TextStyle(fontSize: 18, color: Colors.grey[600]),
              ),
              Text(
                'pour "$_currentSearchQuery"',
                style: TextStyle(fontSize: 14, color: Colors.grey[500]),
              ),
            ],
          ),
        ),
      );
    }
    
    // Si pas de mots du tout même en ligne (cas très rare)
    if (_filteredWords.isEmpty && _isOnline) {
      return SliverFillRemaining(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.book_outlined, size: 80, color: Colors.grey[400]),
              SizedBox(height: 16),
              Text(
                'Dictionnaire vide',
                style: TextStyle(fontSize: 18, color: Colors.grey[600]),
              ),
              SizedBox(height: 8),
              Text(
                'Aucun mot disponible pour le moment',
                style: TextStyle(fontSize: 14, color: Colors.grey[500]),
              ),
            ],
          ),
        ),
      );
    }

    return SliverList(
      delegate: SliverChildBuilderDelegate(
        (context, index) {
          final word = _filteredWords[index];
          
          return FutureBuilder<bool>(
            future: word.id != null ? _cacheHelper.isFavorite(word.id!) : Future.value(false),
            builder: (context, snapshot) {
              final isFavoriteStatus = snapshot.data ?? false;
              
              return EnhancedWordCard(
                word: word,
                isFavorite: isFavoriteStatus,
                isSpeaking: _currentSpeakingWord == word.zarmaWord,
                isOffline: !_isOnline,
                onTap: () async {
                  final result = await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => WordDetailScreen(word: word),
                    ),
                  );
                  
                  if (result != null && result is String) {
                    _searchController.text = result;
                    _filterWords(result);
                  }
                },
                onFavoriteToggle: () => _toggleFavorite(word),
                onSpeakToggle: () => _speakWord(word.zarmaWord, word.zarmaWord),
              );
            },
          );
        },
        childCount: _filteredWords.length,
      ),
    );
  }

  // Boîtes de dialogue d'information (non intrusives)
  void _showCacheInfoDialog() {
    final lastSyncTime = _cacheInfo['last_sync'] != null 
        ? DateTime.fromMillisecondsSinceEpoch(_cacheInfo['last_sync'])
        : null;
        
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Informations du cache'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Mots en cache: ${_cacheInfo['words_cached'] ?? 0}'),
            Text('Favoris en cache: ${_cacheInfo['favorites_cached'] ?? 0}'),
            Text('Taille du cache: ${_cacheInfo['cache_size'] ?? 'Calcul...'}'),
            SizedBox(height: 12),
            Text('Statut: ${_isOnline ? 'En ligne' : 'Hors ligne'}'),
            if (lastSyncTime != null)
              Text('Dernière sync: ${_formatDateTime(lastSyncTime)}'),
            if (_syncStatus != null) ...[
              SizedBox(height: 8),
              Text('État sync: ${_syncStatus!.statusMessage}'),
            ],
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text('Fermer'),
          ),
          if (_isOnline)
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                _performFullSync();
              },
              child: Text('Synchroniser'),
            ),
        ],
      ),
    );
  }

  void _showClearCacheDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Vider le cache'),
        content: Text(
          'Êtes-vous sûr de vouloir vider le cache local ?\n\n'
          'Toutes les données hors ligne seront supprimées. '
          'Une connexion internet sera nécessaire pour récupérer les données.'
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text('Annuler'),
          ),
          TextButton(
            onPressed: () async {
              Navigator.of(context).pop();
              try {
                await _cacheHelper.clearCache();
                await _initializeApp();
                _showSuccessSnackBar('Cache vidé avec succès');
              } catch (e) {
                _showInfoSnackBar('Impossible de vider le cache');
              }
            },
            child: Text('Vider', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  void _showConnectionInfoDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Informations de connexion'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  _isOnline ? Icons.cloud_done : Icons.cloud_off,
                  color: _isOnline ? Colors.green : Colors.orange,
                ),
                SizedBox(width: 8),
                Text('Statut: ${_isOnline ? 'En ligne' : 'Hors ligne'}'),
              ],
            ),
            SizedBox(height: 8),
            SizedBox(height: 12),
            Text(_connectionStatus),
            SizedBox(height: 12),
            if (!_isOnline)
              Container(
                padding: EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.orange.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  'En mode hors ligne, vous utilisez les données en cache. '
                  'Certaines fonctionnalités comme la synchronisation '
                  'nécessitent une connexion internet.',
                  style: TextStyle(color: Colors.orange[800], fontSize: 12),
                ),
              )
            else
              Container(
                padding: EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.green.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  'Connexion active. Toutes les fonctionnalités sont disponibles.',
                  style: TextStyle(color: Colors.green[800], fontSize: 12),
                ),
              ),
            if (_syncStatus != null) ...[
              SizedBox(height: 12),
              Text(
                'Synchronisation: ${_syncStatus!.statusMessage}',
                style: TextStyle(fontSize: 12, fontWeight: FontWeight.w500),
              ),
            ],
          ],
        ),
        actions: [
          if (!_isOnline)
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                _checkConnectionStatus();
              },
              child: Text('Réessayer'),
            ),
          if (_isOnline && _syncStatus?.needsSync == true)
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                _performFullSync();
              },
              child: Text('Synchroniser'),
            ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text('Fermer'),
          ),
        ],
      ),
    );
  }

  String _formatDateTime(DateTime dateTime) {
    final now = DateTime.now();
    final difference = now.difference(dateTime);
    
    if (difference.inDays > 0) {
      return 'Il y a ${difference.inDays} jour(s)';
    } else if (difference.inHours > 0) {
      return 'Il y a ${difference.inHours} heure(s)';
    } else if (difference.inMinutes > 0) {
      return 'Il y a ${difference.inMinutes} minute(s)';
    } else {
      return 'À l\'instant';
    }
  }
}

// Widget EnhancedWordCard inchangé
class EnhancedWordCard extends StatelessWidget {
  final WordModel word;
  final bool isFavorite;
  final bool isSpeaking;
  final bool isOffline;
  final VoidCallback onTap;
  final VoidCallback onFavoriteToggle;
  final VoidCallback onSpeakToggle;

  const EnhancedWordCard({
    Key? key,
    required this.word,
    required this.isFavorite,
    this.isSpeaking = false,
    this.isOffline = false,
    required this.onTap,
    required this.onFavoriteToggle,
    required this.onSpeakToggle,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      word.zarmaWord,
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.teal,
                      ),
                    ),
                  ),
                  if (isOffline)
                    Container(
                      margin: EdgeInsets.only(right: 8),
                      padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: Colors.orange.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        'CACHE',
                        style: TextStyle(
                          fontSize: 8,
                          fontWeight: FontWeight.bold,
                          color: Colors.orange[800],
                        ),
                      ),
                    ),
                  IconButton(
                    icon: Icon(
                      isSpeaking ? Icons.volume_up : Icons.volume_up_outlined,
                      color: isSpeaking ? Colors.orange : Colors.blue,
                    ),
                    onPressed: onSpeakToggle,
                  ),
                  IconButton(
                    icon: Icon(
                      isFavorite ? Icons.favorite : Icons.favorite_border,
                      color: isFavorite ? Colors.red : Colors.grey,
                    ),
                    onPressed: onFavoriteToggle,
                  ),
                  Icon(Icons.arrow_forward_ios, color: Colors.grey, size: 16),
                ],
              ),
              SizedBox(height: 4),
              Text(
                word.frenchMeaning,
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.grey[700],
                ),
              ),
              SizedBox(height: 8),
              Text(
                word.zarmaExample,
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.grey[600],
                  fontStyle: FontStyle.italic,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              if (word.category != null && word.category!.isNotEmpty) ...[
                SizedBox(height: 8),
                Row(
                  children: [
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.blue.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        word.category!,
                        style: TextStyle(
                          fontSize: 10,
                          color: Colors.blue[800],
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

// FavoritesScreen inchangé
class FavoritesScreen extends StatefulWidget {
  @override
  _FavoritesScreenState createState() => _FavoritesScreenState();
}

class _FavoritesScreenState extends State<FavoritesScreen> {
  final CacheDatabaseHelper _cacheHelper = CacheDatabaseHelper();
  List<WordModel> _favoriteWords = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadFavorites();
  }

  Future<void> _loadFavorites() async {
    try {
      setState(() => _isLoading = true);
      final favorites = await _cacheHelper.getFavoriteWords();
      setState(() {
        _favoriteWords = favorites;
        _isLoading = false;
      });
    } catch (e) {
      print('Erreur chargement favoris: $e');
      setState(() => _isLoading = false);
    }
  }

  Future<void> _toggleFavorite(WordModel word) async {
    try {
      await _cacheHelper.toggleFavorite(word);
      await _loadFavorites();
    } catch (e) {
      print('Erreur toggle favori: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Favoris (${_favoriteWords.length})'),
        backgroundColor: Colors.red,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: _loadFavorites,
          ),
        ],
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : _favoriteWords.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.favorite_border, size: 80, color: Colors.grey[400]),
                      SizedBox(height: 16),
                      Text(
                        'Aucun favori',
                        style: TextStyle(fontSize: 18, color: Colors.grey[600]),
                      ),
                      SizedBox(height: 8),
                      Text(
                        'Ajoutez des mots en favoris en cliquant sur le cœur',
                        style: TextStyle(fontSize: 14, color: Colors.grey[500]),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  itemCount: _favoriteWords.length,
                  itemBuilder: (context, index) {
                    final word = _favoriteWords[index];
                    return FutureBuilder<bool>(
                      future: _cacheHelper.isFavorite(word.id!),
                      builder: (context, snapshot) {
                        final isFavorite = snapshot.data ?? true;
                        return EnhancedWordCard(
                          word: word,
                          isFavorite: isFavorite,
                          isOffline: true,
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => WordDetailScreen(word: word),
                              ),
                            );
                          },
                          onFavoriteToggle: () => _toggleFavorite(word),
                          onSpeakToggle: () {},
                        );
                      },
                    );
                  },
                ),
              );
            }
            }