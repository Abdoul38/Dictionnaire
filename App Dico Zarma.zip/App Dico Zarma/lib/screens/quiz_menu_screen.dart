import 'dart:async';

import 'package:flutter/material.dart';
import 'quiz_screen.dart';
import '../services/apiservice.dart';

class QuizMenuScreen extends StatefulWidget {
  @override
  _QuizMenuScreenState createState() => _QuizMenuScreenState();
}

class _QuizMenuScreenState extends State<QuizMenuScreen>
    with TickerProviderStateMixin {
  late AnimationController _slideController;
  late AnimationController _fadeController;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _fadeAnimation;
  List<dynamic> quizzes = [];
  bool isLoading = true;
  bool isLoadingInProgress = false;
  
  // CACHE PERSISTANT - durée très longue
  static bool _dataLoaded = false;
  static List<dynamic> _cachedQuizzes = [];
  static DateTime? _lastLoadTime;
  static DateTime? _lastAttemptTime;

  @override
  void initState() {
    super.initState();
    _setupAnimations();
    
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        _loadDataSilently();
      }
    });
  }

  // CHARGEMENT SILENCIEUX SANS MESSAGES D'ERREUR
  Future<void> _loadDataSilently() async {
    // Toujours utiliser le cache si disponible (cache très long - 24h)
    if (_dataLoaded && 
        _lastLoadTime != null && 
        DateTime.now().difference(_lastLoadTime!) < Duration(hours: 24)) {
      
      setState(() {
        quizzes = _cachedQuizzes;
        isLoading = false;
      });
      
      // Essayer de rafraîchir en arrière-plan si le cache a plus de 30 minutes
      if (DateTime.now().difference(_lastLoadTime!) > Duration(minutes: 30)) {
        _backgroundRefresh();
      }
      return;
    }
    
    // Si pas de cache, essayer de charger
    await _loadDataQuietly();
  }

  // CHARGEMENT EN ARRIÈRE-PLAN SANS AFFECTER L'UI
  Future<void> _backgroundRefresh() async {
    // Ne pas refaire de requête si on vient d'en faire une récemment
    if (_lastAttemptTime != null && 
        DateTime.now().difference(_lastAttemptTime!) < Duration(minutes: 15)) {
      return;
    }
    
    try {
      _lastAttemptTime = DateTime.now();
      
      // Test rapide de connexion
      final isConnected = await ApiService.instance.testConnection()
          .timeout(Duration(seconds: 3));
      
      if (!isConnected) return;
      
      // Attendre avant de faire la requête
      await Future.delayed(Duration(seconds: 2));
      
      final newQuizzes = await ApiService.instance.getQuizzes()
          .timeout(Duration(seconds: 8));
      
      // Mettre à jour le cache silencieusement
      if (newQuizzes.isNotEmpty) {
        _cachedQuizzes = newQuizzes;
        _lastLoadTime = DateTime.now();
        _dataLoaded = true;
        
        // Mettre à jour l'UI seulement si les données ont changé
        if (mounted && !_listsEqual(quizzes, newQuizzes)) {
          setState(() {
            quizzes = newQuizzes;
          });
        }
      }
    } catch (e) {
      // Ignorer toutes les erreurs en arrière-plan
    }
  }

  // CHARGEMENT PRINCIPAL SILENCIEUX
  Future<void> _loadDataQuietly() async {
    if (isLoadingInProgress) return;
    
    setState(() {
      isLoadingInProgress = true;
      isLoading = true;
    });

    try {
      // Si on a déjà essayé récemment, utiliser les données par défaut
      if (_lastAttemptTime != null && 
          DateTime.now().difference(_lastAttemptTime!) < Duration(minutes: 10)) {
        
        if (_cachedQuizzes.isNotEmpty) {
          setState(() {
            quizzes = List<dynamic>.from(_cachedQuizzes);
            isLoading = false;
            isLoadingInProgress = false;
          });
          return;
        }
        
        // Charger des données par défaut si pas de cache
        _loadDefaultQuizzes();
        return;
      }
      
      _lastAttemptTime = DateTime.now();
      
      // Test rapide de connexion
      final isConnected = await ApiService.instance.testConnection()
          .timeout(Duration(seconds: 5));
      
      if (!isConnected) {
        _handleLoadingFallback();
        return;
      }

      // Chargement avec retry silencieux
      final loadedQuizzes = await _loadQuizzesQuietly();
      
      if (mounted) {
        setState(() {
          this.quizzes = loadedQuizzes;
          isLoading = false;
          isLoadingInProgress = false;
        });
        
        // Mettre à jour le cache
        _cachedQuizzes = loadedQuizzes;
        _dataLoaded = true;
        _lastLoadTime = DateTime.now();
      }
      
    } catch (e) {
      // Pas de messages d'erreur - juste fallback
      _handleLoadingFallback();
    }
  }

  // RETRY SILENCIEUX SANS ERREURS
  Future<List<dynamic>> _loadQuizzesQuietly({int maxRetries = 1}) async {
    for (int attempt = 0; attempt < maxRetries; attempt++) {
      try {
        final result = await ApiService.instance.getQuizzes()
            .timeout(Duration(seconds: 10));
        return result;
      } catch (e) {
        // Si c'est un rate limit, attendre plus longtemps
        if (e.toString().contains('429') || 
            e.toString().contains('Too Many Requests')) {
          await Future.delayed(Duration(seconds: 30));
        }
        
        if (attempt == maxRetries - 1) {
          rethrow;
        }
      }
    }
    return [];
  }

  // FALLBACK SILENCIEUX
  void _handleLoadingFallback() {
    if (mounted) {
      setState(() {
        isLoading = false;
        isLoadingInProgress = false;
        
        // Utiliser le cache si disponible
        if (_cachedQuizzes.isNotEmpty) {
          quizzes = _cachedQuizzes;
        } else {
          // Charger des données par défaut
          _loadDefaultQuizzes();
        }
      });
    }
  }

  // DONNÉES PAR DÉFAUT SI RIEN N'EST DISPONIBLE
  void _loadDefaultQuizzes() {
    quizzes = [
      {
        'id': 'default_1',
        'title': 'Quiz Vocabulaire de Base',
        'description': 'Apprenez les mots essentiels en zarma',
        'difficulty': 'Débutant',
        'category': 'vocabulaire',
        'question_count': 2,
        'questions': _getDefaultQuestions(),
      },
      {
        'id': 'default_2', 
        'title': 'Culture Zarma',
        'description': 'Découvrez la richesse culturelle zarma',
        'difficulty': 'Intermédiaire',
        'category': 'culture',
        'question_count': 8,
        'questions': _getDefaultCultureQuestions(),
      }
    ];
  }

  // QUESTIONS PAR DÉFAUT
  List<Map<String, dynamic>> _getDefaultQuestions() {
    return [
      {
        'id': '1',
        'question_text': 'Comment dit-on "salut" en zarma ?',
        'options': ['Mata  nigo', 'Fofo', 'Baani', 'aucune reponse'],
        'correct_answer': 1,
        'explanation': 'Fofo est la salutation zarma pour dire bonjour.',
      },
      {
        'id': '2',
        'question_text': 'Que signifie "baani" en français ?',
        'options': ['Au revoir', 'Santé', 'Bonjour', 'Bonsoir'],
        'correct_answer': 1,
        'explanation': 'Baani signifie Santé en zarma.',
      },
      {
        'id': '3',
        'question_text': 'Comment dit-on "eau" en zarma ?',
        'options': ['Hari', 'Haw', 'batou', 'Kasu'],
        'correct_answer': 0,
        'explanation': 'Hari signifie eau en zarma.',
      },
    ];
  }

  List<Map<String, dynamic>> _getDefaultCultureQuestions() {
    return [
      {
        'id': '1',
        'question_text': 'Quelle est la principale activité économique du peuple zarma ?',
        'options': ['Agriculture', 'Pêche', 'Commerce', 'Artisanat'],
        'correct_answer': 0,
        'explanation': 'L\'agriculture est traditionnellement l\'activité principale des Zarmas.',
      },
      {
        'id': '2',
        'question_text': 'Dans quelle région du Niger vivent principalement les Zarmas ?',
        'options': ['Nord', 'Sud', 'Ouest', 'Est'],
        'correct_answer': 2,
        'explanation': 'Les Zarmas vivent principalement dans l\'ouest du Niger.',
      },
    ];
  }

  // RECHARGEMENT MANUEL DÉSACTIVÉ
  Future<void> _manualRefresh() async {
    // Désactivé complètement pour éviter les appels API
    return;
  }

  // NAVIGATION SÉCURISÉE SANS CONTRÔLES
  void _startQuizFromData(Map<String, dynamic> quiz) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => QuizScreen.fromApi(
          quizData: quiz,
          category: quiz['category']?.toString() ?? '',
          quizType: quiz['quiz_type']?.toString() ?? '',
        ),
      ),
    );
  }

  // UTILITAIRE POUR COMPARER LES LISTES
  bool _listsEqual(List a, List b) {
    if (a.length != b.length) return false;
    for (int i = 0; i < a.length; i++) {
      if (a[i]['id'] != b[i]['id']) return false;
    }
    return true;
  }

  // BUILD SECTION QUIZ SIMPLIFIÉE
  Widget _buildQuizSection() {
    if (isLoading) {
      return _buildLoadingCard();
    }

    if (quizzes.isEmpty) {
      return _buildMinimalEmptyCard();
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 4),
          child: Row(
            children: [
              Text(
                'Quiz ',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              Spacer(),
              Text(
                '${quizzes.length} disponible${quizzes.length > 1 ? 's' : ''}',
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.white.withOpacity(0.8),
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 16),
        ...quizzes.map((quiz) => _buildQuizCardFromApi(quiz)).toList(),
      ],
    );
  }

  Widget _buildLoadingCard() {
    return Container(
      padding: EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.1),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          SizedBox(
            width: 20,
            height: 20,
            child: CircularProgressIndicator(
              strokeWidth: 2,
              valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
            ),
          ),
          SizedBox(width: 16),
          Expanded(
            child: Text(
              'Chargement des quiz...',
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMinimalEmptyCard() {
    return Container(
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.1),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        children: [
          Icon(Icons.quiz, color: Colors.white, size: 48),
          SizedBox(height: 12),
          Text(
            'Quiz en préparation...',
            style: TextStyle(
              color: Colors.white.withOpacity(0.9),
              fontSize: 16,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  void _setupAnimations() {
    _slideController = AnimationController(
      duration: Duration(milliseconds: 800),
      vsync: this,
    );
    _fadeController = AnimationController(
      duration: Duration(milliseconds: 1000),
      vsync: this,
    );

    _slideAnimation = Tween<Offset>(
      begin: Offset(0, 0.5),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _slideController,
      curve: Curves.easeOutCubic,
    ));

    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeOut,
    ));

    _slideController.forward();
    _fadeController.forward();
  }

  @override
  void dispose() {
    _slideController.dispose();
    _fadeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Colors.teal.shade600,
              Colors.blue.shade600,
              Colors.purple.shade600,
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              Expanded(
                child: RefreshIndicator(
                  onRefresh: _manualRefresh,
                  color: Colors.white,
                  backgroundColor: Colors.teal,
                  child: SingleChildScrollView(
                    physics: AlwaysScrollableScrollPhysics(),
                    padding: EdgeInsets.all(20),
                    child: Column(
                      children: [
                        FadeTransition(
                          opacity: _fadeAnimation,
                          child: _buildWelcomeCard(),
                        ),
                        SizedBox(height: 30),
                        SlideTransition(
                          position: _slideAnimation,
                          child: _buildQuizSection(),
                        ),
                        SizedBox(height: 30),
                        SlideTransition(
                          position: _slideAnimation,
                          child: _buildAboutSection(),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: EdgeInsets.all(20),
      child: Row(
        children: [
          IconButton(
            onPressed: () => Navigator.pop(context),
            icon: Icon(Icons.arrow_back, color: Colors.white),
          ),
          Expanded(
            child: Text(
              'Quiz et Exercices Zarma',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWelcomeCard() {
    return Container(
      padding: EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.95),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 20,
            offset: Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        children: [
          Icon(
            Icons.school,
            size: 60,
            color: Colors.teal,
          ),
          SizedBox(height: 16),
          Text(
            'Bienvenue dans l\'espace d\'apprentissage',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              color: Colors.grey[800],
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 8),
          Text(
            'Testez vos connaissances sur la langue zarma et découvrez la riche histoire du peuple zarma',
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey[600],
              height: 1.4,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildQuizCardFromApi(Map<String, dynamic> quiz) {
    final title = quiz['title'] ?? 'Quiz sans titre';
    final description = quiz['description'] ?? 'Pas de description';
    final difficulty = quiz['difficulty'] ?? 'Débutant';
    final category = quiz['category'] ?? 'general';
    final questionCount = quiz['question_count'] ?? quiz['questionCount'] ?? quiz['questions_count'] ?? quiz['questions']?.length ?? 0;
    
   
    
    print('Quiz: ${title}, Question count: $questionCount'); // Pour debug

    return GestureDetector(
      onTap: () => _startQuizFromData(quiz),
      child: Container(
        width: double.infinity,
        margin: EdgeInsets.only(bottom: 12),
        padding: EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 15,
              offset: Offset(0, 5),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: _getCategoryColor(category).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(_getCategoryIcon(category), 
                      color: _getCategoryColor(category), size: 24),
                ),
                Spacer(),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  decoration: BoxDecoration(
                    color: _getDifficultyColor(difficulty).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    difficulty,
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: _getDifficultyColor(difficulty),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 16),
            Text(
              title,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.grey[800],
              ),
            ),
            SizedBox(height: 8),
            Text(
              description,
              style: TextStyle(
                fontSize: 13,
                color: Colors.grey[600],
                height: 1.3,
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
            SizedBox(height: 8),
            // CORRECTION: Affichage amélioré du nombre de questions
            Container(
              padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: Colors.grey.shade100,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.quiz, color: Colors.grey[600], size: 14),
                  SizedBox(width: 4),
                  Text(
                    '$questionCount question${questionCount > 1 ? 's' : ''}',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                      color: Colors.grey[600],
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 16),
            Row(
              children: [
                Text(
                  'Commencer',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: _getCategoryColor(category),
                  ),
                ),
                SizedBox(width: 4),
                Icon(Icons.arrow_forward, 
                    color: _getCategoryColor(category), size: 16),
              ],
            ),
          ],
        ),
      ),
    );
  }


  Widget _buildAboutSection() {
    return Container(
      padding: EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.2)),
      ),
      child: Column(
        children: [
          Icon(
            Icons.info_outline,
            color: Colors.white,
            size: 40,
          ),
          SizedBox(height: 16),
          Text(
            'À propos',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          SizedBox(height: 8),
          Text(
            'Cette application vous aide à apprendre la langue zarma et à découvrir la riche histoire du peuple zarma du Niger. Progressez à votre rythme avec des quiz adaptés et des exercices interactifs.',
            style: TextStyle(
              fontSize: 14,
              color: Colors.white.withOpacity(0.9),
              height: 1.4,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Color _getCategoryColor(String? category) {
    switch (category?.toLowerCase()) {
      case 'language':
      case 'langue':
        return Colors.green;
      case 'history':
      case 'histoire':
        return Colors.purple;
      case 'culture':
        return Colors.orange;
      case 'geography':
      case 'géographie':
        return Colors.blue;
      case 'vocabulary':
      case 'vocabulaire':
        return Colors.teal;
      case 'grammar':
      case 'grammaire':
        return Colors.pink;
      default:
        return Colors.grey;
    }
  }

  IconData _getCategoryIcon(String? category) {
    switch (category?.toLowerCase()) {
      case 'language':
      case 'langue':
        return Icons.translate;
      case 'history':
      case 'histoire':
        return Icons.history;
      case 'culture':
        return Icons.people;
      case 'geography':
      case 'géographie':
        return Icons.map;
      case 'vocabulary':
      case 'vocabulaire':
        return Icons.book;
      case 'grammar':
      case 'grammaire':
        return Icons.description;
      default:
        return Icons.help;
    }
  }

  Color _getDifficultyColor(String? difficulty) {
    switch (difficulty?.toLowerCase()) {
      case 'débutant':
      case 'beginner':
      case 'easy':
        return Colors.green;
      case 'intermédiaire':
      case 'intermediate':
      case 'medium':
        return Colors.orange;
      case 'avancé':
      case 'advanced':
      case 'hard':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }
}