// lib/screens/notification_settings_screen.dart
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:zarma_dictionary/screens/notification_service.dart';

class NotificationSettingsScreen extends StatefulWidget {
  @override
  _NotificationSettingsScreenState createState() => _NotificationSettingsScreenState();
}

class _NotificationSettingsScreenState extends State<NotificationSettingsScreen> {
  final NotificationService _notificationService = NotificationService.instance;
  
  bool _notificationsEnabled = true;
  bool _dailyWordEnabled = true;
  bool _studyRemindersEnabled = true;
  bool _syncAlertsEnabled = true;
  bool _quizChallengesEnabled = true;
  
  TimeOfDay _dailyWordTime = TimeOfDay(hour: 9, minute: 0);
  TimeOfDay _studyReminderTime = TimeOfDay(hour: 18, minute: 0);
  
  bool _isLoading = true;
  Map<String, dynamic>? _notificationStats;

  @override
  void initState() {
    super.initState();
    _loadSettings();
    _loadStats();
  }

  Future<void> _loadSettings() async {
    try {
      setState(() => _isLoading = true);
      
      _notificationsEnabled = await _notificationService.areNotificationsEnabled();
      
      final dailyWordTimeMap = await _notificationService.getDailyWordTime();
      _dailyWordTime = TimeOfDay(
        hour: dailyWordTimeMap['hour']!,
        minute: dailyWordTimeMap['minute']!,
      );
      
      // Charger les préférences individuelles
      final prefs = await SharedPreferences.getInstance();
      _dailyWordEnabled = prefs.getBool('daily_word_enabled') ?? true;
      _studyRemindersEnabled = prefs.getBool('study_reminders_enabled') ?? true;
      _syncAlertsEnabled = prefs.getBool('sync_alerts_enabled') ?? true;
      _quizChallengesEnabled = prefs.getBool('quiz_challenges_enabled') ?? true;
      
      // Récupérer l'heure des rappels d'étude
      final studyHour = prefs.getInt('study_reminder_hour') ?? 18;
      final studyMinute = prefs.getInt('study_reminder_minute') ?? 0;
      _studyReminderTime = TimeOfDay(hour: studyHour, minute: studyMinute);
      
      setState(() => _isLoading = false);
    } catch (e) {
      print('Erreur chargement paramètres notifications: $e');
      setState(() => _isLoading = false);
    }
  }

  Future<void> _loadStats() async {
    try {
      final stats = await _notificationService.getNotificationStats();
      setState(() {
        _notificationStats = stats;
      });
    } catch (e) {
      print('Erreur chargement stats notifications: $e');
    }
  }

  Future<void> _toggleNotifications(bool enabled) async {
    setState(() => _notificationsEnabled = enabled);
    
    await _notificationService.setNotificationsEnabled(enabled);
    
    if (enabled) {
      await _setupNotifications();
    }
    
    _showSnackBar(enabled ? 'Notifications activées' : 'Notifications désactivées');
    await _loadStats();
  }

  Future<void> _toggleDailyWord(bool enabled) async {
    setState(() => _dailyWordEnabled = enabled);
    
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('daily_word_enabled', enabled);
    
    if (_notificationsEnabled) {
      if (enabled) {
        await _notificationService.scheduleDailyNotification(
          type: NotificationType.dailyWord,
          hour: _dailyWordTime.hour,
          minute: _dailyWordTime.minute,
        );
      } else {
        await _notificationService.cancelNotificationsByType(NotificationType.dailyWord);
      }
    }
    
    _showSnackBar(enabled ? 'Mot du jour activé' : 'Mot du jour désactivé');
  }

  Future<void> _toggleStudyReminders(bool enabled) async {
    setState(() => _studyRemindersEnabled = enabled);
    
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('study_reminders_enabled', enabled);
    
    if (_notificationsEnabled) {
      if (enabled) {
        await _notificationService.scheduleDailyNotification(
          type: NotificationType.studyReminder,
          hour: _studyReminderTime.hour,
          minute: _studyReminderTime.minute,
        );
      } else {
        await _notificationService.cancelNotificationsByType(NotificationType.studyReminder);
      }
    }
    
    _showSnackBar(enabled ? 'Rappels d\'étude activés' : 'Rappels d\'étude désactivés');
  }

  Future<void> _toggleSyncAlerts(bool enabled) async {
    setState(() => _syncAlertsEnabled = enabled);
    
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('sync_alerts_enabled', enabled);
    
    _showSnackBar(enabled ? 'Alertes de sync activées' : 'Alertes de sync désactivées');
  }

  Future<void> _toggleQuizChallenges(bool enabled) async {
    setState(() => _quizChallengesEnabled = enabled);
    
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('quiz_challenges_enabled', enabled);
    
    _showSnackBar(enabled ? 'Défis quiz activés' : 'Défis quiz désactivés');
  }

  Future<void> _setDailyWordTime() async {
    final TimeOfDay? pickedTime = await showTimePicker(
      context: context,
      initialTime: _dailyWordTime,
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: ColorScheme.light(
              primary: Colors.teal,
            ),
          ),
          child: child!,
        );
      },
    );

    if (pickedTime != null) {
      setState(() => _dailyWordTime = pickedTime);
      
      await _notificationService.setDailyWordTime(
        pickedTime.hour,
        pickedTime.minute,
      );
      
      _showSnackBar('Heure du mot du jour mise à jour');
    }
  }

  Future<void> _setStudyReminderTime() async {
    final TimeOfDay? pickedTime = await showTimePicker(
      context: context,
      initialTime: _studyReminderTime,
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: ColorScheme.light(
              primary: Colors.teal,
            ),
          ),
          child: child!,
        );
      },
    );

    if (pickedTime != null) {
      setState(() => _studyReminderTime = pickedTime);
      
      await _notificationService.setStudyReminderTime(
        pickedTime.hour,
        pickedTime.minute,
      );
      
      _showSnackBar('Heure des rappels d\'étude mise à jour');
    }
  }

  Future<void> _setupNotifications() async {
    if (!_notificationsEnabled) return;
    
    // Annuler toutes les notifications existantes
    await _notificationService.cancelAllNotifications();
    
    // Reprogrammer selon les préférences
    if (_dailyWordEnabled) {
      await _notificationService.scheduleDailyNotification(
        type: NotificationType.dailyWord,
        hour: _dailyWordTime.hour,
        minute: _dailyWordTime.minute,
      );
    }
    
    if (_studyRemindersEnabled) {
      await _notificationService.scheduleDailyNotification(
        type: NotificationType.studyReminder,
        hour: _studyReminderTime.hour,
        minute: _studyReminderTime.minute,
      );
    }
  }

  Future<void> _testNotification() async {
    await _notificationService.showNotification(
      type: NotificationType.dailyWord,
      title: 'Test de notification',
      body: 'Si vous voyez ceci, les notifications fonctionnent !',
    );
    
    _showSnackBar('Notification de test envoyée');
  }

  Future<void> _clearNotificationHistory() async {
    await _notificationService.clearNotificationHistory();
    await _loadStats();
    _showSnackBar('Historique des notifications effacé');
  }

  void _showNotificationHistory() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => NotificationHistoryScreen(),
      ),
    );
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.teal,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        duration: Duration(seconds: 2),
      ),
    );
  }

  String _formatTime(TimeOfDay time) {
    return '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return Scaffold(
        appBar: AppBar(
          title: Text('Paramètres de notifications'),
          backgroundColor: Colors.teal,
          foregroundColor: Colors.white,
        ),
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        title: Text('Paramètres de notifications'),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
        elevation: 0,
        actions: [
          IconButton(
            icon: Icon(Icons.history),
            onPressed: _showNotificationHistory,
            tooltip: 'Historique des notifications',
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Statistiques des notifications
            if (_notificationStats != null)
              _buildStatsCard(),
            
            SizedBox(height: 16),
            
            // Activation/désactivation générale
            _buildMainToggleCard(),
            
            SizedBox(height: 16),
            
            // Section mot du jour
            _buildDailyWordSection(),
            
            SizedBox(height: 16),
            
            // Section rappels d'étude
            _buildStudyRemindersSection(),
            
            SizedBox(height: 16),
            
            // Section alertes diverses
            _buildAlertsSection(),
            
            SizedBox(height: 16),
            
            // Actions rapides
            _buildQuickActionsSection(),
          ],
        ),
      ),
    );
  }

  Widget _buildStatsCard() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Statistiques des notifications',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.teal,
              ),
            ),
            SizedBox(height: 12),
            Row(
              children: [
                _buildStatItem('Total', _notificationStats!['total'].toString(), Colors.blue),
                _buildStatItem('Aujourd\'hui', _notificationStats!['today'].toString(), Colors.green),
                _buildStatItem('Cette semaine', _notificationStats!['thisWeek'].toString(), Colors.orange),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatItem(String label, String value, Color color) {
    return Expanded(
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              value,
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
          ),
          SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(fontSize: 12, color: Colors.grey[600]),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildMainToggleCard() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                Icon(
                  _notificationsEnabled ? Icons.notifications_active : Icons.notifications_off,
                  color: _notificationsEnabled ? Colors.teal : Colors.grey,
                  size: 28,
                ),
                SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Notifications',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        _notificationsEnabled 
                          ? 'Toutes les notifications sont activées' 
                          : 'Toutes les notifications sont désactivées',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                ),
                Switch.adaptive(
                  value: _notificationsEnabled,
                  onChanged: _toggleNotifications,
                  activeColor: Colors.teal,
                ),
              ],
            ),
            if (!_notificationsEnabled) ...[
              SizedBox(height: 12),
              Container(
                padding: EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.orange.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.orange.withOpacity(0.3)),
                ),
                child: Row(
                  children: [
                    Icon(Icons.info_outline, color: Colors.orange, size: 20),
                    SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Activez les notifications pour recevoir des rappels d\'apprentissage quotidiens',
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.orange[800],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildDailyWordSection() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.book, color: Colors.blue, size: 24),
                SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Mot du jour',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Switch.adaptive(
                  value: _dailyWordEnabled && _notificationsEnabled,
                  onChanged: _notificationsEnabled ? _toggleDailyWord : null,
                  activeColor: Colors.blue,
                ),
              ],
            ),
            if (_dailyWordEnabled && _notificationsEnabled) ...[
              SizedBox(height: 12),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: Icon(Icons.schedule, color: Colors.blue),
                title: Text('Heure de notification'),
                subtitle: Text(_formatTime(_dailyWordTime)),
                trailing: Icon(Icons.edit, color: Colors.grey),
                onTap: _setDailyWordTime,
              ),
              Container(
                padding: EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.blue.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  'Recevez chaque jour un mot zarma différent avec sa traduction française',
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.blue[800],
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildStudyRemindersSection() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.school, color: Colors.green, size: 24),
                SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Rappels d\'étude',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Switch.adaptive(
                  value: _studyRemindersEnabled && _notificationsEnabled,
                  onChanged: _notificationsEnabled ? _toggleStudyReminders : null,
                  activeColor: Colors.green,
                ),
              ],
            ),
            if (_studyRemindersEnabled && _notificationsEnabled) ...[
              SizedBox(height: 12),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: Icon(Icons.schedule, color: Colors.green),
                title: Text('Heure de rappel'),
                subtitle: Text(_formatTime(_studyReminderTime)),
                trailing: Icon(Icons.edit, color: Colors.grey),
                onTap: _setStudyReminderTime,
              ),
              Container(
                padding: EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.green.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  'Rappels quotidiens pour réviser vos mots favoris et continuer votre apprentissage',
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.green[800],
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildAlertsSection() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Alertes et défis',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 12),
            _buildAlertToggle(
              'Alertes de synchronisation',
              'Soyez informé quand de nouvelles données sont disponibles',
              Icons.sync,
              Colors.purple,
              _syncAlertsEnabled,
              _toggleSyncAlerts,
            ),
            Divider(),
            _buildAlertToggle(
              'Défis quiz',
              'Recevez des invitations pour tester vos connaissances',
              Icons.quiz,
              Colors.orange,
              _quizChallengesEnabled,
              _toggleQuizChallenges,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAlertToggle(
    String title,
    String subtitle,
    IconData icon,
    Color color,
    bool value,
    Function(bool) onChanged,
  ) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: Icon(icon, color: color),
      title: Text(title),
      subtitle: Text(
        subtitle,
        style: TextStyle(fontSize: 12, color: Colors.grey[600]),
      ),
      trailing: Switch.adaptive(
        value: value && _notificationsEnabled,
        onChanged: _notificationsEnabled ? onChanged : null,
        activeColor: color,
      ),
    );
  }

  Widget _buildQuickActionsSection() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Actions rapides',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _testNotification,
                    icon: Icon(Icons.notifications_active),
                    label: Text('Test'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.teal,
                      foregroundColor: Colors.white,
                    ),
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _showNotificationHistory,
                    icon: Icon(Icons.history),
                    label: Text('Historique'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.teal,
                      side: BorderSide(color: Colors.teal),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: TextButton.icon(
                onPressed: _clearNotificationHistory,
                icon: Icon(Icons.clear_all, color: Colors.red),
                label: Text('Effacer l\'historique', style: TextStyle(color: Colors.red)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Écran d'historique des notifications
class NotificationHistoryScreen extends StatefulWidget {
  @override
  _NotificationHistoryScreenState createState() => _NotificationHistoryScreenState();
}

class _NotificationHistoryScreenState extends State<NotificationHistoryScreen> {
  final NotificationService _notificationService = NotificationService.instance;
  List<Map<String, dynamic>> _notifications = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  Future<void> _loadHistory() async {
    try {
      setState(() => _isLoading = true);
      final history = await _notificationService.getNotificationHistory();
      setState(() {
        _notifications = history;
        _isLoading = false;
      });
    } catch (e) {
      print('Erreur chargement historique: $e');
      setState(() => _isLoading = false);
    }
  }

  String _getNotificationTypeLabel(String type) {
    switch (type) {
      case 'NotificationType.dailyWord':
        return 'Mot du jour';
      case 'NotificationType.studyReminder':
        return 'Rappel d\'étude';
      case 'NotificationType.syncAlert':
        return 'Alerte de sync';
      case 'NotificationType.quizChallenge':
        return 'Défi quiz';
      default:
        return 'Notification';
    }
  }

  Color _getNotificationTypeColor(String type) {
    switch (type) {
      case 'NotificationType.dailyWord':
        return Colors.blue;
      case 'NotificationType.studyReminder':
        return Colors.green;
      case 'NotificationType.syncAlert':
        return Colors.purple;
      case 'NotificationType.quizChallenge':
        return Colors.orange;
      default:
        return Colors.grey;
    }
  }

  IconData _getNotificationTypeIcon(String type) {
    switch (type) {
      case 'NotificationType.dailyWord':
        return Icons.book;
      case 'NotificationType.studyReminder':
        return Icons.school;
      case 'NotificationType.syncAlert':
        return Icons.sync;
      case 'NotificationType.quizChallenge':
        return Icons.quiz;
      default:
        return Icons.notifications;
    }
  }

  String _formatTimestamp(int timestamp) {
    final date = DateTime.fromMillisecondsSinceEpoch(timestamp);
    final now = DateTime.now();
    final difference = now.difference(date);

    if (difference.inDays > 0) {
      return 'Il y a ${difference.inDays} jour(s)';
    } else if (difference.inHours > 0) {
      return 'Il y a ${difference.inHours} heure(s)';
    } else if (difference.inMinutes > 0) {
      return 'Il y a ${difference.inMinutes} minute(s)';
    } else {
      return 'À l\'instant';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Historique des notifications'),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: _loadHistory,
          ),
        ],
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : _notifications.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.notifications_off, size: 80, color: Colors.grey[400]),
                      SizedBox(height: 16),
                      Text(
                        'Aucune notification',
                        style: TextStyle(fontSize: 18, color: Colors.grey[600]),
                      ),
                      SizedBox(height: 8),
                      Text(
                        'L\'historique des notifications apparaîtra ici',
                        style: TextStyle(fontSize: 14, color: Colors.grey[500]),
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  padding: EdgeInsets.all(16),
                  itemCount: _notifications.length,
                  itemBuilder: (context, index) {
                    final notification = _notifications[index];
                    final type = notification['type'];
                    final title = notification['title'];
                    final body = notification['body'];
                    final timestamp = notification['timestamp'];

                    return Card(
                      margin: EdgeInsets.only(bottom: 8),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      child: ListTile(
                        leading: Container(
                          padding: EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: _getNotificationTypeColor(type).withOpacity(0.2),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Icon(
                            _getNotificationTypeIcon(type),
                            color: _getNotificationTypeColor(type),
                          ),
                        ),
                        title: Text(
                          title,
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(body, maxLines: 2, overflow: TextOverflow.ellipsis),
                            SizedBox(height: 4),
                            Row(
                              children: [
                                Container(
                                  padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                  decoration: BoxDecoration(
                                    color: _getNotificationTypeColor(type).withOpacity(0.2),
                                    borderRadius: BorderRadius.circular(4),
                                  ),
                                  child: Text(
                                    _getNotificationTypeLabel(type),
                                    style: TextStyle(
                                      fontSize: 10,
                                      color: _getNotificationTypeColor(type),
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                                Spacer(),
                                Text(
                                  _formatTimestamp(timestamp),
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: Colors.grey[500],
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                        isThreeLine: true,
                      ),
                    );
                  },
                ),
    );
  }
}