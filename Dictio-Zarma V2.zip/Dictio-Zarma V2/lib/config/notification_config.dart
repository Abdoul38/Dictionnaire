import 'package:flutter/material.dart';
class NotificationConfig {
  // Configuration WebSocket
  static const String WS_URL = 'wss://dictionnaire-zarma-api.onrender.com/api/ws';
  
  // Configuration de reconnexion
  static const Duration RECONNECT_INTERVAL = Duration(seconds: 10);
  static const int MAX_RECONNECT_ATTEMPTS = 5;
  
  // Configuration des notifications
  static const int MAX_NOTIFICATIONS = 100;
  static const Duration NOTIFICATION_DISPLAY_DURATION = Duration(seconds: 4);
  static const Duration PING_INTERVAL = Duration(seconds: 30);
  
  // Clés de stockage local
  static const String CACHED_NOTIFICATIONS_KEY = 'cached_notifications';
  static const String NOTIFICATION_SETTINGS_KEY = 'notification_settings';
  
  // Types de notifications
  static const Map<String, NotificationTypeConfig> NOTIFICATION_TYPES = {
    'info': NotificationTypeConfig(
      color: Colors.blue,
      icon: Icons.info,
      priority: 1,
    ),
    'success': NotificationTypeConfig(
      color: Colors.green,
      icon: Icons.check_circle,
      priority: 2,
    ),
    'warning': NotificationTypeConfig(
      color: Colors.orange,
      icon: Icons.warning,
      priority: 3,
    ),
    'error': NotificationTypeConfig(
      color: Colors.red,
      icon: Icons.error,
      priority: 4,
    ),
  };
}

class NotificationTypeConfig {
  final Color color;
  final IconData icon;
  final int priority;
  
  const NotificationTypeConfig({
    required this.color,
    required this.icon,
    required this.priority,
  });
}