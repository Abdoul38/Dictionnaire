// lib/widgets/notification_bottom_sheet.dart
import 'package:flutter/material.dart';
import 'package:zarma_dictionary/widgets/notification_item.dart';
import '../models/notification_model.dart';
import '../services/notification_service.dart';

class NotificationBottomSheet extends StatefulWidget {
  @override
  _NotificationBottomSheetState createState() => _NotificationBottomSheetState();
}

class _NotificationBottomSheetState extends State<NotificationBottomSheet> {
  @override
  void initState() {
    super.initState();
    // Forcer le chargement des notifications au démarrage
    WidgetsBinding.instance.addPostFrameCallback((_) {
      NotificationService().clearExpiredNotifications();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.9,
      decoration: BoxDecoration(
        color: Colors.grey[100],
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        children: [
          // Handle
          Container(
            margin: EdgeInsets.only(top: 8),
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: Colors.grey[400],
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          
          // Header fixe avec couleur teal
          Container(
            width: double.infinity,
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.teal,
              borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
            ),
            child: Row(
              children: [
                Icon(Icons.notifications, color: Colors.white, size: 28),
                SizedBox(width: 8),
                Text(
                  'NOTIFICATIONS',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    letterSpacing: 1.2,
                  ),
                ),
                Spacer(),
                StreamBuilder<List<NotificationModel>>(
                  stream: NotificationService().notificationsStream,
                  builder: (context, snapshot) {
                    final unreadCount = NotificationService().unreadCount;
                    if (unreadCount > 0) {
                      return TextButton(
                        onPressed: () {
                          NotificationService().markAllAsRead();
                        },
                        child: Text(
                          'Tout lu',
                          style: TextStyle(fontSize: 10,color: Colors.white),
                        ),
                      );
                    }
                    return SizedBox.shrink();
                  },
                ),
                IconButton(
                  icon: Icon(Icons.close, color: Colors.white),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),
          ),
          
          // Liste des notifications scrollable
          Expanded(
            child: Container(
              color: Colors.grey[100],
              child: StreamBuilder<List<NotificationModel>>(
                stream: NotificationService().notificationsStream,
                initialData: NotificationService().notifications, // Données initiales
                builder: (context, snapshot) {
                  print('📱 StreamBuilder rebuild - Connection: ${snapshot.connectionState}');
                  print('📊 Données reçues: ${snapshot.data?.length ?? 0} notifications');
                  
                  // Afficher les données même en cours de chargement
                  final allNotifications = snapshot.data ?? NotificationService().notifications;
                  
                  // Afficher toutes les notifications non expirées
                  final notifications = allNotifications
                      .where((n) => !n.isExpired)
                      .toList();
                  
                  print('🎯 Notifications filtrées: ${notifications.length}');

                  if (notifications.isEmpty) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            CircularProgressIndicator(color: Colors.teal),
                            SizedBox(height: 16),
                            Text(
                              'Chargement des notifications...',
                              style: TextStyle(color: Colors.grey[600]),
                            ),
                          ],
                        ),
                      );
                    }
                    return _buildEmptyState();
                  }

                  return ListView.builder(
                    padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    itemCount: notifications.length,
                    itemBuilder: (context, index) {
                      final notification = notifications[index];
                      return _buildNotificationCard(notification, index);
                    },
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNotificationCard(NotificationModel notification, int index) {
    return Container(
      margin: EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 5,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: InkWell(
        onTap: () => _handleNotificationTap(notification),
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: EdgeInsets.all(16),
          child: Row(
            children: [
              // Icône avec cercle coloré
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  color: _getNotificationColor(notification).withOpacity(0.15),
                  borderRadius: BorderRadius.circular(25),
                ),
                child: Icon(
                  _getNotificationIcon(notification),
                  color: _getNotificationColor(notification),
                  size: 24,
                ),
              ),
              
              SizedBox(width: 16),
              
              // Contenu de la notification
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            notification.title,
                            style: TextStyle(
                              fontWeight: notification.isRead 
                                  ? FontWeight.w500 
                                  : FontWeight.bold,
                              fontSize: 16,
                              color: Colors.grey[800],
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        // Indicateur de statut de lecture
                        if (!notification.isRead)
                          Container(
                            padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: Colors.teal,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text(
                              'Non lu',
                              style: TextStyle(
                                fontSize: 10,
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          )
                        else
                          Row(
                            children: [
                              Icon(
                                Icons.check,
                                size: 16,
                                color: Colors.grey[400],
                              ),
                              SizedBox(width: 4),
                              Text(
                                'Lu',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.grey[400],
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                      ],
                    ),
                    
                    SizedBox(height: 4),
                    
                    Text(
                      notification.message,
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey[600],
                        height: 1.3,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    
                    SizedBox(height: 8),
                    
                    Row(
                      children: [
                        Text(
                          _formatTime(notification.timestamp),
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.grey[500],
                          ),
                        ),
                        Spacer(),
                        Text(
                          _formatDate(notification.timestamp),
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.grey[500],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Color _getNotificationColor(NotificationModel notification) {
    switch (notification.type.toLowerCase()) {
      case 'success':
      case 'word_added':
        return Colors.green;
      case 'warning':
      case 'sync':
        return Colors.orange;
      case 'error':
        return Colors.red;
      case 'info':
      case 'welcome':
        return Colors.blue;
      case 'quiz':
        return Colors.purple;
      case 'favorite':
        return Colors.pink;
      default:
        return Colors.teal;
    }
  }

  IconData _getNotificationIcon(NotificationModel notification) {
    switch (notification.type.toLowerCase()) {
      case 'success':
      case 'word_added':
        return Icons.check_circle;
      case 'warning':
        return Icons.warning;
      case 'sync':
        return Icons.sync;
      case 'error':
        return Icons.error;
      case 'info':
      case 'welcome':
        return Icons.info;
      case 'quiz':
        return Icons.quiz;
      case 'favorite':
        return Icons.favorite;
      default:
        return Icons.notifications;
    }
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              color: Colors.teal.withOpacity(0.1),
              borderRadius: BorderRadius.circular(40),
            ),
            child: Icon(
              Icons.notifications_none,
              size: 40,
              color: Colors.teal,
            ),
          ),
          SizedBox(height: 16),
          Text(
            'Aucune notification',
            style: TextStyle(
              fontSize: 18,
              color: Colors.grey[600],
              fontWeight: FontWeight.w500,
            ),
          ),
          SizedBox(height: 8),
          Text(
            'Les notifications apparaîtront ici',
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey[500],
            ),
          ),
        ],
      ),
    );
  }

  void _handleNotificationTap(NotificationModel notification) {
    print('🔔 Clic sur notification: ${notification.id} - isRead: ${notification.isRead}');
    
    // Marquer comme lu seulement quand on clique et si ce n'est pas déjà lu
    if (!notification.isRead) {
      print('📖 Marquage comme lu de la notification: ${notification.id}');
      NotificationService().markAsRead(notification.id);
      
      // Forcer la mise à jour de l'état local
      setState(() {});
    }
    
    // Afficher le dialogue de détail
    showDialog(
      context: context,
      builder: (context) => _buildNotificationDetailDialog(notification),
    );
  }

  Widget _buildNotificationDetailDialog(NotificationModel notification) {
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      contentPadding: EdgeInsets.zero,
      content: Container(
        width: MediaQuery.of(context).size.width * 0.85,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Header du dialogue
            Container(
              width: double.infinity,
              padding: EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: _getNotificationColor(notification),
                borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
              ),
              child: Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Icon(
                      _getNotificationIcon(notification),
                      color: Colors.white,
                      size: 20,
                    ),
                  ),
                  SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          notification.title,
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        Text(
                          _formatFullDateTime(notification.timestamp),
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.9),
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            
            // Contenu du dialogue
            Container(
              padding: EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (notification.message.isNotEmpty) ...[
                    Text(
                      'Message',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: Colors.grey[700],
                      ),
                    ),
                    SizedBox(height: 8),
                    Container(
                      width: double.infinity,
                      padding: EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.grey[50],
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: Colors.grey[200]!),
                      ),
                      child: Text(
                        notification.message,
                        style: TextStyle(
                          fontSize: 15,
                          color: Colors.grey[800],
                          height: 1.4,
                        ),
                      ),
                    ),
                    SizedBox(height: 16),
                  ],
                  
                  // Informations supplémentaires
                  Container(
                    padding: EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: _getNotificationColor(notification).withOpacity(0.05),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: _getNotificationColor(notification).withOpacity(0.2),
                      ),
                    ),
                    child: Column(
                      children: [
                        _buildInfoRow('Type', _getTypeDisplayName(notification.type)),
                        SizedBox(height: 8),
                        _buildInfoRow('Priorité', 
                          notification.priority == 'high' ? 'Élevée' : 
                          notification.priority == 'medium' ? 'Moyenne' : 'Normale'),
                        SizedBox(height: 8),
                        _buildInfoRow('Statut', notification.isRead ? 'Lu' : 'Non lu'),
                        if (notification.isHistorical) ...[
                          SizedBox(height: 8),
                          _buildInfoRow('Source', 'Historique'),
                        ],
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: Text(
            'Fermer',
            style: TextStyle(color: _getNotificationColor(notification)),
          ),
        ),
        if (!notification.isRead)
          ElevatedButton(
            onPressed: () {
              NotificationService().markAsRead(notification.id);
              Navigator.of(context).pop();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: _getNotificationColor(notification),
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            ),
            child: Text('Marquer comme lu'),
          ),
      ],
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Row(
      children: [
        Text(
          '$label:',
          style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w600,
            color: Colors.grey[600],
          ),
        ),
        SizedBox(width: 8),
        Expanded(
          child: Text(
            value,
            style: TextStyle(
              fontSize: 12,
              color: Colors.grey[800],
            ),
            textAlign: TextAlign.end,
          ),
        ),
      ],
    );
  }

  String _getTypeDisplayName(String type) {
    switch (type.toLowerCase()) {
      case 'success':
        return 'Succès';
      case 'word_added':
        return 'Mot ajouté';
      case 'warning':
        return 'Avertissement';
      case 'sync':
        return 'Synchronisation';
      case 'error':
        return 'Erreur';
      case 'info':
        return 'Information';
      case 'welcome':
        return 'Bienvenue';
      case 'quiz':
        return 'Quiz';
      case 'favorite':
        return 'Favori';
      default:
        return type.toUpperCase();
    }
  }

  String _formatFullDateTime(DateTime dateTime) {
    final months = [
      'janvier', 'février', 'mars', 'avril', 'mai', 'juin',
      'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'
    ];
    
    return '${dateTime.day} ${months[dateTime.month - 1]} ${dateTime.year} à ${dateTime.hour.toString().padLeft(2, '0')}:${dateTime.minute.toString().padLeft(2, '0')}';
  }

  String _formatTime(DateTime dateTime) {
    return '${dateTime.hour.toString().padLeft(2, '0')}:${dateTime.minute.toString().padLeft(2, '0')}';
  }

  String _formatDate(DateTime dateTime) {
    return '${dateTime.day.toString().padLeft(2, '0')}/${dateTime.month.toString().padLeft(2, '0')}/${dateTime.year}';
  }
}