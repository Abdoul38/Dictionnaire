import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class QuickActionsWidget extends StatefulWidget {
  final VoidCallback? onLearningPressed;
  final VoidCallback? onQuizPressed;
  final VoidCallback? onAddWordPressed;
  final VoidCallback? onReviewPressed;

  const QuickActionsWidget({
    Key? key,
    this.onLearningPressed,
    this.onQuizPressed,
    this.onAddWordPressed,
    this.onReviewPressed,
  }) : super(key: key);

  @override
  _QuickActionsWidgetState createState() => _QuickActionsWidgetState();
}

class _QuickActionsWidgetState extends State<QuickActionsWidget>
    with TickerProviderStateMixin {
  late AnimationController _slideController;
  late AnimationController _pulseController;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _pulseAnimation;
  
  int _lastTappedIndex = -1;

  @override
  void initState() {
    super.initState();
    _setupAnimations();
  }

  void _setupAnimations() {
    _slideController = AnimationController(
      duration: Duration(milliseconds: 800),
      vsync: this,
    );
    
    _pulseController = AnimationController(
      duration: Duration(milliseconds: 1000),
      vsync: this,
    );

    _slideAnimation = Tween<Offset>(
      begin: Offset(0, 0.5),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _slideController,
      curve: Curves.easeOutCubic,
    ));

    _pulseAnimation = Tween<double>(
      begin: 1.0,
      end: 1.1,
    ).animate(CurvedAnimation(
      parent: _pulseController,
      curve: Curves.easeInOut,
    ));

    _slideController.forward();
    _pulseController.repeat(reverse: true);
  }

  @override
  void dispose() {
    _slideController.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  void _onActionTapped(int index, VoidCallback? callback) {
    setState(() {
      _lastTappedIndex = index;
    });
    
    HapticFeedback.mediumImpact();
    
    // Animation d'échelle
    final controller = AnimationController(
      duration: Duration(milliseconds: 150),
      vsync: this,
    );
    
    final scaleAnimation = Tween<double>(
      begin: 1.0,
      end: 0.95,
    ).animate(CurvedAnimation(
      parent: controller,
      curve: Curves.easeInOut,
    ));

    controller.forward().then((_) {
      controller.reverse().then((_) {
        controller.dispose();
        callback?.call();
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return SlideTransition(
      position: _slideAnimation,
      child: Container(
        margin: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSectionHeader(),
            SizedBox(height: 12),
            _buildActionsGrid(),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionHeader() {
    return Row(
      children: [
        Container(
          padding: EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Colors.teal.withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(
            Icons.flash_on,
            color: Colors.teal,
            size: 20,
          ),
        ),
        SizedBox(width: 8),
        Text(
          'Actions rapides',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.grey[800],
          ),
        ),
        Spacer(),
        AnimatedBuilder(
          animation: _pulseAnimation,
          builder: (context, child) {
            return Transform.scale(
              scale: _pulseAnimation.value,
              child: Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  color: Colors.green,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.green.withOpacity(0.3),
                      blurRadius: 4,
                      spreadRadius: 1,
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _buildActionsGrid() {
    return Row(
      children: [
        Expanded(
          child: _buildActionCard(
            0,
            'Apprentissage',
            'Mode guidé',
            Icons.school,
            Colors.purple,
            widget.onLearningPressed,
          ),
        ),
        SizedBox(width: 12),
        Expanded(
          child: _buildActionCard(
            1,
            'Quiz',
            'Testez-vous',
            Icons.quiz,
            Colors.green,
            widget.onQuizPressed,
          ),
        ),
        SizedBox(width: 12),
        Expanded(
          child: _buildActionCard(
            2,
            'Révision',
            'Mots difficiles',
            Icons.refresh,
            Colors.orange,
            widget.onReviewPressed,
          ),
        ),
        SizedBox(width: 12),
        Expanded(
          child: _buildActionCard(
            3,
            'Ajouter',
            'Nouveau mot',
            Icons.add_circle,
            Colors.blue,
            widget.onAddWordPressed,
          ),
        ),
      ],
    );
  }

  Widget _buildActionCard(
    int index,
    String title,
    String subtitle,
    IconData icon,
    Color color,
    VoidCallback? onTap,
  ) {
    bool isRecentlyTapped = _lastTappedIndex == index;
    
    return AnimatedContainer(
      duration: Duration(milliseconds: 300),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap != null ? () => _onActionTapped(index, onTap) : null,
          borderRadius: BorderRadius.circular(16),
          child: AnimatedContainer(
            duration: Duration(milliseconds: 200),
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  color.withOpacity(0.1),
                  color.withOpacity(0.05),
                ],
              ),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: isRecentlyTapped 
                    ? color.withOpacity(0.8)
                    : color.withOpacity(0.3),
                width: isRecentlyTapped ? 2 : 1,
              ),
              boxShadow: isRecentlyTapped ? [
                BoxShadow(
                  color: color.withOpacity(0.3),
                  blurRadius: 12,
                  offset: Offset(0, 4),
                ),
              ] : [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 8,
                  offset: Offset(0, 2),
                ),
              ],
            ),
            child: Column(
              children: [
                Container(
                  padding: EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    icon,
                    color: color,
                    size: 24,
                  ),
                ),
                SizedBox(height: 12),
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: color,
                  ),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 4),
                Text(
                  subtitle,
                  style: TextStyle(
                    fontSize: 11,
                    color: Colors.grey[600],
                    fontWeight: FontWeight.w500,
                  ),
                  textAlign: TextAlign.center,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// Widget alternatif avec style horizontal
class HorizontalQuickActionsWidget extends StatelessWidget {
  final VoidCallback? onLearningPressed;
  final VoidCallback? onQuizPressed;
  final VoidCallback? onAddWordPressed;
  final VoidCallback? onReviewPressed;

  const HorizontalQuickActionsWidget({
    Key? key,
    this.onLearningPressed,
    this.onQuizPressed,
    this.onAddWordPressed,
    this.onReviewPressed,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 100,
      margin: EdgeInsets.symmetric(vertical: 8),
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: EdgeInsets.symmetric(horizontal: 16),
        children: [
          _buildHorizontalActionCard(
            'Apprentissage guidé',
            Icons.school,
            Colors.purple,
            onLearningPressed,
          ),
          SizedBox(width: 12),
          _buildHorizontalActionCard(
            'Quiz interactif',
            Icons.quiz,
            Colors.green,
            onQuizPressed,
          ),
          SizedBox(width: 12),
          _buildHorizontalActionCard(
            'Révision rapide',
            Icons.refresh,
            Colors.orange,
            onReviewPressed,
          ),
          SizedBox(width: 12),
          _buildHorizontalActionCard(
            'Ajouter un mot',
            Icons.add_circle,
            Colors.blue,
            onAddWordPressed,
          ),
        ],
      ),
    );
  }

  Widget _buildHorizontalActionCard(
    String title,
    IconData icon,
    Color color,
    VoidCallback? onTap,
  ) {
    return Container(
      width: 120,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          child: Container(
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: color.withOpacity(0.3),
              ),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  icon,
                  color: color,
                  size: 28,
                ),
                SizedBox(height: 8),
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: color,
                  ),
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}