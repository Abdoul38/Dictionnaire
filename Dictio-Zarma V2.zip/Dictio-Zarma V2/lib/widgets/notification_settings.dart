import 'package:flutter/material.dart';
import '../models/notification_model.dart';

class NotificationSettings extends StatefulWidget {
  @override
  _NotificationSettingsState createState() => _NotificationSettingsState();
}

class _NotificationSettingsState extends State<NotificationSettings> {
  bool _enableNotifications = true;
  bool _soundEnabled = true;
  bool _vibrationEnabled = true;
  String _selectedSound = 'default';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Paramètres des notifications'),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
      ),
      body: ListView(
        padding: EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Notifications générales',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 16),
                  SwitchListTile(
                    title: Text('Activer les notifications'),
                    subtitle: Text('Recevoir les notifications du serveur'),
                    value: _enableNotifications,
                    onChanged: (value) {
                      setState(() {
                        _enableNotifications = value;
                      });
                    },
                    activeColor: Colors.teal,
                  ),
                  if (_enableNotifications) ...[
                    SwitchListTile(
                      title: Text('Son'),
                      subtitle: Text('Jouer un son pour les notifications'),
                      value: _soundEnabled,
                      onChanged: (value) {
                        setState(() {
                          _soundEnabled = value;
                        });
                      },
                      activeColor: Colors.teal,
                    ),
                    SwitchListTile(
                      title: Text('Vibration'),
                      subtitle: Text('Vibrer pour les notifications importantes'),
                      value: _vibrationEnabled,
                      onChanged: (value) {
                        setState(() {
                          _vibrationEnabled = value;
                        });
                      },
                      activeColor: Colors.teal,
                    ),
                  ]
                ],
              ),
            ),
          ),
          
          SizedBox(height: 16),
          
          Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Types de notifications',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 16),
                  _buildNotificationTypeCard(
                    'Informations',
                    'Notifications générales et informatives',
                    Icons.info,
                    Colors.blue,
                    true,
                  ),
                  _buildNotificationTypeCard(
                    'Succès',
                    'Confirmations d\'actions réussies',
                    Icons.check_circle,
                    Colors.green,
                    true,
                  ),
                  _buildNotificationTypeCard(
                    'Avertissements',
                    'Alertes importantes à surveiller',
                    Icons.warning,
                    Colors.orange,
                    true,
                  ),
                  _buildNotificationTypeCard(
                    'Erreurs',
                    'Problèmes nécessitant votre attention',
                    Icons.error,
                    Colors.red,
                    true,
                  ),
                ],
              ),
            ),
          ),
          
          SizedBox(height: 16),
          
          Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Actions',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 16),
                  ListTile(
                    leading: Icon(Icons.delete_sweep, color: Colors.red),
                    title: Text('Effacer toutes les notifications'),
                    subtitle: Text('Supprimer toutes les notifications lues'),
                    onTap: () {
                      _showClearNotificationsDialog();
                    },
                  ),
                  ListTile(
                    leading: Icon(Icons.refresh, color: Colors.teal),
                    title: Text('Tester les notifications'),
                    subtitle: Text('Envoyer une notification de test'),
                    onTap: () {
                      _sendTestNotification();
                    },
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNotificationTypeCard(
    String title,
    String subtitle,
    IconData icon,
    Color color,
    bool enabled,
  ) {
    return ListTile(
      leading: Icon(icon, color: color),
      title: Text(title),
      subtitle: Text(subtitle),
      trailing: Switch(
        value: enabled,
        onChanged: (value) {
          // Gérer l'activation/désactivation par type
        },
        activeColor: Colors.teal,
      ),
    );
  }

  void _showClearNotificationsDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Effacer les notifications'),
        content: Text(
          'Êtes-vous sûr de vouloir supprimer toutes les notifications lues ?'
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Annuler'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              // Implémenter la suppression des notifications lues
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Notifications supprimées')),
              );
            },
            child: Text('Supprimer', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  void _sendTestNotification() {
    // Créer une notification de test
    final testNotification = NotificationModel(
      id: 'test_${DateTime.now().millisecondsSinceEpoch}',
      title: 'Notification de test',
      message: 'Ceci est une notification de test pour vérifier le système',
      type: 'info',
      priority: 'normal',
      target: 'all',
      timestamp: DateTime.now(),
      expiresAt: DateTime.now().add(Duration(hours: 24)),
    );

    // Ajouter la notification au service (simulation)
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Notification de test envoyée'),
        backgroundColor: Colors.teal,
      ),
    );
  }
}