import 'package:flutter/material.dart';
import '../models/historiquerecherche.dart';
import '../data/database_helper.dart';

class SearchHistoryWidget extends StatefulWidget {
  final Function(String) onSearchSelected;
  final Function() onClearHistory;
  final String currentQuery;
  final VoidCallback? onClose;

  const SearchHistoryWidget({
    Key? key,
    required this.onSearchSelected,
    required this.onClearHistory,
    this.currentQuery = '',
    this.onClose,
  }) : super(key: key);

  @override
  _SearchHistoryWidgetState createState() => _SearchHistoryWidgetState();
}

class _SearchHistoryWidgetState extends State<SearchHistoryWidget>
    with AutomaticKeepAliveClientMixin {
  final CacheDatabaseHelper _cacheHelper = CacheDatabaseHelper();
  final ScrollController _scrollController = ScrollController();
  
  List<SearchHistoryItem> _history = [];
  List<SearchHistoryItem> _popularSearches = [];
  bool _isLoading = true;
  String? _error;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _loadHistory() async {
    if (!mounted) return;
    
    setState(() {
      _isLoading = true;
      _error = null;
    });
    
    try {
      final history = await _cacheHelper.getSearchHistory();
      final popular = await _cacheHelper.getPopularSearches();
      
      if (!mounted) return;
      
      setState(() {
        _history = history;
        _popularSearches = popular;
        _isLoading = false;
      });
    } catch (e) {
      print('Erreur chargement historique: $e');
      if (!mounted) return;
      
      setState(() {
        _error = 'Erreur lors du chargement de l\'historique';
        _isLoading = false;
      });
    }
  }

  Future<void> _removeItem(int id) async {
    try {
      await _cacheHelper.removeFromSearchHistory(id);
      // Mise à jour optimiste de l'UI
      setState(() {
        _history.removeWhere((item) => item.id == id);
      });
    } catch (e) {
      print('Erreur suppression historique: $e');
      // En cas d'erreur, recharger les données
      _loadHistory();
      _showErrorSnackBar('Erreur lors de la suppression');
    }
  }

  Future<void> _clearAllHistory() async {
    try {
      await _cacheHelper.clearSearchHistory();
      widget.onClearHistory();
      setState(() {
        _history.clear();
      });
    } catch (e) {
      print('Erreur effacement historique: $e');
      _showErrorSnackBar('Erreur lors de l\'effacement');
    }
  }

  void _showErrorSnackBar(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
        duration: Duration(seconds: 2),
      ),
    );
  }

  Widget _buildLoadingState() {
    return Container(
      height: 200,
      padding: EdgeInsets.all(16),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Colors.teal),
            ),
            SizedBox(height: 16),
            Text(
              'Chargement de l\'historique...',
              style: TextStyle(
                color: Colors.grey[600],
                fontSize: 14,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildErrorState() {
    return Container(
      height: 200,
      padding: EdgeInsets.all(32),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.error_outline,
            size: 48,
            color: Colors.red[300],
          ),
          SizedBox(height: 16),
          Text(
            _error ?? 'Une erreur est survenue',
            style: TextStyle(
              fontSize: 14,
              color: Colors.red[600],
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 16),
          ElevatedButton(
            onPressed: _loadHistory,
            child: Text('Réessayer'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.teal,
              foregroundColor: Colors.white,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border(
          bottom: BorderSide(
            color: Colors.grey[200]!,
            width: 1,
          ),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            'Recherches',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: Colors.teal,
            ),
          ),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (_history.isNotEmpty)
                TextButton.icon(
                  onPressed: _clearAllHistory,
                  icon: Icon(Icons.clear_all, size: 12),
                  label: Text('Effacer tout'),
                  style: TextButton.styleFrom(
                    foregroundColor: Colors.red[600],
                  ),
                ),
              if (widget.onClose != null)
                IconButton(
                  icon: Icon(Icons.close),
                  onPressed: widget.onClose,
                  tooltip: 'Fermer',
                ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildPopularSearches() {
    if (_popularSearches.isEmpty) return SizedBox.shrink();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
          child: Text(
            'Recherches populaires',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: Colors.grey[700],
            ),
          ),
        ),
        Container(
          height: 40,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            padding: EdgeInsets.symmetric(horizontal: 16),
            itemCount: _popularSearches.length,
            itemBuilder: (context, index) {
              final item = _popularSearches[index];
              return Container(
                margin: EdgeInsets.only(right: 8),
                child: ActionChip(
                  label: Text(
                    '${item.query} (${item.searchCount})',
                    style: TextStyle(fontSize: 12),
                  ),
                  onPressed: () => widget.onSearchSelected(item.query),
                  backgroundColor: Colors.blue.withOpacity(0.1),
                  pressElevation: 2,
                ),
              );
            },
          ),
        ),
      ],
    );
  }

 Widget _buildHistoryList() {
  if (_history.isEmpty) {
    return Container(
      // SUPPRIMER toute contrainte de hauteur fixe
      padding: EdgeInsets.only(top: 32, left: 16, right: 16),
      alignment: Alignment.topCenter, // Forcer l'alignement en haut
      child: Column(
        mainAxisSize: MainAxisSize.min, // Important: taille minimale
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Icon(
            Icons.search_off,
            size: 64,
            color: Colors.grey[400],
          ),
          SizedBox(height: 16),
          Text(
            'Aucun historique de recherche',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w500,
              color: Colors.grey[600],
            ),
          ),
          SizedBox(height: 8),
          Text(
            'Vos recherches récentes apparaîtront ici',
            style: TextStyle(
              fontSize: 12,
              color: Colors.grey[500],
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  // Le reste du code pour quand il y a un historique...


    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
          child: Text(
            'Récent',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: Colors.grey[700],
            ),
          ),
        ),
        ListView.builder(
          shrinkWrap: true,
          physics: NeverScrollableScrollPhysics(),
          itemCount: _history.length,
          itemBuilder: (context, index) {
            final item = _history[index];
            final isCurrentQuery = item.query == widget.currentQuery;
            
            return Container(
              margin: EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: isCurrentQuery ? Colors.teal.withOpacity(0.1) : null,
                borderRadius: BorderRadius.circular(8),
              ),
              child: ListTile(
                leading: Icon(
                  Icons.history,
                  color: isCurrentQuery ? Colors.teal : Colors.grey,
                ),
                title: Text(
                  item.query,
                  style: TextStyle(
                    fontWeight: isCurrentQuery ? FontWeight.w600 : FontWeight.w500,
                    color: isCurrentQuery ? Colors.teal[700] : null,
                  ),
                ),
                subtitle: Text(
                  '${item.resultsCount} résultat${item.resultsCount > 1 ? 's' : ''} • ${item.timeAgo}',
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey[600],
                  ),
                ),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (item.searchCount > 1)
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: Colors.orange.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          '${item.searchCount}x',
                          style: TextStyle(
                            fontSize: 10,
                            color: Colors.orange[800],
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    SizedBox(width: 8),
                    InkWell(
                      onTap: () => _removeItem(item.id),
                      borderRadius: BorderRadius.circular(16),
                      child: Padding(
                        padding: EdgeInsets.all(4),
                        child: Icon(
                          Icons.close,
                          color: Colors.grey[400],
                          size: 18,
                        ),
                      ),
                    ),
                  ],
                ),
                onTap: () => widget.onSearchSelected(item.query),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            );
          },
        ),
      ],
    );
  }

 @override
Widget build(BuildContext context) {
  super.build(context);
  
  if (_error != null) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start, // Déjà correct
      children: [
        SizedBox(height: MediaQuery.of(context).padding.top),
        _buildErrorState(),
      ],
    );
  }

  if (_isLoading) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start, // Déjà correct
      children: [
        SizedBox(height: MediaQuery.of(context).padding.top),
        _buildLoadingState(),
      ],
    );
  }

  return Column(
    mainAxisAlignment: MainAxisAlignment.start,
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      SizedBox(height: MediaQuery.of(context).padding.top),
      // MODIFIER ICI: Supprimer les contraintes de hauteur maximales
      Container(
        width: double.infinity,
        // SUPPRIMER: constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.8),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(bottom: Radius.circular(16)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.15),
              blurRadius: 10,
              offset: Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min, // Important: taille minimale
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildHeader(),
            Flexible(
              child: Scrollbar(
                controller: _scrollController,
                child: SingleChildScrollView(
                  controller: _scrollController,
                  physics: BouncingScrollPhysics(),
                  child: Column(
                    mainAxisSize: MainAxisSize.min, // Important
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildPopularSearches(),
                      _buildHistoryList(),
                      SizedBox(height: 16),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    ],
  );
}
}