class FavoriteModel {
  final int? id;
  final int wordId;
  final DateTime? createdAt;

  FavoriteModel({
    this.id,
    required this.wordId,
    this.createdAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'word_id': wordId,
      'created_at': createdAt?.millisecondsSinceEpoch ?? DateTime.now().millisecondsSinceEpoch,
    };
  }

  static FavoriteModel fromMap(Map<String, dynamic> map) {
    return FavoriteModel(
      id: map['id'],
      wordId: map['word_id'],
      createdAt: map['created_at'] != null 
          ? DateTime.fromMillisecondsSinceEpoch(map['created_at']) 
          : null,
    );
  }

  FavoriteModel copyWith({
    int? id,
    int? wordId,
    DateTime? createdAt,
  }) {
    return FavoriteModel(
      id: id ?? this.id,
      wordId: wordId ?? this.wordId,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  @override
  String toString() {
    return 'FavoriteModel{id: $id, wordId: $wordId, createdAt: $createdAt}';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is FavoriteModel &&
        other.id == id &&
        other.wordId == wordId;
  }

  @override
  int get hashCode => id.hashCode ^ wordId.hashCode;
}