class SearchHistoryItem {
  final int id;
  final String query;
  final int searchCount;
  final DateTime lastSearched;
  final int resultsCount;
  final DateTime createdAt;

  SearchHistoryItem({
    required this.id,
    required this.query,
    required this.searchCount,
    required this.lastSearched,
    required this.resultsCount,
    required this.createdAt,
  });

  factory SearchHistoryItem.fromMap(Map<String, dynamic> map) {
    return SearchHistoryItem(
      id: map['id'] as int,
      query: map['query'] as String,
      searchCount: map['search_count'] as int,
      lastSearched: DateTime.fromMillisecondsSinceEpoch((map['last_searched'] as int) * 1000),
      resultsCount: map['results_count'] as int,
      createdAt: DateTime.fromMillisecondsSinceEpoch((map['created_at'] as int) * 1000),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'query': query,
      'search_count': searchCount,
      'last_searched': lastSearched.millisecondsSinceEpoch ~/ 1000,
      'results_count': resultsCount,
      'created_at': createdAt.millisecondsSinceEpoch ~/ 1000,
    };
  }

  String get timeAgo {
    final now = DateTime.now();
    final difference = now.difference(lastSearched);
    
    if (difference.inDays > 0) {
      return 'Il y a ${difference.inDays} jour${difference.inDays > 1 ? 's' : ''}';
    } else if (difference.inHours > 0) {
      return 'Il y a ${difference.inHours} heure${difference.inHours > 1 ? 's' : ''}';
    } else if (difference.inMinutes > 0) {
      return 'Il y a ${difference.inMinutes} minute${difference.inMinutes > 1 ? 's' : ''}';
    } else {
      return 'À l\'instant';
    }
  }
  }