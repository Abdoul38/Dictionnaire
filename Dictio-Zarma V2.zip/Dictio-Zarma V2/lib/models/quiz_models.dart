// Modèles de données pour le système de quiz et exercices zarma
import 'package:flutter/material.dart';
class WordModel {
  final String zarmaWord;
  final String frenchMeaning;
  final String zarmaExample;
  final String frenchExample;
  final String? pronunciation;
  final String? etymology;
  final String? audioPath;
  final List<String>? synonyms;
  final List<String>? antonyms;
  final bool hasAudio;

  WordModel({
    required this.zarmaWord,
    required this.frenchMeaning,
    required this.zarmaExample,
    required this.frenchExample,
    this.pronunciation,
    this.etymology,
    this.audioPath,
    this.synonyms,
    this.antonyms,
    this.hasAudio = false,
  });
}

class QuizData {
  final String id;
  final String title;
  final String description;
  final String difficulty;
  final String category;
  final List<QuizQuestion> questions;
  final int timeLimit; // en secondes par question
  final Color primaryColor;

  QuizData({
    required this.id,
    required this.title,
    required this.description,
    required this.difficulty,
    required this.category,
    required this.questions,
    this.timeLimit = 30,
    this.primaryColor = Colors.teal,
  });
}

class QuizQuestion {
  final String id;
  final String question;
  final List<String> options;
  final int correct;
  final String explanation;
  final String? audioPath;
  final String? imageUrl;
  final QuestionType type;

  QuizQuestion({
    required this.id,
    required this.question,
    required this.options,
    required this.correct,
    required this.explanation,
    this.audioPath,
    this.imageUrl,
    this.type = QuestionType.multipleChoice,
  });
}

enum QuestionType {
  multipleChoice,
  trueFalse,
  fillInBlank,
  matching,
  pronunciation,
}

class QuizResult {
  final String quizId;
  final int score;
  final int totalQuestions;
  final int timeSpent; // en secondes
  final DateTime completedAt;
  final List<UserAnswer> userAnswers;

  QuizResult({
    required this.quizId,
    required this.score,
    required this.totalQuestions,
    required this.timeSpent,
    required this.completedAt,
    required this.userAnswers,
  });

  double get percentage => (score / totalQuestions) * 100;
  
  String get grade {
    if (percentage >= 90) return 'A+';
    if (percentage >= 80) return 'A';
    if (percentage >= 70) return 'B';
    if (percentage >= 60) return 'C';
    if (percentage >= 50) return 'D';
    return 'F';
  }
}

class UserAnswer {
  final String questionId;
  final int? selectedOptionIndex;
  final String? textAnswer;
  final bool isCorrect;
  final int timeSpent;

  UserAnswer({
    required this.questionId,
    this.selectedOptionIndex,
    this.textAnswer,
    required this.isCorrect,
    required this.timeSpent,
  });
}

class PracticeExercise {
  final String id;
  final String title;
  final String description;
  final ExerciseType type;
  final List<ExerciseItem> items;
  final Color primaryColor;

  PracticeExercise({
    required this.id,
    required this.title,
    required this.description,
    required this.type,
    required this.items,
    this.primaryColor = Colors.orange,
  });
}

enum ExerciseType {
  pronunciation,
  translation,
  listening,
  writing,
  conversation,
}

class ExerciseItem {
  final String id;
  final String zarmaText;
  final String frenchText;
  final String? tip;
  final String? audioPath;
  final String? imageUrl;
  final Map<String, dynamic>? metadata;

  ExerciseItem({
    required this.id,
    required this.zarmaText,
    required this.frenchText,
    this.tip,
    this.audioPath,
    this.imageUrl,
    this.metadata,
  });
}

class UserProgress {
  final String userId;
  final Map<String, QuizResult> quizResults;
  final Map<String, ExerciseProgress> exerciseProgress;
  final int totalWordsLearned;
  final int streakDays;
  final DateTime lastActivityDate;

  UserProgress({
    required this.userId,
    required this.quizResults,
    required this.exerciseProgress,
    required this.totalWordsLearned,
    required this.streakDays,
    required this.lastActivityDate,
  });

  double get overallProgress {
    if (quizResults.isEmpty) return 0.0;
    
    double totalPercentage = 0.0;
    quizResults.values.forEach((result) {
      totalPercentage += result.percentage;
    });
    
    return totalPercentage / quizResults.length;
  }
}

class ExerciseProgress {
  final String exerciseId;
  final int completedItems;
  final int totalItems;
  final DateTime lastCompletedAt;
  final int totalTimeSpent;

  ExerciseProgress({
    required this.exerciseId,
    required this.completedItems,
    required this.totalItems,
    required this.lastCompletedAt,
    required this.totalTimeSpent,
  });

  double get progressPercentage => (completedItems / totalItems) * 100;
  bool get isCompleted => completedItems >= totalItems;
}

// Classe utilitaire pour les données statiques
class QuizDataRepository {
  static List<QuizData> getAllQuizzes() {
    return [
      _getLanguageVocabularyQuiz(),
      _getLanguageGrammarQuiz(),
      _getHistoryOriginsQuiz(),
      _getCultureTraditionsQuiz(),
    ];
  }

  static List<PracticeExercise> getAllExercises() {
    return [
      _getPronunciationExercise(),
      _getTranslationExercise(),
      _getListeningExercise(),
    ];
  }

  static QuizData _getLanguageVocabularyQuiz() {
    return QuizData(
      id: 'lang_vocab',
      title: 'Vocabulaire de base',
      description: 'Mots essentiels du quotidien en zarma',
      difficulty: 'Débutant',
      category: 'Langue',
      primaryColor: Colors.green,
      questions: [
        QuizQuestion(
          id: 'vocab_1',
          question: 'Comment dit-on "bonjour" en zarma ?',
          options: ['Fofo', 'Mate ni', 'Bani', 'Salam'],
          correct: 1,
          explanation: '"Mate ni" est la salutation standard en zarma, utilisée tout au long de la journée.',
          audioPath: 'assets/audio/mate_ni.mp3',
        ),
        QuizQuestion(
          id: 'vocab_2',
          question: 'Que signifie "bani" en français ?',
          options: ['Au revoir', 'Merci', 'S\'il vous plaît', 'Pardon'],
          correct: 0,
          explanation: '"Bani" signifie "au revoir" et est utilisé lors des séparations.',
          audioPath: 'assets/audio/bani.mp3',
        ),
        QuizQuestion(
          id: 'vocab_3',
          question: 'Comment dit-on "eau" en zarma ?',
          options: ['Habu', 'Hari', 'Hinka', 'Hawsa'],
          correct: 1,
          explanation: '"Hari" est le mot zarma pour "eau", un mot fondamental dans cette région semi-aride.',
          audioPath: 'assets/audio/hari.mp3',
        ),
        QuizQuestion(
          id: 'vocab_4',
          question: 'Que signifie "fofo" ?',
          options: ['Père', 'Mère', 'Enfant', 'Grand-père'],
          correct: 0,
          explanation: '"Fofo" désigne le père dans la famille zarma.',
          audioPath: 'assets/audio/fofo.mp3',
        ),
        QuizQuestion(
          id: 'vocab_5',
          question: 'Comment dit-on "maison" en zarma ?',
          options: ['Windi', 'Goro', 'Koira', 'Bani'],
          correct: 1,
          explanation: '"Goro" signifie "maison" ou "habitation" en zarma.',
          audioPath: 'assets/audio/goro.mp3',
        ),
      ],
    );
  }

  static QuizData _getLanguageGrammarQuiz() {
    return QuizData(
      id: 'lang_grammar',
      title: 'Grammaire zarma',
      description: 'Structure et règles grammaticales',
      difficulty: 'Intermédiaire',
      category: 'Langue',
      primaryColor: Colors.blue,
      questions: [
        QuizQuestion(
          id: 'grammar_1',
          question: 'Quelle est la structure de phrase de base en zarma ?',
          options: ['Sujet-Verbe-Objet', 'Verbe-Sujet-Objet', 'Objet-Verbe-Sujet', 'Sujet-Objet-Verbe'],
          correct: 3,
          explanation: 'Le zarma suit généralement l\'ordre Sujet-Objet-Verbe, différent du français.',
        ),
        QuizQuestion(
          id: 'grammar_2',
          question: 'Comment forme-t-on le pluriel en zarma ?',
          options: ['Ajout de -s', 'Ajout de -yan', 'Changement de ton', 'Redoublement'],
          correct: 1,
          explanation: 'Le pluriel se forme souvent par l\'ajout du suffixe \'-yan\' au nom singulier.',
        ),
        QuizQuestion(
          id: 'grammar_3',
          question: 'Quel est le pronom personnel pour "je/moi" ?',
          options: ['Ay', 'A', 'Ir', 'War'],
          correct: 0,
          explanation: '"Ay" est le pronom de première personne du singulier en zarma.',
        ),
        QuizQuestion(
          id: 'grammar_4',
          question: 'Comment exprime-t-on la négation en zarma ?',
          options: ['Particule "si"', 'Particule "mana"', 'Particule "boro"', 'Changement tonal'],
          correct: 1,
          explanation: 'La négation s\'exprime avec la particule "mana" placée après le verbe.',
        ),
      ],
    );
  }

  static QuizData _getHistoryOriginsQuiz() {
    return QuizData(
      id: 'hist_origins',
      title: 'Origines du peuple zarma',
      description: 'Les débuts de l\'histoire zarma',
      difficulty: 'Intermédiaire',
      category: 'Histoire',
      primaryColor: Colors.purple,
      questions: [
        QuizQuestion(
          id: 'hist_1',
          question: 'D\'où viennent originellement les Zarma selon la tradition ?',
          options: ['Mali', 'Burkina Faso', 'Lac Tchad', 'Vallée du Nil'],
          correct: 0,
          explanation: 'Selon la tradition orale, les Zarma auraient migré depuis la région de l\'empire du Mali.',
        ),
        QuizQuestion(
          id: 'hist_2',
          question: 'Vers quelle période les Zarma se sont-ils installés dans la vallée du Niger ?',
          options: ['XIe siècle', 'XIVe siècle', 'XVIe siècle', 'XVIIIe siècle'],
          correct: 1,
          explanation: 'Les migrations zarma vers la vallée du Niger dateraient principalement du XIVe siècle.',
        ),
        QuizQuestion(
          id: 'hist_3',
          question: 'Quel groupe ethnique était présent avant l\'arrivée des Zarma ?',
          options: ['Haoussa', 'Songhaï', 'Fulani', 'Touareg'],
          correct: 1,
          explanation: 'Les Songhaï étaient déjà établis dans la région avant l\'arrivée des Zarma.',
        ),
      ],
    );
  }

  static QuizData _getCultureTraditionsQuiz() {
    return QuizData(
      id: 'cult_traditions',
      title: 'Culture et traditions',
      description: 'Expressions culturelles zarma',
      difficulty: 'Avancé',
      category: 'Culture',
      primaryColor: Colors.orange,
      questions: [
        QuizQuestion(
          id: 'cult_1',
          question: 'Que signifie l\'expression "Zarma ni goy" ?',
          options: ['Bonjour zarma', 'C\'est du zarma', 'Nous sommes zarma', 'Pays zarma'],
          correct: 2,
          explanation: 'Cette expression affirme l\'identité zarma et se traduit par "Nous sommes zarma".',
        ),
        QuizQuestion(
          id: 'cult_2',
          question: 'Quel instrument accompagne traditionnellement les récits zarma ?',
          options: ['Djembé', 'Molo', 'Gourde', 'Flûte'],
          correct: 1,
          explanation: 'Le "molo" (luth à cordes) accompagne traditionnellement les griots zarma.',
        ),
      ],
    );
  }

  static PracticeExercise _getPronunciationExercise() {
    return PracticeExercise(
      id: 'pronunciation',
      title: 'Exercice de prononciation',
      description: 'Entraînez-vous à prononcer correctement',
      type: ExerciseType.pronunciation,
      primaryColor: Colors.purple,
      items: [
        ExerciseItem(
          id: 'pron_1',
          zarmaText: 'mate ni',
          frenchText: 'bonjour',
          tip: 'Accent sur la première syllabe - MA-te ni',
          audioPath: 'assets/audio/mate_ni.mp3',
        ),
        ExerciseItem(
          id: 'pron_2',
          zarmaText: 'bani',
          frenchText: 'au revoir',
          tip: 'Voyelles courtes et nettes - BA-ni',
          audioPath: 'assets/audio/bani.mp3',
        ),
        ExerciseItem(
          id: 'pron_3',
          zarmaText: 'fofo',
          frenchText: 'père',
          tip: 'Double consonne expressive - FO-fo',
          audioPath: 'assets/audio/fofo.mp3',
        ),
        ExerciseItem(
          id: 'pron_4',
          zarmaText: 'nda kala',
          frenchText: 'salut respectueux',
          tip: 'Liaison fluide entre les mots - nda-KA-la',
          audioPath: 'assets/audio/nda_kala.mp3',
        ),
        ExerciseItem(
          id: 'pron_5',
          zarmaText: 'hari',
          frenchText: 'eau',
          tip: 'R roulé légèrement - HA-ri',
          audioPath: 'assets/audio/hari.mp3',
        ),
        ExerciseItem(
          id: 'pron_6',
          zarmaText: 'goro',
          frenchText: 'maison',
          tip: 'O bien ouvert - GO-ro',
          audioPath: 'assets/audio/goro.mp3',
        ),
      ],
    );
  }

  static PracticeExercise _getTranslationExercise() {
    return PracticeExercise(
      id: 'translation',
      title: 'Exercice de traduction',
      description: 'Traduisez ces phrases courantes',
      type: ExerciseType.translation,
      primaryColor: Colors.orange,
      items: [
        ExerciseItem(
          id: 'trans_1',
          zarmaText: 'Ay goo kayna',
          frenchText: 'Je vais au marché',
          audioPath: 'assets/audio/ay_goo_kayna.mp3',
        ),
        ExerciseItem(
          id: 'trans_2',
          zarmaText: 'Hari kulu',
          frenchText: 'Beaucoup d\'eau',
          audioPath: 'assets/audio/hari_kulu.mp3',
        ),
        ExerciseItem(
          id: 'trans_3',
          zarmaText: 'Boro too wey',
          frenchText: 'Une personne est venue',
          audioPath: 'assets/audio/boro_too_wey.mp3',
        ),
        ExerciseItem(
          id: 'trans_4',
          zarmaText: 'Goro ga boori',
          frenchText: 'La maison est grande',
          audioPath: 'assets/audio/goro_ga_boori.mp3',
        ),
        ExerciseItem(
          id: 'trans_5',
          zarmaText: 'Fofo ga caw',
          frenchText: 'Papa mange',
          audioPath: 'assets/audio/fofo_ga_caw.mp3',
        ),
        ExerciseItem(
          id: 'trans_6',
          zarmaText: 'Ay si mate ni',
          frenchText: 'Je dis bonjour',
          audioPath: 'assets/audio/ay_si_mate_ni.mp3',
        ),
      ],
    );
  }

  static PracticeExercise _getListeningExercise() {
    return PracticeExercise(
      id: 'listening',
      title: 'Exercice d\'écoute',
      description: 'Écoutez et identifiez les mots',
      type: ExerciseType.listening,
      primaryColor: Colors.teal,
      items: [
        ExerciseItem(
          id: 'listen_1',
          zarmaText: 'Ni baani?',
          frenchText: 'Comment allez-vous ?',
          tip: 'Expression courante de politesse',
          audioPath: 'assets/audio/ni_baani.mp3',
        ),
        ExerciseItem(
          id: 'listen_2',
          zarmaText: 'Salam aleykum',
          frenchText: 'Paix sur vous (salut islamique)',
          tip: 'Salutation religieuse courante',
          audioPath: 'assets/audio/salam_aleykum.mp3',
        ),
      ],
    );
  }
}