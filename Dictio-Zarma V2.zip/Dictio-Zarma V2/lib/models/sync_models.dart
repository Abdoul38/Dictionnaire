class SyncStatus {
  final bool isConnected;
  final bool canConnectToServer;
  final bool needsSync;
  final int pendingUploads;
  final String statusMessage;

  SyncStatus({
    required this.isConnected,
    required this.canConnectToServer,
    required this.needsSync,
    required this.pendingUploads,
    required this.statusMessage,
  });

  @override
  String toString() {
    return 'SyncStatus(connected: $isConnected, server: $canConnectToServer, needsSync: $needsSync, pending: $pendingUploads)';
  }
}