// Enhanced WordModel avec nouvelles propriétés
class WordModel {
  final int? id;
  final String zarmaWord;
  final String zarmaExample;
  final String frenchMeaning;
  final String frenchExample;
  final String? category;
  final String? pronunciation;
  final int difficultyLevel;
  final String? etymology;
  final List<String> synonyms;
  final List<String> antonyms;
  final List<String> relatedWords;
  final int usageFrequency;
  final String? audioPath;
  final String? imagePath;
  
  // Ajoutez ces champs pour la base de données
  final bool isFavorite;
  final bool isLearned;
  final int viewCount;
  final int practiceCount;

  WordModel({
    this.id,
    required this.zarmaWord,
    required this.zarmaExample,
    required this.frenchMeaning,
    required this.frenchExample,
    this.category,
    this.pronunciation,
    this.difficultyLevel = 1,
    this.etymology,
    this.synonyms = const [],
    this.antonyms = const [],
    this.relatedWords = const [],
    this.usageFrequency = 0,
    this.audioPath,
    this.imagePath,
    // Valeurs par défaut pour les nouveaux champs
    this.isFavorite = false,
    this.isLearned = false,
    this.viewCount = 0,
    this.practiceCount = 0,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'zarma_word': zarmaWord,
      'zarma_example': zarmaExample,
      'french_meaning': frenchMeaning,
      'french_example': frenchExample,
      'category': category,
      'pronunciation': pronunciation,
      'difficulty_level': difficultyLevel,
      'etymology': etymology,
      'synonyms': synonyms.join(','),
      'antonyms': antonyms.join(','),
      'related_words': relatedWords.join(','),
      'usage_frequency': usageFrequency,
      'audio_path': audioPath,
      'image_path': imagePath,
     
    };
  }

static List<String> _parseCommaSeparated(dynamic value) {
  if (value == null) return [];
  
  if (value is List) {
    return value.cast<String>().where((s) => s.trim().isNotEmpty).toList();
  }
  
  if (value is String) {
    if (value.isEmpty) return [];
    // Supporter à la fois ',' et '|' comme séparateurs
    String separator = value.contains('|') ? '|' : ',';
    return value.split(separator)
      .map((s) => s.trim())
      .where((s) => s.isNotEmpty)
      .toList();
  }
  
  return [];
}

// 2. Correction dans fromMap pour les timestamps
static WordModel fromMap(Map<String, dynamic> map) {
  return WordModel(
    id: map['id'],
    zarmaWord: map['zarma_word'] ?? '',
    zarmaExample: map['zarma_example'] ?? '',
    frenchMeaning: map['french_meaning'] ?? '',
    frenchExample: map['french_example'] ?? '',
    category: map['category'],
    pronunciation: map['pronunciation'],
    difficultyLevel: map['difficulty_level'] ?? 1,
    etymology: map['etymology'],
    synonyms: _parseCommaSeparated(map['synonyms']),
    antonyms: _parseCommaSeparated(map['antonyms']),
    relatedWords: _parseCommaSeparated(map['related_words']),
    usageFrequency: map['usage_frequency'] ?? 0,
    audioPath: map['audio_path'],
    imagePath: map['image_path'],
    // CORRECTION: Gestion unifiée des timestamps
   
  );
}
  WordModel copyWith({
    int? id,
    String? zarmaWord,
    String? zarmaExample,
    String? frenchMeaning,
    String? frenchExample,
    String? category,
    String? pronunciation,
    int? difficultyLevel,
    String? etymology,
    List<String>? synonyms,
    List<String>? antonyms,
    List<String>? relatedWords,
    int? usageFrequency,
    String? audioPath,
    String? imagePath,
    
  }) {
    return WordModel(
      id: id ?? this.id,
      zarmaWord: zarmaWord ?? this.zarmaWord,
      zarmaExample: zarmaExample ?? this.zarmaExample,
      frenchMeaning: frenchMeaning ?? this.frenchMeaning,
      frenchExample: frenchExample ?? this.frenchExample,
      category: category ?? this.category,
      pronunciation: pronunciation ?? this.pronunciation,
      difficultyLevel: difficultyLevel ?? this.difficultyLevel,
      etymology: etymology ?? this.etymology,
      synonyms: synonyms ?? this.synonyms,
      antonyms: antonyms ?? this.antonyms,
      relatedWords: relatedWords ?? this.relatedWords,
      usageFrequency: usageFrequency ?? this.usageFrequency,
      audioPath: audioPath ?? this.audioPath,
      imagePath: imagePath ?? this.imagePath,
    );
  }

  // Méthodes utilitaires
  // Méthodes utilitaires
  bool get hasAudio => audioPath != null && audioPath!.isNotEmpty;
  bool get hasImage => imagePath != null && imagePath!.isNotEmpty;
  bool get hasPronunciation => pronunciation != null && pronunciation!.isNotEmpty;
  bool get hasEtymology => etymology != null && etymology!.isNotEmpty;
  bool get hasSynonyms => synonyms.isNotEmpty;
  bool get hasAntonyms => antonyms.isNotEmpty;
  bool get hasRelatedWords => relatedWords.isNotEmpty;
  
  String get difficultyText {
    switch (difficultyLevel) {
      case 1: return 'Débutant';
      case 2: return 'Intermédiaire';
      case 3: return 'Avancé';
      case 4: return 'Expert';
      default: return 'Inconnu';
    }
  }

  @override
  String toString() {
    return 'WordModel(id: $id, zarmaWord: $zarmaWord, frenchMeaning: $frenchMeaning)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is WordModel && other.id == id;
  }

  @override
  int get hashCode => id.hashCode;
}

// Modèle pour les progrès d'apprentissage
class LearningProgressModel {
  final int? id;
  final int wordId;
  final int viewCount;
  final int practiceCount;
  final int correctAnswers;
  final int wrongAnswers;
  final bool isLearned;
  final DateTime? lastPracticed;
  final int learningStreak;
  final double difficultyAdjustment;
  

  LearningProgressModel({
    this.id,
    required this.wordId,
    this.viewCount = 0,
    this.practiceCount = 0,
    this.correctAnswers = 0,
    this.wrongAnswers = 0,
    this.isLearned = false,
    this.lastPracticed,
    this.learningStreak = 0,
    this.difficultyAdjustment = 1.0,
    
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'word_id': wordId,
      'view_count': viewCount,
      'practice_count': practiceCount,
      'correct_answers': correctAnswers,
      'wrong_answers': wrongAnswers,
      'is_learned': isLearned ? 1 : 0,
      'last_practiced': lastPracticed?.millisecondsSinceEpoch,
      'learning_streak': learningStreak,
      'difficulty_adjustment': difficultyAdjustment,
      
    };
  }

  static LearningProgressModel fromMap(Map<String, dynamic> map) {
    return LearningProgressModel(
      id: map['id'],
      wordId: map['word_id'],
      viewCount: map['view_count'] ?? 0,
      practiceCount: map['practice_count'] ?? 0,
      correctAnswers: map['correct_answers'] ?? 0,
      wrongAnswers: map['wrong_answers'] ?? 0,
      isLearned: (map['is_learned'] ?? 0) == 1,
      lastPracticed: map['last_practiced'] != null 
          ? DateTime.fromMillisecondsSinceEpoch(map['last_practiced'])
          : null,
      learningStreak: map['learning_streak'] ?? 0,
      difficultyAdjustment: map['difficulty_adjustment']?.toDouble() ?? 1.0,
      
    );
  }

  // Méthodes utilitaires
  double get accuracyRate {
    if (practiceCount == 0) return 0.0;
    return correctAnswers / practiceCount;
  }

  int get totalPracticeAttempts => correctAnswers + wrongAnswers;

  bool get needsReview {
    if (!isLearned && practiceCount > 0) {
      return accuracyRate < 0.7 || learningStreak < 3;
    }
    return false;
  }

  String get proficiencyLevel {
    if (isLearned) return 'Maîtrisé';
    if (accuracyRate >= 0.8 && learningStreak >= 5) return 'Bien acquis';
    if (accuracyRate >= 0.6 && practiceCount >= 3) return 'En cours d\'apprentissage';
    if (practiceCount > 0) return 'Débutant';
    return 'Pas encore étudié';
  }

  LearningProgressModel copyWith({
    int? id,
    int? wordId,
    int? viewCount,
    int? practiceCount,
    int? correctAnswers,
    int? wrongAnswers,
    bool? isLearned,
    DateTime? lastPracticed,
    int? learningStreak,
    double? difficultyAdjustment,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return LearningProgressModel(
      id: id ?? this.id,
      wordId: wordId ?? this.wordId,
      viewCount: viewCount ?? this.viewCount,
      practiceCount: practiceCount ?? this.practiceCount,
      correctAnswers: correctAnswers ?? this.correctAnswers,
      wrongAnswers: wrongAnswers ?? this.wrongAnswers,
      isLearned: isLearned ?? this.isLearned,
      lastPracticed: lastPracticed ?? this.lastPracticed,
      learningStreak: learningStreak ?? this.learningStreak,
      difficultyAdjustment: difficultyAdjustment ?? this.difficultyAdjustment,
      
    );
  }
}

// Modèle pour les favoris
class FavoriteModel {
  final int? id;
  final int wordId;
  final DateTime createdAt;

  FavoriteModel({
    this.id,
    required this.wordId,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'word_id': wordId,
      'created_at': createdAt.millisecondsSinceEpoch ~/ 1000,
    };
  }

  static FavoriteModel fromMap(Map<String, dynamic> map) {
    return FavoriteModel(
      id: map['id'],
      wordId: map['word_id'],
      createdAt: DateTime.fromMillisecondsSinceEpoch(map['created_at'] * 1000),
    );
  }
}

// Modèle pour les notes utilisateur
class UserNoteModel {
  final int? id;
  final int wordId;
  final String noteText;
  final List<String> tags;
  final DateTime createdAt;
  final DateTime updatedAt;

  UserNoteModel({
    this.id,
    required this.wordId,
    required this.noteText,
    this.tags = const [],
    DateTime? createdAt,
    DateTime? updatedAt,
  }) : createdAt = createdAt ?? DateTime.now(),
       updatedAt = updatedAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'word_id': wordId,
      'note_text': noteText,
      'tags': tags.join(','),
      'created_at': createdAt.millisecondsSinceEpoch ~/ 1000,
      'updated_at': updatedAt.millisecondsSinceEpoch ~/ 1000,
    };
  }

  static UserNoteModel fromMap(Map<String, dynamic> map) {
    return UserNoteModel(
      id: map['id'],
      wordId: map['word_id'],
      noteText: map['note_text'] ?? '',
      tags: _parseCommaSeparated(map['tags']),
      createdAt: DateTime.fromMillisecondsSinceEpoch(map['created_at'] * 1000),
      updatedAt: DateTime.fromMillisecondsSinceEpoch(map['updated_at'] * 1000),
    );
  }

  static List<String> _parseCommaSeparated(String? value) {
    if (value == null || value.isEmpty) return [];
    return value.split(',').where((s) => s.isNotEmpty).toList();
  }

  UserNoteModel copyWith({
    int? id,
    int? wordId,
    String? noteText,
    List<String>? tags,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return UserNoteModel(
      id: id ?? this.id,
      wordId: wordId ?? this.wordId,
      noteText: noteText ?? this.noteText,
      tags: tags ?? this.tags,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}

// Modèle pour les sessions de quiz
class QuizSessionModel {
  final int? id;
  final int totalQuestions;
  final int correctAnswers;
  final int wrongAnswers;
  final double score;
  final int duration; // en secondes
  final String? category;
  final int? difficultyLevel;
  final DateTime createdAt;

  QuizSessionModel({
    this.id,
    required this.totalQuestions,
    required this.correctAnswers,
    required this.wrongAnswers,
    required this.score,
    required this.duration,
    this.category,
    this.difficultyLevel,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'total_questions': totalQuestions,
      'correct_answers': correctAnswers,
      'wrong_answers': wrongAnswers,
      'score': score,
      'duration': duration,
      'category': category,
      'difficulty_level': difficultyLevel,
      'created_at': createdAt.millisecondsSinceEpoch ~/ 1000,
    };
  }

  static QuizSessionModel fromMap(Map<String, dynamic> map) {
    return QuizSessionModel(
      id: map['id'],
      totalQuestions: map['total_questions'],
      correctAnswers: map['correct_answers'],
      wrongAnswers: map['wrong_answers'],
      score: map['score']?.toDouble() ?? 0.0,
      duration: map['duration'],
      category: map['category'],
      difficultyLevel: map['difficulty_level'],
      createdAt: DateTime.fromMillisecondsSinceEpoch(map['created_at'] * 1000),
    );
  }

  // Méthodes utilitaires
  double get accuracyPercentage => (correctAnswers / totalQuestions) * 100;
  
  String get formattedDuration {
    int minutes = duration ~/ 60;
    int seconds = duration % 60;
    return '${minutes}m ${seconds}s';
  }

  String get performanceLevel {
    if (score >= 90) return 'Excellent';
    if (score >= 80) return 'Très bien';
    if (score >= 70) return 'Bien';
    if (score >= 60) return 'Passable';
    return 'À améliorer';
  }
}

// Modèle pour les détails de quiz
class QuizDetailModel {
  final int? id;
  final int quizSessionId;
  final int wordId;
  final String questionType;
  final bool isCorrect;
  final int? responseTime; // en millisecondes
  final DateTime createdAt;

  QuizDetailModel({
    this.id,
    required this.quizSessionId,
    required this.wordId,
    required this.questionType,
    required this.isCorrect,
    this.responseTime,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'quiz_session_id': quizSessionId,
      'word_id': wordId,
      'question_type': questionType,
      'is_correct': isCorrect ? 1 : 0,
      'response_time': responseTime,
      'created_at': createdAt.millisecondsSinceEpoch ~/ 1000,
    };
  }

  static QuizDetailModel fromMap(Map<String, dynamic> map) {
    return QuizDetailModel(
      id: map['id'],
      quizSessionId: map['quiz_session_id'],
      wordId: map['word_id'],
      questionType: map['question_type'],
      isCorrect: (map['is_correct'] ?? 0) == 1,
      responseTime: map['response_time'],
      createdAt: DateTime.fromMillisecondsSinceEpoch(map['created_at'] * 1000),
    );
  }
}

// Modèle pour les statistiques d'utilisation
class UsageStatsModel {
  final int? id;
  final DateTime date;
  final int wordsStudied;
  final int timeSpent; // en minutes
  final int quizCompleted;
  final int newWordsLearned;
  final DateTime createdAt;

  UsageStatsModel({
    this.id,
    required this.date,
    this.wordsStudied = 0,
    this.timeSpent = 0,
    this.quizCompleted = 0,
    this.newWordsLearned = 0,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'date': date.toIso8601String().split('T')[0],
      'words_studied': wordsStudied,
      'time_spent': timeSpent,
      'quiz_completed': quizCompleted,
      'new_words_learned': newWordsLearned,
      'created_at': createdAt.millisecondsSinceEpoch ~/ 1000,
    };
  }

  static UsageStatsModel fromMap(Map<String, dynamic> map) {
    return UsageStatsModel(
      id: map['id'],
      date: DateTime.parse(map['date']),
      wordsStudied: map['words_studied'] ?? 0,
      timeSpent: map['time_spent'] ?? 0,
      quizCompleted: map['quiz_completed'] ?? 0,
      newWordsLearned: map['new_words_learned'] ?? 0,
      createdAt: DateTime.fromMillisecondsSinceEpoch(map['created_at'] * 1000),
    );
  }

  // Méthodes utilitaires
  String get formattedTimeSpent {
    if (timeSpent < 60) return '${timeSpent}min';
    int hours = timeSpent ~/ 60;
    int minutes = timeSpent % 60;
    return '${hours}h ${minutes}min';
  }

  bool get isToday {
    final today = DateTime.now();
    return date.year == today.year && 
           date.month == today.month && 
           date.day == today.day;
  }

  UsageStatsModel copyWith({
    int? id,
    DateTime? date,
    int? wordsStudied,
    int? timeSpent,
    int? quizCompleted,
    int? newWordsLearned,
    DateTime? createdAt,
  }) {
    return UsageStatsModel(
      id: id ?? this.id,
      date: date ?? this.date,
      wordsStudied: wordsStudied ?? this.wordsStudied,
      timeSpent: timeSpent ?? this.timeSpent,
      quizCompleted: quizCompleted ?? this.quizCompleted,
      newWordsLearned: newWordsLearned ?? this.newWordsLearned,
      createdAt: createdAt ?? this.createdAt,
    );
  }
}

// Modèle pour les catégories avec statistiques
class CategoryModel {
  final String name;
  final String displayName;
  final int wordCount;
  final int learnedWords;
  final String? description;
  final String? icon;

  CategoryModel({
    required this.name,
    required this.displayName,
    required this.wordCount,
    this.learnedWords = 0,
    this.description,
    this.icon,
  });

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'display_name': displayName,
      'word_count': wordCount,
      'learned_words': learnedWords,
      'description': description,
      'icon': icon,
    };
  }

  static CategoryModel fromMap(Map<String, dynamic> map) {
    return CategoryModel(
      name: map['name'],
      displayName: map['display_name'] ?? map['name'],
      wordCount: map['word_count'] ?? 0,
      learnedWords: map['learned_words'] ?? 0,
      description: map['description'],
      icon: map['icon'],
    );
  }

  // Méthodes utilitaires
  double get progressPercentage {
    if (wordCount == 0) return 0.0;
    return (learnedWords / wordCount) * 100;
  }

  String get progressText => '$learnedWords/$wordCount mots appris';

  bool get isCompleted => learnedWords >= wordCount && wordCount > 0;

  CategoryModel copyWith({
    String? name,
    String? displayName,
    int? wordCount,
    int? learnedWords,
    String? description,
    String? icon,
  }) {
    return CategoryModel(
      name: name ?? this.name,
      displayName: displayName ?? this.displayName,
      wordCount: wordCount ?? this.wordCount,
      learnedWords: learnedWords ?? this.learnedWords,
      description: description ?? this.description,
      icon: icon ?? this.icon,
    );
  }
}

// Enums pour les types de questions de quiz
enum QuestionType {
  zarmaToFrench,
  frenchToZarma,
  multipleChoice,
  fillInTheBlank,
  listening,
  pronunciation,
}

extension QuestionTypeExtension on QuestionType {
  String get displayName {
    switch (this) {
      case QuestionType.zarmaToFrench:
        return 'Zarma vers Français';
      case QuestionType.frenchToZarma:
        return 'Français vers Zarma';
      case QuestionType.multipleChoice:
        return 'Choix multiples';
      case QuestionType.fillInTheBlank:
        return 'Remplir les blancs';
      case QuestionType.listening:
        return 'Écoute';
      case QuestionType.pronunciation:
        return 'Prononciation';
    }
  }

  String get code {
    switch (this) {
      case QuestionType.zarmaToFrench:
        return 'z2f';
      case QuestionType.frenchToZarma:
        return 'f2z';
      case QuestionType.multipleChoice:
        return 'mc';
      case QuestionType.fillInTheBlank:
        return 'fib';
      case QuestionType.listening:
        return 'listen';
      case QuestionType.pronunciation:
        return 'pronounce';
    }
  }

  static QuestionType fromCode(String code) {
    switch (code) {
      case 'z2f':
        return QuestionType.zarmaToFrench;
      case 'f2z':
        return QuestionType.frenchToZarma;
      case 'mc':
        return QuestionType.multipleChoice;
      case 'fib':
        return QuestionType.fillInTheBlank;
      case 'listen':
        return QuestionType.listening;
      case 'pronounce':
        return QuestionType.pronunciation;
      default:
        return QuestionType.multipleChoice;
    }
  }
}

// Modèle pour les paramètres de l'application
class AppSettingsModel {
  final bool darkMode;
  final bool soundEnabled;
  final bool hapticFeedback;
  final bool autoPlayAudio;
  final int dailyGoal;
  final String language;
  final int reminderHour;
  final bool reminderEnabled;
  final double textSize;
  final bool offlineMode;

  AppSettingsModel({
    this.darkMode = false,
    this.soundEnabled = true,
    this.hapticFeedback = true,
    this.autoPlayAudio = false,
    this.dailyGoal = 10,
    this.language = 'fr',
    this.reminderHour = 19,
    this.reminderEnabled = true,
    this.textSize = 1.0,
    this.offlineMode = true,
  });

  Map<String, dynamic> toMap() {
    return {
      'dark_mode': darkMode ? 1 : 0,
      'sound_enabled': soundEnabled ? 1 : 0,
      'haptic_feedback': hapticFeedback ? 1 : 0,
      'auto_play_audio': autoPlayAudio ? 1 : 0,
      'daily_goal': dailyGoal,
      'language': language,
      'reminder_hour': reminderHour,
      'reminder_enabled': reminderEnabled ? 1 : 0,
      'text_size': textSize,
      'offline_mode': offlineMode ? 1 : 0,
    };
  }

  static AppSettingsModel fromMap(Map<String, dynamic> map) {
    return AppSettingsModel(
      darkMode: (map['dark_mode'] ?? 0) == 1,
      soundEnabled: (map['sound_enabled'] ?? 1) == 1,
      hapticFeedback: (map['haptic_feedback'] ?? 1) == 1,
      autoPlayAudio: (map['auto_play_audio'] ?? 0) == 1,
      dailyGoal: map['daily_goal'] ?? 10,
      language: map['language'] ?? 'fr',
      reminderHour: map['reminder_hour'] ?? 19,
      reminderEnabled: (map['reminder_enabled'] ?? 1) == 1,
      textSize: map['text_size']?.toDouble() ?? 1.0,
      offlineMode: (map['offline_mode'] ?? 1) == 1,
    );
  }

  AppSettingsModel copyWith({
    bool? darkMode,
    bool? soundEnabled,
    bool? hapticFeedback,
    bool? autoPlayAudio,
    int? dailyGoal,
    String? language,
    int? reminderHour,
    bool? reminderEnabled,
    double? textSize,
    bool? offlineMode,
  }) {
    return AppSettingsModel(
      darkMode: darkMode ?? this.darkMode,
      soundEnabled: soundEnabled ?? this.soundEnabled,
      hapticFeedback: hapticFeedback ?? this.hapticFeedback,
      autoPlayAudio: autoPlayAudio ?? this.autoPlayAudio,
      dailyGoal: dailyGoal ?? this.dailyGoal,
      language: language ?? this.language,
      reminderHour: reminderHour ?? this.reminderHour,
      reminderEnabled: reminderEnabled ?? this.reminderEnabled,
      textSize: textSize ?? this.textSize,
      offlineMode: offlineMode ?? this.offlineMode,
    );
  }
}