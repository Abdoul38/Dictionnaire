import 'package:flutter/material.dart';

class NotificationModel {
  final String id;
  final String title;
  final String message;
  final String type;
  final String priority;
  final bool isRead;
  final String target;
  final String? createdBy;
  final DateTime timestamp;
  final DateTime expiresAt;
  final bool isHistorical;

  NotificationModel({
    required this.id,
    required this.title,
    this.isRead = false,
    required this.message,
    required this.type,
    required this.priority,
    required this.target,
    this.createdBy,
    required this.timestamp,
    required this.expiresAt,
    this.isHistorical = false,
  });

  // CORRECTION : Améliorer le parsing JSON
  factory NotificationModel.fromJson(Map<String, dynamic> json) {
  print('🔍 Parsing notification JSON: ${json['title']} - ${json['message']}');
  
  try {
    // Fonction pour parser les timestamps
    DateTime parseTimestamp(dynamic value) {
      if (value == null) {
        print('⚠️ Timestamp null, utilisation de maintenant');
        return DateTime.now();
      }
      
      int timestamp = 0;
      if (value is int) {
        timestamp = value;
      } else if (value is String) {
        timestamp = int.tryParse(value) ?? 0;
      }
      
      // Si le timestamp semble être en millisecondes (> 1 trillion)
      if (timestamp > 1000000000000) {
        return DateTime.fromMillisecondsSinceEpoch(timestamp);
      }
      // Sinon c'est probablement en secondes
      return DateTime.fromMillisecondsSinceEpoch(timestamp * 1000);
    }

    final notification = NotificationModel(
      id: json['id']?.toString() ?? '',
      title: json['title']?.toString() ?? 'Notification',
      message: json['message']?.toString() ?? '',
      type: json['type']?.toString() ?? 'info',
      priority: json['priority']?.toString() ?? 'normal',
      target: json['target']?.toString() ?? 'all',
      createdBy: json['createdBy']?.toString() ?? json['created_by']?.toString(),
      timestamp: parseTimestamp(json['timestamp'] ?? json['created_at']),
      expiresAt: parseTimestamp(json['expiresAt'] ?? json['expires_at'] ?? json['expires_at_ms']),
      isHistorical: json['isHistorical'] == true,
      isRead: json['isRead'] ?? false,
    );

    print('✅ Notification parsée avec succès: "${notification.title}" - "${notification.message}"');
    print('📅 Créée: ${notification.timestamp}, Expire: ${notification.expiresAt}');
    
    return notification;
    
  } catch (e, stackTrace) {
    print('❌ Erreur parsing notification: $e');
    print('📄 JSON: $json');
    print('🔍 Stack trace: $stackTrace');
    
    // Retourner une notification par défaut en cas d'erreur
    return NotificationModel(
      id: json['id']?.toString() ?? DateTime.now().millisecondsSinceEpoch.toString(),
      title: json['title']?.toString() ?? 'Notification',
      message: json['message']?.toString() ?? 'Contenu non disponible',
      type: 'info',
      priority: 'normal',
      target: 'all',
      timestamp: DateTime.now(),
      expiresAt: DateTime.now().add(Duration(days: 1)),
    );
  }
}


  // Getter pour vérifier si la notification est expirée
  bool get isExpired {
    return DateTime.now().isAfter(expiresAt);
  }

  // Getter pour la couleur selon le type
  Color get typeColor {
    switch (type.toLowerCase()) {
      case 'success':
        return Colors.green;
      case 'warning':
        return Colors.orange;
      case 'error':
        return Colors.red;
      case 'update':
        return Colors.blue;
      case 'feature':
        return Colors.purple;
      default:
        return Colors.teal;
    }
  }

  // Getter pour l'icône selon le type
  IconData get typeIcon {
    switch (type.toLowerCase()) {
      case 'success':
        return Icons.check_circle;
      case 'warning':
        return Icons.warning;
      case 'error':
        return Icons.error;
      case 'update':
        return Icons.system_update;
      case 'feature':
        return Icons.new_releases;
      default:
        return Icons.info;
    }
  }

  // Getter pour le niveau de priorité
  int get priorityLevel {
    switch (priority.toLowerCase()) {
      case 'urgent':
        return 3;
      case 'high':
        return 2;
      case 'normal':
      default:
        return 1;
    }
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'message': message,
      'type': type,
      'priority': priority,
      'target': target,
      'isRead': isRead,
      'createdBy': createdBy,
      'timestamp': timestamp.millisecondsSinceEpoch,
      'expiresAt': expiresAt.millisecondsSinceEpoch,
      'isHistorical': isHistorical,
    };
  }

  NotificationModel copyWith({
    String? id,
    String? title,
    String? message,
    String? type,
    String? priority,
    String? target,
    String? createdBy,
    DateTime? timestamp,
    DateTime? expiresAt,
    bool? isHistorical,
    bool? isRead,
  }) {
    return NotificationModel(
      id: id ?? this.id,
      title: title ?? this.title,
      message: message ?? this.message,
      type: type ?? this.type,
      priority: priority ?? this.priority,
      target: target ?? this.target,
      isRead: isRead ?? this.isRead,
      createdBy: createdBy ?? this.createdBy,
      timestamp: timestamp ?? this.timestamp,
      expiresAt: expiresAt ?? this.expiresAt,
      isHistorical: isHistorical ?? this.isHistorical,
    );
  }
}
