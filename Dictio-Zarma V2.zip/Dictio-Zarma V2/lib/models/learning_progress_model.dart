class LearningProgressModel {
  final int? id;
  final int wordId;
  final int viewCount;
  final int practiceCount;
  final int correctAnswers;
  final int wrongAnswers;
  final bool isLearned;
  final DateTime? lastPracticed;
  final int learningStreak;
  final double difficultyAdjustment;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  LearningProgressModel({
    this.id,
    required this.wordId,
    this.viewCount = 0,
    this.practiceCount = 0,
    this.correctAnswers = 0,
    this.wrongAnswers = 0,
    this.isLearned = false,
    this.lastPracticed,
    this.learningStreak = 0,
    this.difficultyAdjustment = 1.0,
    this.createdAt,
    this.updatedAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'word_id': wordId,
      'view_count': viewCount,
      'practice_count': practiceCount,
      'correct_answers': correctAnswers,
      'wrong_answers': wrongAnswers,
      'is_learned': isLearned ? 1 : 0,
      'last_practiced': lastPracticed?.millisecondsSinceEpoch,
      'learning_streak': learningStreak,
      'difficulty_adjustment': difficultyAdjustment,
      'created_at': createdAt?.millisecondsSinceEpoch ?? DateTime.now().millisecondsSinceEpoch,
      'updated_at': updatedAt?.millisecondsSinceEpoch ?? DateTime.now().millisecondsSinceEpoch,
    };
  }

  static LearningProgressModel fromMap(Map<String, dynamic> map) {
    return LearningProgressModel(
      id: map['id'],
      wordId: map['word_id'],
      viewCount: map['view_count'] ?? 0,
      practiceCount: map['practice_count'] ?? 0,
      correctAnswers: map['correct_answers'] ?? 0,
      wrongAnswers: map['wrong_answers'] ?? 0,
      isLearned: (map['is_learned'] ?? 0) == 1,
      lastPracticed: map['last_practiced'] != null 
          ? DateTime.fromMillisecondsSinceEpoch(map['last_practiced']) 
          : null,
      learningStreak: map['learning_streak'] ?? 0,
      difficultyAdjustment: map['difficulty_adjustment']?.toDouble() ?? 1.0,
      createdAt: map['created_at'] != null 
          ? DateTime.fromMillisecondsSinceEpoch(map['created_at']) 
          : null,
      updatedAt: map['updated_at'] != null 
          ? DateTime.fromMillisecondsSinceEpoch(map['updated_at']) 
          : null,
    );
  }

  // Méthodes utilitaires
  double get successRate {
    int totalAttempts = correctAnswers + wrongAnswers;
    if (totalAttempts == 0) return 0.0;
    return correctAnswers / totalAttempts;
  }

  String get proficiencyLevel {
    if (!isLearned && practiceCount < 3) return 'Débutant';
    if (successRate >= 0.8 && learningStreak >= 5) return 'Maîtrisé';
    if (successRate >= 0.6 && practiceCount >= 5) return 'Intermédiaire';
    if (successRate >= 0.4) return 'En apprentissage';
    return 'À réviser';
  }

  bool get needsReview {
    if (practiceCount == 0) return false;
    if (successRate < 0.5) return true;
    if (lastPracticed != null) {
      int daysSinceLastPractice = DateTime.now().difference(lastPracticed!).inDays;
      return daysSinceLastPractice > (learningStreak > 10 ? 30 : 7);
    }
    return false;
  }

  LearningProgressModel copyWith({
    int? id,
    int? wordId,
    int? viewCount,
    int? practiceCount,
    int? correctAnswers,
    int? wrongAnswers,
    bool? isLearned,
    DateTime? lastPracticed,
    int? learningStreak,
    double? difficultyAdjustment,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return LearningProgressModel(
      id: id ?? this.id,
      wordId: wordId ?? this.wordId,
      viewCount: viewCount ?? this.viewCount,
      practiceCount: practiceCount ?? this.practiceCount,
      correctAnswers: correctAnswers ?? this.correctAnswers,
      wrongAnswers: wrongAnswers ?? this.wrongAnswers,
      isLearned: isLearned ?? this.isLearned,
      lastPracticed: lastPracticed ?? this.lastPracticed,
      learningStreak: learningStreak ?? this.learningStreak,
      difficultyAdjustment: difficultyAdjustment ?? this.difficultyAdjustment,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  @override
  String toString() {
    return 'LearningProgressModel{id: $id, wordId: $wordId, successRate: ${successRate.toStringAsFixed(2)}, proficiencyLevel: $proficiencyLevel}';
  }
}