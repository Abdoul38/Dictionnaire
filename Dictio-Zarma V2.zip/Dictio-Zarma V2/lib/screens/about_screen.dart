// lib/screens/about_screen.dart
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:share_plus/share_plus.dart';
import 'package:package_info_plus/package_info_plus.dart';

class AboutScreen extends StatefulWidget {
  @override
  _AboutScreenState createState() => _AboutScreenState();
}

class _AboutScreenState extends State<AboutScreen> with TickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  String _appVersion = '';

  @override
  void initState() {
    super.initState();
    _setupAnimations();
    _getAppVersion();
  }

  void _setupAnimations() {
    _animationController = AnimationController(
      duration: Duration(milliseconds: 1000),
      vsync: this,
    );
    _fadeAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    );
    _animationController.forward();
  }

  Future<void> _getAppVersion() async {
    try {
      PackageInfo packageInfo = await PackageInfo.fromPlatform();
      setState(() {
        _appVersion = '${packageInfo.version} (${packageInfo.buildNumber})';
      });
    } catch (e) {
      setState(() {
        _appVersion = '1.0.0';
      });
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        title: Text('À propos'),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: FadeTransition(
        opacity: _fadeAnimation,
        child: SingleChildScrollView(
          padding: EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildAppInfo(),
              SizedBox(height: 24),
              _buildFeaturesSection(),
              SizedBox(height: 24),
              _buildDeveloperSection(),
              SizedBox(height: 24),
              _buildSocialLinks(),
              SizedBox(height: 24),
              _buildSupportSection(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAppInfo() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Container(
        padding: EdgeInsets.all(24),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Colors.teal.shade50, Colors.teal.shade100],
          ),
        ),
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.teal,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Icon(
                Icons.book,
                size: 48,
                color: Colors.white,
              ),
            ),
            SizedBox(height: 16),
            Text(
              'Dictionnaire Zarma',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                color: Colors.teal.shade800,
              ),
            ),
            SizedBox(height: 8),
            Text(
              'Version $_appVersion',
              style: TextStyle(
                fontSize: 16,
                color: Colors.teal.shade600,
                fontWeight: FontWeight.w500,
              ),
            ),
            SizedBox(height: 16),
            Text(
              'Application mobile pour apprendre et consulter le dictionnaire Zarma-Français avec synchronisation en ligne.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey[700],
                height: 1.5,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFeaturesSection() {
    return _buildSection(
      'Fonctionnalités',
      Icons.star,
      Colors.orange,
      Column(
        children: [
          _buildFeatureItem(
            Icons.translate,
            'Dictionnaire Bilingue',
            'Plus de 2000 mots zarma avec traductions françaises et exemples d\'usage',
          ),
          _buildFeatureItem(
            Icons.sync,
            'Synchronisation Automatique',
            'Mise à jour automatique de la base de données depuis le serveur',
          ),
          _buildFeatureItem(
            Icons.favorite,
            'Gestion des Favoris',
            'Sauvegardez vos mots préférés pour un accès rapide',
          ),
          _buildFeatureItem(
            Icons.search,
            'Recherche Avancée',
            'Recherchez par mot zarma, français ou dans les exemples',
          ),
          _buildFeatureItem(
            Icons.category,
            'Filtrage par Catégorie',
            'Organisez les mots par catégories grammaticales',
          ),
          _buildFeatureItem(
            Icons.offline_bolt,
            'Mode Hors Ligne',
            'Accédez au dictionnaire même sans connexion internet',
          ),
          _buildFeatureItem(
            Icons.volume_up,
            'Prononciation Audio',
            'Écoutez la prononciation correcte des mots zarma',
          ),
          _buildFeatureItem(
            Icons.quiz,
            'Système d\'Apprentissage',
            'Suivez vos progrès et apprenez efficacement',
          ),
        ],
      ),
    );
  }

  Widget _buildFeatureItem(IconData icon, String title, String description) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.teal.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: Colors.teal, size: 20),
          ),
          SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey[800],
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  description,
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.grey[600],
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDeveloperSection() {
    return _buildSection(
      'Développeur',
      Icons.person,
      Colors.blue,
      Column(
        children: [
          CircleAvatar(
            radius: 50,
            backgroundColor: Colors.blue.shade100,
            child: Icon(
              Icons.person,
              size: 60,
              color: Colors.blue,
            ),
          ),
          SizedBox(height: 16),
          Text(
            'HAMADOU MOUMOUNI Abdou',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.grey[800],
            ),
          ),
          SizedBox(height: 8),
          Text(
            'Développeur Mobile & Web',
            style: TextStyle(
              fontSize: 16,
              color: Colors.blue,
              fontWeight: FontWeight.w500,
            ),
          ),
          SizedBox(height: 16),
          Text(
            'Passionné par le développement d\'applications mobiles et la préservation des langues locales. Spécialisé en Flutter, React et Node.js.',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey[600],
              height: 1.5,
            ),
          ),
          SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.location_on, color: Colors.grey[500], size: 16),
              SizedBox(width: 4),
              Text(
                'Niamey, Niger', // Remplacez par votre localisation
                style: TextStyle(color: Colors.grey[600]),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSocialLinks() {
    return _buildSection(
      'Contacts',
      Icons.link,
      Colors.purple,
      Column(
        children: [
          Row(
            children: [
              Expanded(
                child: _buildSocialButton(
                  'WhatsApp',
                  Icons.chat,
                  Colors.green,
                  () => _launchWhatsApp('+22796019007'),
                ),
              ),
              SizedBox(width: 12),
              Expanded(
                child: _buildSocialButton(
                  'Email',
                  Icons.email,
                  Colors.red,
                  () => _launchEmail('hamadouabdou38@gmail.com'),
                ),
              ),
            ],
          ),
          SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _buildSocialButton(
                  'Facebook',
                  Icons.facebook,
                  Colors.blue[800]!,
                  () => _launchFacebook('https://www.facebook.com/profile.php?id=100089084547103'),
                ),
              ),
              SizedBox(width: 12),
              Expanded(
                child: _buildSocialButton(
                  'LinkedIn',
                  Icons.business,
                  Colors.blue[700]!,
                  () => _launchLinkedIn('linkedin.com'),
                ),
              ),
            ],
          ),
          SizedBox(height: 12),
        
        ],
      ),
    );
  }

  Widget _buildSocialButton(String label, IconData icon, Color color, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 16, horizontal: 12),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Column(
          children: [
            Icon(icon, color: color, size: 28),
            SizedBox(height: 8),
            Text(
              label,
              style: TextStyle(
                color: color,
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTechnicalInfo() {
    return _buildSection(
      'Informations Techniques',
      Icons.info,
      Colors.indigo,
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildInfoRow('Framework', 'Flutter 3.0+'),
          _buildInfoRow('Base de données', 'SQLite avec synchronisation'),
          _buildInfoRow('API Backend', 'Node.js + Express'),
          _buildInfoRow('Authentification', 'JWT Token'),
          _buildInfoRow('Stockage', 'Base locale + Cloud'),
          _buildInfoRow('Compatibilité', 'Android 6.0+ / iOS 11.0+'),
        ],
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Text(
              '$label:',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.grey[700],
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: TextStyle(color: Colors.grey[600]),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSupportSection() {
    return _buildSection(
      'Support & Feedback',
      Icons.support_agent,
      Colors.green,
      Column(
        children: [
          Text(
            'Vous avez une question ou une suggestion ? N\'hésitez pas à nous contacter !',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey[700],
              height: 1.5,
            ),
          ),
          SizedBox(height: 20),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: _shareApp,
                  icon: Icon(Icons.share),
                  label: Text('Partager l\'app'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.teal,
                    foregroundColor: Colors.white,
                    padding: EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ),
              SizedBox(width: 12),
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () => _launchEmail('support@dictionnaire-zarma.com'),
                  icon: Icon(Icons.bug_report),
                  label: Text('Signaler un bug'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.orange,
                    foregroundColor: Colors.white,
                    padding: EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSection(String title, IconData icon, Color color, Widget content) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(icon, color: color, size: 24),
                ),
                SizedBox(width: 12),
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey[800],
                  ),
                ),
              ],
            ),
            SizedBox(height: 16),
            content,
          ],
        ),
      ),
    );
  }

  // Méthodes pour lancer les liens
  Future<void> _launchWhatsApp(String phoneNumber) async {
    final url = 'https://wa.me/$phoneNumber';
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      _showErrorSnackBar('Impossible d\'ouvrir WhatsApp');
    }
  }

  Future<void> _launchEmail(String email) async {
    final url = 'mailto:$email?subject=Dictionnaire Zarma - Support';
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      _showErrorSnackBar('Impossible d\'ouvrir l\'application email');
    }
  }

  Future<void> _launchFacebook(String profile) async {
    final url = 'https://facebook.com/$profile';
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      _showErrorSnackBar('Impossible d\'ouvrir Facebook');
    }
  }

  Future<void> _launchLinkedIn(String profile) async {
    final url = 'https://linkedin.com/in/$profile';
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      _showErrorSnackBar('Impossible d\'ouvrir LinkedIn');
    }
  }

  Future<void> _launchGitHub(String username) async {
    final url = 'https://github.com/$username';
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      _showErrorSnackBar('Impossible d\'ouvrir GitHub');
    }
  }

  Future<void> _launchWebsite(String website) async {
    if (await canLaunch(website)) {
      await launch(website);
    } else {
      _showErrorSnackBar('Impossible d\'ouvrir le site web');
    }
  }

  Future<void> _shareApp() async {
    await Share.share(
      'Découvrez le Dictionnaire Zarma, une application mobile pour apprendre le zarma ! '
      'Téléchargez-la sur le Play Store.',
      subject: 'Dictionnaire Zarma - Application Mobile',
    );
  }

  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }
}