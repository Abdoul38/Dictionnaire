import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/get_connect/http/src/response/response.dart' as http;
import 'practice_exercises_screen.dart';
import '../services/apiservice.dart';

class ExerciceMenuScreen extends StatefulWidget {
  @override
  _ExerciceMenuScreenState createState() => _ExerciceMenuScreenState();
}

class _ExerciceMenuScreenState extends State<ExerciceMenuScreen>
    with TickerProviderStateMixin {
  late AnimationController _slideController;
  late AnimationController _fadeController;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _fadeAnimation;
  List<dynamic> exercises = [];
  bool isLoading = true;
  bool isLoadingInProgress = false;
  
  // VARIABLES POUR CACHE
  static bool _dataLoaded = false;
  static List<dynamic> _cachedExercises = [];
  static DateTime? _lastLoadTime;

  @override
  void initState() {
    super.initState();
    _setupAnimations();
    
    // CHARGEMENT OPTIMISÉ - vérifier le cache d'abord
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        _loadDataWithCache();
      }
    });
  }

  // MÉTHODE DE CHARGEMENT AVEC CACHE
  Future<void> _loadDataWithCache() async {
    // Si les données sont déjà en cache et récentes
    if (_dataLoaded && 
        _lastLoadTime != null && 
        DateTime.now().difference(_lastLoadTime!) < Duration(minutes: 10)) {
      
      setState(() {
        exercises = _cachedExercises;
        isLoading = false;
      });
      return;
    }
    
    // Sinon, charger depuis l'API
    await _loadData();
  }

  // CHARGEMENT SILENCIEUX - AUCUN MESSAGE D'ERREUR
  Future<void> _loadData() async {
    if (isLoadingInProgress) {
      return;
    }
    
    setState(() {
      isLoadingInProgress = true;
      isLoading = true;
    });

    try {
      // Test de connexion simple
      final isConnected = await ApiService.instance.testConnection();
      if (!isConnected) {
        _handleSilentFailure();
        return;
      }

      // CHARGEMENT SÉQUENTIEL avec délais
      await Future.delayed(Duration(seconds: 2));
      
      final exercises = await _loadExercisesWithRetry();
      
      if (mounted) {
        setState(() {
          this.exercises = exercises;
          isLoading = false;
          isLoadingInProgress = false;
        });
        
        // MISE À JOUR DU CACHE
        _cachedExercises = exercises;
        _dataLoaded = true;
        _lastLoadTime = DateTime.now();
      }
      
    } catch (e) {
      // ÉCHEC SILENCIEUX
      _handleSilentFailure();
    }
  }

  // GESTION SILENCIEUSE DES ÉCHECS
  void _handleSilentFailure() {
    if (mounted) {
      setState(() {
        // Si on a des données en cache, les utiliser
        if (_cachedExercises.isNotEmpty) {
          exercises = _cachedExercises;
        } else {
          exercises = []; // Liste vide sans message d'erreur
        }
        isLoading = false;
        isLoadingInProgress = false;
      });
    }
  }

  // RETRY SILENCIEUX
  Future<List<dynamic>> _loadExercisesWithRetry({int maxRetries = 2}) async {
    for (int attempt = 0; attempt < maxRetries; attempt++) {
      try {
        final result = await ApiService.instance.getExercises();
        return result;
      } catch (e) {
        if (e.toString().contains('429') || 
            e.toString().contains('Trop de requêtes') ||
            e.toString().contains('Too Many Requests')) {
          
          if (attempt < maxRetries - 1) {
            final delay = 10000 * (attempt + 1); // 10s, 20s
            await Future.delayed(Duration(milliseconds: delay));
            continue;
          }
        }
        
        if (attempt == maxRetries - 1) {
          // Au lieu de rethrow, retourner liste vide
          return [];
        }
      }
    }
    return [];
  }

  // RECHARGEMENT FORCÉ SILENCIEUX
  Future<void> _forceReload() async {
    // Vérifier si un rechargement récent a eu lieu
    if (_lastLoadTime != null && 
        DateTime.now().difference(_lastLoadTime!) < Duration(minutes: 2)) {
      // Ne rien faire, pas de message d'avertissement
      return;
    }

    // NETTOYER LE CACHE
    _dataLoaded = false;
    _cachedExercises.clear();
    _lastLoadTime = null;
    
    setState(() {
      isLoadingInProgress = false;
      isLoading = true;
      exercises = [];
    });
    
    await Future.delayed(Duration(seconds: 1));
    await _loadData();
  }

  // NAVIGATION EXERCICE SÉCURISÉE SILENCIEUSE
  void _startExerciseFromApiSafe(Map<String, dynamic> exercise) {
    try {
      final exerciseId = exercise['id']?.toString();
      final rawType = exercise['exercise_type'] ?? exercise['type'];
      String exerciseType = _normalizeExerciseType(rawType);
      
      if (exerciseType == 'unknown') {
        exerciseType = _guessExerciseType(exercise);
      }
      
      if (exerciseId == null || exerciseId.isEmpty) {
        // Pas de message d'erreur, juste ne rien faire
        return;
      }
      
      // NAVIGATION
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => PracticeExercisesScreen(
            exerciseId: exerciseId,
            exerciseType: exerciseType,
          ),
        ),
      );
      
    } catch (e) {
      // Pas de message d'erreur, juste ne rien faire
      return;
    }
  }

  String _normalizeExerciseType(dynamic exerciseType) {
    if (exerciseType == null) return 'unknown';
    
    final typeString = exerciseType.toString().toLowerCase().trim();
    
    switch (typeString) {
      case 'pronunciation':
      case 'prononciation':
      case 'pronounce':
        return 'pronunciation';
      case 'translation':
      case 'traduction':
      case 'translate':
        return 'translation';
      case 'listening':
      case 'ecoute':
      case 'écoute':
      case 'listen':
        return 'listening';
      case 'writing':
      case 'ecriture':
      case 'écriture':
      case 'write':
        return 'writing';
      case 'conversation':
      case 'speaking':
      case 'parler':
        return 'conversation';
      default:
        return 'unknown';
    }
  }

  String _guessExerciseType(Map<String, dynamic> exercise) {
    final title = exercise['title']?.toString().toLowerCase() ?? '';
    
    if (title.contains('traduction') || title.contains('translation')) {
      return 'translation';
    }
    if (title.contains('prononciation') || title.contains('pronunciation')) {
      return 'pronunciation';
    }
    
    // Fallback basé sur l'ID
    final id = exercise['id']?.toString() ?? '';
    if (id.isNotEmpty) {
      final idNum = int.tryParse(id);
      if (idNum != null) {
        return idNum % 2 == 0 ? 'translation' : 'pronunciation';
      }
    }
    
    return 'pronunciation';
  }

  Widget _buildExerciseSection() {
    if (isLoading) {
      return _buildLoadingCard('Chargement des exercices...');
    }

    // PAS DE GESTION D'ERREUR, JUSTE AFFICHER CE QUI EST DISPONIBLE
    if (exercises.isEmpty) {
      return _buildEmptyCard('Exercices', 'Aucun exercice disponible pour le moment.');
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 4),
          child: Row(
            children: [
              Text(
                'Exercices pratiques',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              Spacer(),
              Text(
                '${exercises.length} disponible${exercises.length > 1 ? 's' : ''}',
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.white.withOpacity(0.8),
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 16),
        ...exercises.asMap().entries.map((entry) {
          final index = entry.key;
          final exercise = entry.value;
          return _buildExerciseCardFromApiSafe(exercise, index);
        }).toList(),
      ],
    );
  }

  Widget _buildLoadingCard(String message) {
    return Container(
      padding: EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.1),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          SizedBox(
            width: 20,
            height: 20,
            child: CircularProgressIndicator(
              strokeWidth: 2,
              valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
            ),
          ),
          SizedBox(width: 16),
          Expanded(
            child: Text(
              message,
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyCard(String title, String message) {
    return Container(
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.1),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        children: [
          Icon(Icons.inbox_outlined, color: Colors.white, size: 48),
          SizedBox(height: 12),
          Text(
            message,
            style: TextStyle(
              color: Colors.white.withOpacity(0.9),
              fontSize: 16,
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 16),
          // BOUTON DE RECHARGEMENT SILENCIEUX
          ElevatedButton.icon(
            onPressed: _forceReload,
            icon: Icon(Icons.refresh, size: 16),
            label: Text('Actualiser'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.white.withOpacity(0.2),
              foregroundColor: Colors.white,
              minimumSize: Size(120, 36),
            ),
          ),
        ],
      ),
    );
  }

  // MÉTHODES ANIMATIONS ET BUILD INCHANGÉES
  void _setupAnimations() {
    _slideController = AnimationController(
      duration: Duration(milliseconds: 800),
      vsync: this,
    );
    _fadeController = AnimationController(
      duration: Duration(milliseconds: 1000),
      vsync: this,
    );

    _slideAnimation = Tween<Offset>(
      begin: Offset(0, 0.5),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _slideController,
      curve: Curves.easeOutCubic,
    ));

    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeOut,
    ));

    _slideController.forward();
    _fadeController.forward();
  }

  @override
  void dispose() {
    _slideController.dispose();
    _fadeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Colors.teal.shade600,
              Colors.blue.shade600,
              Colors.purple.shade600,
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              Expanded(
                child: SingleChildScrollView(
                  padding: EdgeInsets.all(20),
                  child: Column(
                    children: [
                      FadeTransition(
                        opacity: _fadeAnimation,
                        child: _buildWelcomeCard(),
                      ),
                     
                      SizedBox(height: 30),
                      SlideTransition(
                        position: _slideAnimation,
                        child: _buildExerciseSection(),
                      ),
                      SizedBox(height: 30),
                      SlideTransition(
                        position: _slideAnimation,
                        child: _buildAboutSection(),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: EdgeInsets.all(20),
      child: Row(
        children: [
          IconButton(
            onPressed: () => Navigator.pop(context),
            icon: Icon(Icons.arrow_back, color: Colors.white),
          ),
          Expanded(
            child: Text(
              'Exercices Zarma',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWelcomeCard() {
    return Container(
      padding: EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.95),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 20,
            offset: Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        children: [
          Icon(
            Icons.school,
            size: 60,
            color: Colors.teal,
          ),
          SizedBox(height: 16),
          Text(
            'Bienvenue dans l\'espace d\'apprentissage',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              color: Colors.grey[800],
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 8),
          Text(
            'Testez vos connaissances sur la langue zarma et découvrez la riche histoire du peuple zarma',
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey[600],
              height: 1.4,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildExerciseCardFromApiSafe(dynamic exercise, int index) {
    if (exercise == null || exercise is! Map<String, dynamic>) {
      return SizedBox.shrink();
    }
    
    final exerciseMap = exercise as Map<String, dynamic>;
    final title = exerciseMap['title'] ?? exerciseMap['Title'] ?? exerciseMap['name'] ?? 'Exercice sans titre';
    final description = exerciseMap['description'] ?? exerciseMap['Description'] ?? 'Pas de description';
    final exerciseType = exerciseMap['exercise_type'] ?? exerciseMap['exerciseType'] ?? exerciseMap['type'] ?? exerciseMap['Type'] ?? 'unknown';
    final id = exerciseMap['id']?.toString() ?? exerciseMap['Id']?.toString();
    final itemCount = exerciseMap['item_count'] ?? exerciseMap['itemCount'] ?? exerciseMap['items_count'] ?? exerciseMap['items']?.length ?? 0;
    
    if (id == null) return SizedBox.shrink();

    return GestureDetector(
      onTap: () => _startExerciseFromApiSafe(exerciseMap),
      child: Container(
        margin: EdgeInsets.only(bottom: 12),
        padding: EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 15,
              offset: Offset(0, 5),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: _getExerciseTypeColor(exerciseType).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    _getExerciseTypeIcon(exerciseType),
                    color: _getExerciseTypeColor(exerciseType),
                    size: 24,
                  ),
                ),
                Spacer(),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: _getExerciseTypeColor(exerciseType).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    _getExerciseTypeDisplayName(exerciseType),
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                      color: _getExerciseTypeColor(exerciseType),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 16),
            Text(
              title,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.grey[800],
              ),
            ),
            SizedBox(height: 8),
            Text(
              description,
              style: TextStyle(
                fontSize: 13,
                color: Colors.grey[600],
                height: 1.3,
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
            SizedBox(height: 8),
            Text(
              '$itemCount élément${itemCount != 1 ? 's' : ''}',
              style: TextStyle(
                fontSize: 12,
                color: Colors.grey[500],
              ),
            ),
            SizedBox(height: 16),
            Row(
              children: [
                Text(
                  'Démarrer',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: _getExerciseTypeColor(exerciseType),
                  ),
                ),
                SizedBox(width: 4),
                Icon(Icons.play_arrow, 
                    color: _getExerciseTypeColor(exerciseType), size: 16),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAboutSection() {
    return Container(
      padding: EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.2)),
      ),
      child: Column(
        children: [
          Icon(
            Icons.info_outline,
            color: Colors.white,
            size: 40,
          ),
          SizedBox(height: 16),
          Text(
            'À propos',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          SizedBox(height: 8),
          Text(
            'Cette application vous aide à apprendre la langue zarma et à découvrir la riche histoire du peuple zarma du Niger. Progressez à votre rythme avec des quiz adaptés et des exercices interactifs.',
            style: TextStyle(
              fontSize: 14,
              color: Colors.white.withOpacity(0.9),
              height: 1.4,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Color _getExerciseTypeColor(String? type) {
    switch (type?.toLowerCase()) {
      case 'pronunciation':
      case 'prononciation':
        return Colors.orange;
      case 'translation':
      case 'traduction':
        return Colors.pink;
      case 'listening':
      case 'écoute':
        return Colors.blue;
      case 'writing':
      case 'écriture':
        return Colors.purple;
      case 'conversation':
        return Colors.green;
      default:
        return Colors.grey;
    }
  }

  IconData _getExerciseTypeIcon(String? type) {
    switch (type?.toLowerCase()) {
      case 'pronunciation':
      case 'prononciation':
        return Icons.record_voice_over;
      case 'translation':
      case 'traduction':
        return Icons.translate;
      case 'listening':
      case 'écoute':
        return Icons.headphones;
      case 'writing':
      case 'écriture':
        return Icons.edit;
      case 'conversation':
        return Icons.chat;
      default:
        return Icons.help;
    }
  }

  String _getExerciseTypeDisplayName(String? type) {
    switch (type?.toLowerCase()) {
      case 'pronunciation':
      case 'prononciation':
        return 'Prononciation';
      case 'translation':
      case 'traduction':
        return 'Traduction';
      case 'listening':
      case 'écoute':
        return 'Écoute';
      case 'writing':
      case 'écriture':
        return 'Écriture';
      case 'conversation':
        return 'Conversation';
      default:
        return 'Exercice';
    }
  }
}