// lib/screens/sync_settings_screen.dart - Version corrigée
import 'package:flutter/material.dart';
import '../data/database_helper.dart';
import '../services/apiservice.dart';
import '../models/word_model.dart';
import '../models/sync_models.dart';

class SyncSettingsScreen extends StatefulWidget {
  @override
  _SyncSettingsScreenState createState() => _SyncSettingsScreenState();
}

class _SyncSettingsScreenState extends State<SyncSettingsScreen> {
  final CacheDatabaseHelper _db = CacheDatabaseHelper();
  final TextEditingController _urlController = TextEditingController();
  
  SyncStatus? _syncStatus;
  bool _isTestingConnection = false;
  bool _autoSyncEnabled = true;
  bool _syncOnWifiOnly = true;
  bool _isSyncing = false;

  @override
  void initState() {
    super.initState();
    _loadSettings();
    _checkSyncStatus();
  }

  Future<void> _loadSettings() async {
    try {
      // Charger l'URL actuelle
      _urlController.text = ApiService.instance.apiUrl;
      
      // Charger les autres paramètres depuis la base de données
      final config = await _db.getSyncConfig();
      setState(() {
        _autoSyncEnabled = config['auto_sync_enabled'] ?? true;
        _syncOnWifiOnly = config['sync_on_wifi_only'] ?? true;
      });
    } catch (e) {
      print('Erreur lors du chargement des paramètres: $e');
    }
  }

  Future<void> _checkSyncStatus() async {
    try {
      final status = await _db.getSyncStatus();
      setState(() {
        _syncStatus = status;
      });
    } catch (e) {
      print('Erreur lors de la vérification du statut: $e');
    }
  }

  Future<void> _testConnection() async {
    setState(() {
      _isTestingConnection = true;
    });

    try {
      final isConnected = await ApiService.instance.testConnection();
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            isConnected ? 'Connexion réussie !' : 'Impossible de se connecter au serveur',
          ),
          backgroundColor: isConnected ? Colors.green : Colors.red,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Erreur de test: $e'),
          backgroundColor: Colors.red,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      );
    } finally {
      setState(() {
        _isTestingConnection = false;
      });
    }
  }

  Future<void> _saveApiUrl() async {
    try {
      await ApiService.instance.setApiUrl(_urlController.text.trim());
      await _checkSyncStatus();
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('URL du serveur sauvegardée'),
          backgroundColor: Colors.green,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Erreur lors de la sauvegarde: $e'),
          backgroundColor: Colors.red,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      );
    }
  }

  Future<void> _performSync() async {
    setState(() {
      _isSyncing = true;
    });

    try {
      // Utiliser performFullSync au lieu de refreshCache
      await _db.performFullSync();
      await _checkSyncStatus();
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Synchronisation réussie !'),
          backgroundColor: Colors.green,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Erreur de synchronisation: $e'),
          backgroundColor: Colors.red,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      );
    } finally {
      setState(() {
        _isSyncing = false;
      });
    }
  }

  Future<void> _resetSyncStatus() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Réinitialiser la synchronisation'),
        content: Text('Cette action va réinitialiser le statut de synchronisation de tous les mots. Continuer ?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text('Annuler'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text('Réinitialiser', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    ) ?? false;

    if (confirmed) {
      try {
        await _db.resetSyncStatus();
        await _checkSyncStatus();
        
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Statut de synchronisation réinitialisé'),
            backgroundColor: Colors.orange,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          ),
        );
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Erreur lors de la réinitialisation: $e'),
            backgroundColor: Colors.red,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          ),
        );
      }
    }
  }

  Future<void> _updateSyncSettings() async {
    try {
      await _db.updateSyncConfig({
        'auto_sync_enabled': _autoSyncEnabled,
        'sync_on_wifi_only': _syncOnWifiOnly,
      });
    } catch (e) {
      print('Erreur lors de la mise à jour des paramètres: $e');
    }
  }

  @override
  void dispose() {
    _urlController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        title: Text('Synchronisation'),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildStatusCard(),
      
            SizedBox(height: 20),
            _buildSyncOptionsCard(),
            SizedBox(height: 20),
            _buildActionsCard(),
           
          ],
        ),
      ),
    );
  }

  Widget _buildStatusCard() {
    if (_syncStatus == null) {
      return _buildCard(
        title: 'Statut de synchronisation',
        icon: Icons.sync_problem,
        iconColor: Colors.grey,
        children: [
          ListTile(
            leading: CircularProgressIndicator(),
            title: Text('Vérification du statut...'),
          ),
        ],
      );
    }

    Color statusColor = _syncStatus!.isConnected 
        ? (_syncStatus!.needsSync ? Colors.orange : Colors.green)
        : Colors.red;

    return _buildCard(
      title: 'Statut de synchronisation',
      icon: _syncStatus!.isConnected 
          ? (_syncStatus!.needsSync ? Icons.sync_problem : Icons.sync) 
          : Icons.sync_disabled,
      iconColor: statusColor,
      children: [
        ListTile(
          title: Text(_syncStatus!.statusMessage),
          subtitle: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 8),
              Text('Connexion: ${_syncStatus!.isConnected ? "Connecté" : "Déconnecté"}'),
              Text('Serveur: ${_syncStatus!.canConnectToServer ? "Accessible" : "Inaccessible"}'),
              if (_syncStatus!.pendingUploads > 0)
                Text('En attente: ${_syncStatus!.pendingUploads} modification(s)'),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildServerConfigCard() {
    return _buildCard(
      title: 'Configuration du serveur',
      icon: Icons.dns,
      iconColor: Colors.blue,
      children: [
        Padding(
          padding: EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'URL du serveur API',
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  color: Colors.grey[700],
                ),
              ),
              SizedBox(height: 8),
              TextField(
                controller: _urlController,
                decoration: InputDecoration(
                  hintText: 'https://dictionnaire-zarma-api.onrender.com/api',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  suffixIcon: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (_isTestingConnection)
                        Padding(
                          padding: EdgeInsets.only(right: 8),
                          child: SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          ),
                        ),
                      IconButton(
                        icon: Icon(Icons.save),
                        onPressed: _saveApiUrl,
                        tooltip: 'Sauvegarder',
                      ),
                    ],
                  ),
                ),
                keyboardType: TextInputType.url,
              ),
              SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: _isTestingConnection ? null : _testConnection,
                      icon: _isTestingConnection 
                          ? SizedBox(
                              width: 16,
                              height: 16,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : Icon(Icons.wifi_protected_setup),
                      label: Text('Tester la connexion'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blue,
                        foregroundColor: Colors.white,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildSyncOptionsCard() {
    return _buildCard(
      title: 'Options de synchronisation',
      icon: Icons.settings,
      iconColor: Colors.orange,
      children: [
        SwitchListTile(
          title: Text('Synchronisation automatique'),
          subtitle: Text('Synchroniser automatiquement en arrière-plan'),
          value: _autoSyncEnabled,
          onChanged: (value) {
            setState(() {
              _autoSyncEnabled = value;
            });
            _updateSyncSettings();
          },
          activeColor: Colors.teal,
        ),
        SwitchListTile(
          title: Text('Synchroniser uniquement en WiFi'),
          subtitle: Text('Éviter l\'utilisation des données mobiles'),
          value: _syncOnWifiOnly,
          onChanged: (value) {
            setState(() {
              _syncOnWifiOnly = value;
            });
            _updateSyncSettings();
          },
          activeColor: Colors.teal,
        ),
      ],
    );
  }

  Widget _buildActionsCard() {
    return _buildCard(
      title: 'Actions',
      icon: Icons.build,
      iconColor: Colors.green,
      children: [
        ListTile(
          leading: CircleAvatar(
            backgroundColor: Colors.green.withOpacity(0.1),
            child: _isSyncing 
                ? SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : Icon(Icons.sync, color: Colors.green),
          ),
          title: Text('Synchroniser maintenant'),
          subtitle: Text('Forcer une synchronisation complète'),
          trailing: Icon(Icons.arrow_forward_ios, size: 16),
          onTap: _isSyncing ? null : _performSync,
        ),
        Divider(),
        ListTile(
          leading: CircleAvatar(
            backgroundColor: Colors.orange.withOpacity(0.1),
            child: Icon(Icons.refresh, color: Colors.orange),
          ),
          title: Text('Réinitialiser le statut'),
          subtitle: Text('Marquer tous les mots comme non synchronisés'),
          trailing: Icon(Icons.arrow_forward_ios, size: 16),
          onTap: _resetSyncStatus,
        ),
        Divider(),
        ListTile(
          leading: CircleAvatar(
            backgroundColor: Colors.blue.withOpacity(0.1),
            child: Icon(Icons.download, color: Colors.blue),
          ),
          title: Text('Mots non synchronisés'),
          subtitle: FutureBuilder<List<WordModel>>(
            future: _db.getUnsyncedWords(),
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                return Text('${snapshot.data!.length} mot(s) en attente');
              }
              return Text('Calcul en cours...');
            },
          ),
          trailing: Icon(Icons.arrow_forward_ios, size: 16),
          onTap: () => _showUnsyncedWords(),
        ),
      ],
    );
  }

  Widget _buildInfoCard() {
    return _buildCard(
      title: 'Informations',
      icon: Icons.info,
      iconColor: Colors.blue,
      children: [
        Padding(
          padding: EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildInfoRow('URL actuelle', ApiService.instance.apiUrl),
              SizedBox(height: 8),
              FutureBuilder<int?>(
                future: ApiService.instance.getLastSyncTime(),
                builder: (context, snapshot) {
                  String lastSyncText = 'Jamais';
                  if (snapshot.hasData && snapshot.data != null) {
                    final lastSync = DateTime.fromMillisecondsSinceEpoch(snapshot.data! * 1000);
                    final diff = DateTime.now().difference(lastSync);
                    if (diff.inMinutes < 60) {
                      lastSyncText = 'Il y a ${diff.inMinutes} minute(s)';
                    } else if (diff.inHours < 24) {
                      lastSyncText = 'Il y a ${diff.inHours} heure(s)';
                    } else {
                      lastSyncText = 'Il y a ${diff.inDays} jour(s)';
                    }
                  }
                  return _buildInfoRow('Dernière synchronisation', lastSyncText);
                },
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildCard({
    required String title,
    required IconData icon,
    required Color iconColor,
    required List<Widget> children,
  }) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Column(
        children: [
          Container(
            width: double.infinity,
            padding: EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: iconColor.withOpacity(0.1),
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(12),
                topRight: Radius.circular(12),
              ),
            ),
            child: Row(
              children: [
                Icon(icon, color: iconColor),
                SizedBox(width: 12),
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey[800],
                  ),
                ),
              ],
            ),
          ),
          ...children,
        ],
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 120,
          child: Text(
            label + ':',
            style: TextStyle(
              fontWeight: FontWeight.w600,
              color: Colors.grey[600],
            ),
          ),
        ),
        Expanded(
          child: Text(
            value,
            style: TextStyle(color: Colors.grey[800]),
          ),
        ),
      ],
    );
  }

  Future<void> _showUnsyncedWords() async {
    try {
      final unsyncedWords = await _db.getUnsyncedWords();
      
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('Mots non synchronisés'),
          content: Container(
            width: double.maxFinite,
            height: 300,
            child: unsyncedWords.isEmpty
                ? Center(child: Text('Tous les mots sont synchronisés'))
                : ListView.builder(
                    itemCount: unsyncedWords.length,
                    itemBuilder: (context, index) {
                      final word = unsyncedWords[index];
                      return ListTile(
                        title: Text(word.zarmaWord),
                        subtitle: Text(word.frenchMeaning),
                        trailing: Icon(Icons.sync_problem, color: Colors.orange),
                      );
                    },
                  ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Fermer'),
            ),
            if (unsyncedWords.isNotEmpty)
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                  _performSync();
                },
                child: Text('Synchroniser', style: TextStyle(color: Colors.teal)),
              ),
          ],
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Erreur lors du chargement: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }
}