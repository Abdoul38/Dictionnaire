import 'package:flutter/material.dart';

class Constants {
  static const String appName = 'Dictionnaire Zarma-Français';
  static const String appVersion = '1.0.0';
  
  // Couleurs de l'app
  static const Color primaryColor = Colors.teal;
  static const Color secondaryColor = Colors.orange;
  static const Color accentColor = Colors.blue;
  static const Color successColor = Colors.green;
  static const Color warningColor = Colors.orange;
  static const Color errorColor = Colors.red;
  
  // Tailles de police
  static const double titleFontSize = 24.0;
  static const double subtitleFontSize = 20.0;
  static const double bodyFontSize = 16.0;
  static const double captionFontSize = 14.0;
  static const double smallFontSize = 12.0;
  
  // Espacements
  static const double smallPadding = 8.0;
  static const double mediumPadding = 16.0;
  static const double largePadding = 24.0;
  
  // Rayons de bordure
  static const double smallRadius = 8.0;
  static const double mediumRadius = 12.0;
  static const double largeRadius = 16.0;
  static const double circularRadius = 25.0;
  
  // Messages
  static const String noWordsFound = 'Aucun mot trouvé';
  static const String searchHint = 'Rechercher un mot en zarma ou français...';
  static const String loadingError = 'Erreur lors du chargement des mots';
  static const String loadingMessage = 'Chargement du dictionnaire...';
  
  // Catégories grammaticales
  static const List<String> grammaticalCategories = [
    'nom',
    'verbe',
    'adjectif',
    'adverbe',
    'pronom',
    'préposition',
    'conjonction',
    'interjection',
  ];
}