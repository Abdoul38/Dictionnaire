import 'package:flutter/material.dart';

class NotificationUtils {
  static String formatRelativeTime(DateTime dateTime) {
    final now = DateTime.now();
    final difference = now.difference(dateTime);

    if (difference.inDays > 7) {
      return '${dateTime.day}/${dateTime.month}/${dateTime.year}';
    } else if (difference.inDays > 0) {
      return 'Il y a ${difference.inDays} jour${difference.inDays > 1 ? 's' : ''}';
    } else if (difference.inHours > 0) {
      return 'Il y a ${difference.inHours}h';
    } else if (difference.inMinutes > 0) {
      return 'Il y a ${difference.inMinutes}min';
    } else {
      return 'À l\'instant';
    }
  }

  static Color getNotificationColor(String type) {
    switch (type.toLowerCase()) {
      case 'success':
        return Colors.green;
      case 'warning':
        return Colors.orange;
      case 'error':
        return Colors.red;
      case 'info':
      default:
        return Colors.blue;
    }
  }

  static IconData getNotificationIcon(String type) {
    switch (type.toLowerCase()) {
      case 'success':
        return Icons.check_circle;
      case 'warning':
        return Icons.warning;
      case 'error':
        return Icons.error;
      case 'info':
      default:
        return Icons.info;
    }
  }

  static int getNotificationPriority(String priority) {
    switch (priority.toLowerCase()) {
      case 'high':
        return 4;
      case 'medium':
        return 3;
      case 'normal':
        return 2;
      case 'low':
        return 1;
      default:
        return 2;
    }
  }

  static void showInAppNotification(
    BuildContext context,
    String title,
    String message, {
    String type = 'info',
    Duration duration = const Duration(seconds: 4),
    VoidCallback? onTap,
  }) {
    final color = getNotificationColor(type);
    final icon = getNotificationIcon(type);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(icon, color: Colors.white, size: 20),
            SizedBox(width: 8),
            Expanded(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                  if (message.isNotEmpty)
                    Text(
                      message,
                      style: TextStyle(fontSize: 12),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                ],
              ),
            ),
          ],
        ),
        backgroundColor: color,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        duration: duration,
        action: onTap != null
            ? SnackBarAction(
                label: 'Voir',
                textColor: Colors.white,
                onPressed: onTap,
              )
            : null,
      ),
    );
  }

  static bool shouldShowNotification(Map<String, dynamic> settings, String type) {
    if (settings.isEmpty) return true;
    
    final enabled = settings['notifications_enabled'] ?? true;
    if (!enabled) return false;
    
    final typeSettings = settings['notification_types'] as Map<String, dynamic>?;
    if (typeSettings == null) return true;
    
    return typeSettings[type] ?? true;
  }
}