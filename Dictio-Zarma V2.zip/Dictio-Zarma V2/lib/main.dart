import 'package:flutter/material.dart';
import 'package:zarma_dictionary/screens/home_screen.dart';


void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialiser Firebase
  // Initialiser les notifications push
 
  
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Dictionnaire Zarma',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.teal,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: CentralizedHomeScreen(),
    );
  }
}