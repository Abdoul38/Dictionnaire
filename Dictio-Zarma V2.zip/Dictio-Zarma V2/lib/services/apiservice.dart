// lib/services/api_service.dart - Version centralisée
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:path/path.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/word_model.dart';

class ApiService {
  static const String PRODUCTION_URL = 'https://dictionnaire-zarma-api.onrender.com/api';

static const String LOCAL_URL = 'https://dictionnaire-zarma-api.onrender.com/api';
  static const String USERNAME = 'admin';
  static const String PASSWORD = 'admin123';
  static DateTime? _lastRequestTime;
  static const int minDelayBetweenRequests = 2000; // 2 secondes au lieu de 1
  static const int maxRetries = 2; // Réduire le nombre de tentatives
  
  // CORRECTION 2: Améliorer la méthode _respectRateLimit
  static Future<void> _respectRateLimit() async {
    if (_lastRequestTime != null) {
      final timeSinceLastRequest = DateTime.now().difference(_lastRequestTime!).inMilliseconds;
      if (timeSinceLastRequest < minDelayBetweenRequests) {
        final delayNeeded = minDelayBetweenRequests - timeSinceLastRequest;
        print('⏳ Rate limiting: attente de ${delayNeeded}ms...');
        await Future.delayed(Duration(milliseconds: delayNeeded));
      }
    }
    _lastRequestTime = DateTime.now();
  }

  // Headers avec authentification Basic Auth
  Map<String, String> get _headers => {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'Authorization': 'Basic ${base64Encode(utf8.encode('$USERNAME:$PASSWORD'))}',
  };

  // Ou si c'est une API Key


  static ApiService? _instance;
  static ApiService get instance => _instance ??= ApiService._();
  ApiService._();

  late String _baseUrl;
  late SharedPreferences _prefs;
  Timer? _connectionCheckTimer;
  bool _isOnline = false;

  Future<void> initialize() async {
    _prefs = await SharedPreferences.getInstance();
    
    // Utiliser l'URL de production par défaut, locale en développement
    _baseUrl = const bool.fromEnvironment('dart.vm.product') 
        ? PRODUCTION_URL 
        : LOCAL_URL;
        
    
    // Permettre à l'utilisateur de configurer l'URL du serveur
    final customUrl = _prefs.getString('custom_api_url');
    if (customUrl != null && customUrl.isNotEmpty) {
      _baseUrl = customUrl;
    }
    
    // Démarrer la vérification de connexion périodique
    _startConnectionCheck();
    
    print('ApiService initialisé avec URL: $_baseUrl');
  }

  void _startConnectionCheck() {
    _connectionCheckTimer?.cancel();
    _connectionCheckTimer = Timer.periodic(Duration(seconds: 30), (timer) {
      _checkConnection();
    });
  }
Future<int?> getLastSyncTime() async {
    // Pour une API centralisée, on peut retourner le timestamp de dernière connexion
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getInt('last_connection_time');
    } catch (e) {
      return null;
    }
  }
  

  
  Future<void> _checkConnection() async {
    try {
      final wasOnline = _isOnline;
      _isOnline = await testConnection();
      
      if (!wasOnline && _isOnline) {
        print('Connexion au serveur rétablie');
      } else if (wasOnline && !_isOnline) {
        print('Connexion au serveur perdue');
      }
    } catch (e) {
      _isOnline = false;
    }
  }

  bool get isOnline => _isOnline;

  // Configuration de l'URL du serveur
  Future<void> setApiUrl(String url) async {
    _baseUrl = url;
    await _prefs.setString('custom_api_url', url);
    await _checkConnection();
  }

  String get apiUrl => _baseUrl;



  // Gestion des erreurs réseau améliorée
Future<http.Response> _handleRequest(Future<http.Response> Function() request) async {
    // Appliquer le rate limiting AVANT chaque requête
    await _respectRateLimit();
    
    try {
      final response = await request().timeout(Duration(seconds: 20)); // Augmenter timeout
      
      if (response.statusCode == 429) {
        // Rate limit détecté - attendre plus longtemps
        print('⚠️ Rate limit 429 détecté - attente de 10 secondes...');
        await Future.delayed(Duration(seconds: 10));
        throw ApiException('Trop de requêtes. Veuillez patienter.');
      }
      
      if (response.statusCode == 401 || response.statusCode == 403) {
        throw ApiException('Erreur d\'authentification. Vérifiez les credentials.');
      }
      
      if (response.statusCode >= 200 && response.statusCode < 300) {
        _isOnline = true;
        final prefs = await SharedPreferences.getInstance();
        await prefs.setInt('last_connection_time', DateTime.now().millisecondsSinceEpoch ~/ 1000);
        return response;
      } else {
        throw ApiException('Erreur ${response.statusCode}: ${response.body}');
      }
    } on SocketException catch (e) {
      _isOnline = false;
      throw ApiException('Impossible de contacter le serveur. Vérifiez votre connexion réseau.');
    } on TimeoutException catch (e) {
      _isOnline = false;
      throw ApiException('Timeout: Le serveur met trop de temps à répondre');
    } catch (e) {
      _isOnline = false;
      if (e.toString().contains('429') || e.toString().contains('Too Many Requests')) {
        throw ApiException('Trop de requêtes envoyées. Veuillez attendre 30 secondes avant de réessayer.');
      }
      throw ApiException('Erreur inattendue: $e');
    }
  }
  // CORRECTION: Finaliser la conversion depuis l'API
Map<String, dynamic> _convertToApi(WordModel word) {
  // Convertir les chaînes séparées par | en listes pour l'API
  List<String> convertStringToList(String? str) {
    if (str == null || str.isEmpty) return [];
    return str.split('|').where((s) => s.isNotEmpty).toList();
  }

  return {
    'zarmaWord': word.zarmaWord,
    'zarmaExample': word.zarmaExample,
    'frenchMeaning': word.frenchMeaning,
    'frenchExample': word.frenchExample,
    'category': word.category,
    'pronunciation': word.pronunciation,
    'difficultyLevel': word.difficultyLevel,
    'etymology': word.etymology,
    'synonyms': convertStringToList(word.synonyms?.toString()), // ← Conversion
    'antonyms': convertStringToList(word.antonyms?.toString()), // ← Conversion
    'relatedWords': convertStringToList(word.relatedWords?.toString()), // ← Conversion
    'usageFrequency': word.usageFrequency,
    'audioPath': word.audioPath,
    'imagePath': word.imagePath,
  };
}
// Remplacez vos méthodes existantes dans apiservice.dart par celles-ci :

Future<List<dynamic>> getQuizzes() async {
    try {
      print('📄 Récupération des quizzes...');
      
      final response = await _handleRequest(() => http.get(
        Uri.parse('$_baseUrl/quiz'),
        headers: _headers,
      ));
      
      print('📊 Statut réponse quizzes: ${response.statusCode}');
      
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        
        List<dynamic> quizzes;
        if (data is Map && data.containsKey('quizzes')) {
          quizzes = data['quizzes'] as List;
        } else if (data is List) {
          quizzes = data;
        } else {
          throw ApiException('Format de réponse inattendu pour les quizzes');
        }
        
        print('✅ ${quizzes.length} quizzes récupérés');
        return quizzes;
      } else {
        throw ApiException('Erreur HTTP ${response.statusCode}: ${response.body}');
      }
    } catch (e) {
      print('❌ Erreur récupération quizzes: $e');
      rethrow;
    }
  }
Future<Map<String, dynamic>> getQuiz(String quizId) async {
  try {
    final response = await http.get(
      Uri.parse('$apiUrl/quiz/$quizId'),
      headers: {'Content-Type': 'application/json'},
    ).timeout(Duration(seconds: 10));
    
    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      
      // Structure attendue basée sur votre schéma DB
      return {
        'id': data['id'],
        'title': data['title'],
        'description': data['description'],
        'category': data['category'],
        'quiz_type': data['quiz_type'],
        'difficulty': data['difficulty'],
        'time_limit': data['time_limit'],
        'primary_color': data['primary_color'],
        'quiz_questions': data['questions'] ?? [] // Vérifier le nom exact
      };
    } else {
      throw ApiException('Erreur HTTP ${response.statusCode}');
    }
  } catch (e) {
    print('❌ Erreur récupération quiz $quizId: $e');
    rethrow;
  }
}
  // Méthode pour récupérer les exercices avec tous leurs items
 Future<List<dynamic>> getExercises() async {
    try {
      print('📄 Récupération des exercices...');
      
      final response = await _handleRequest(() => http.get(
        Uri.parse('$_baseUrl/exercise'),
        headers: _headers,
      ));
      
      print('📊 Statut réponse exercices: ${response.statusCode}');
      
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        
        List<dynamic> exercises;
        if (data is Map && data.containsKey('exercises')) {
          exercises = data['exercises'] as List;
        } else if (data is List) {
          exercises = data;
        } else {
          throw ApiException('Format de réponse inattendu pour les exercices');
        }
        
        print('✅ ${exercises.length} exercices récupérés');
        return exercises;
      } else {
        throw ApiException('Erreur HTTP ${response.statusCode}: ${response.body}');
      }
    } catch (e) {
      print('❌ Erreur récupération exercices: $e');
      rethrow;
    }
  }
  // Méthode pour récupérer un exercice spécifique
  Future<Map<String, dynamic>> getExercise(String exerciseId) async {
  try {
    final response = await http.get(
      Uri.parse('$apiUrl/exercise/$exerciseId'), // Note: 'exercise' pas 'exercises'
      headers: {'Content-Type': 'application/json'},
    ).timeout(Duration(seconds: 10));
    
    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      
      // Structure basée sur votre schéma DB
      return {
        'id': data['id'],
        'title': data['title'],
        'description': data['description'],
        'exercise_type': data['exercise_type'],
        'primary_color': data['primary_color'],
        'exercise_items': data['items'] ?? [] // Vérifier le nom exact
      };
    } else {
      throw ApiException('Erreur HTTP ${response.statusCode}');
    }
  } catch (e) {
    print('❌ Erreur récupération exercice $exerciseId: $e');
    rethrow;
  }
}
Future<void> debugApiStructure() async {
  try {
    print('=== DEBUG API STRUCTURE ===');
    
    // Test quizzes
    final quizzesResponse = await http.get(
      Uri.parse('$apiUrl/quiz'),
      headers: {'Content-Type': 'application/json'},
    );
    
    print('Quizzes endpoint: ${quizzesResponse.statusCode}');
    print('Quizzes body: ${quizzesResponse.body}');
    
    // Test exercises
    final exercisesResponse = await http.get(
      Uri.parse('$apiUrl/exercise'),
      headers: {'Content-Type': 'application/json'},
    );
    
    print('Exercises endpoint: ${exercisesResponse.statusCode}');
    print('Exercises body: ${exercisesResponse.body}');
    
  } catch (e) {
    print('Debug error: $e');
  }
}
// Récupérer un quiz complet avec ses questions et options
Future<Map<String, dynamic>> getQuizWithDetails(String quizId) async {
  try {
    final response = await http.get(
      Uri.parse('$apiUrl/quiz/$quizId/details'), // Vous devrez créer cet endpoint
      headers: {'Content-Type': 'application/json'},
    ).timeout(Duration(seconds: 10));
    
    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      throw ApiException('Erreur HTTP ${response.statusCode}');
    }
  } catch (e) {
    print('❌ Erreur récupération quiz détaillé $quizId: $e');
    rethrow;
  }
}

// Récupérer un exercice complet avec ses items
Future<Map<String, dynamic>> getExerciseWithDetails(String exerciseId) async {
  try {
    final response = await http.get(
      Uri.parse('$apiUrl/exercise/$exerciseId/details'), // Vous devrez créer cet endpoint
      headers: {'Content-Type': 'application/json'},
    ).timeout(Duration(seconds: 10));
    
    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      throw ApiException('Erreur HTTP ${response.statusCode}');
    }
  } catch (e) {
    print('❌ Erreur récupération exercice détaillé $exerciseId: $e');
    rethrow;
  }
}

// Récupérer tous les quizzes avec leurs questions (pour le menu)
Future<List<dynamic>> getQuizzesWithQuestions() async {
  try {
    final response = await http.get(
      Uri.parse('$apiUrl/quizzes-with-questions'), // Nouvel endpoint
      headers: {'Content-Type': 'application/json'},
    ).timeout(Duration(seconds: 10));
    
    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      return data['quizzes'] ?? [];
    } else {
      throw ApiException('Erreur HTTP ${response.statusCode}');
    }
  } catch (e) {
    print('❌ Erreur récupération quizzes avec questions: $e');
    rethrow;
  }
}

// Récupérer tous les exercices avec leurs items (pour le menu)
Future<List<dynamic>> getExercisesWithItems() async {
  try {
    final response = await http.get(
      Uri.parse('$apiUrl/exercises-with-items'), // Nouvel endpoint
      headers: {'Content-Type': 'application/json'},
    ).timeout(Duration(seconds: 10));
    
    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      return data['exercises'] ?? [];
    } else {
      throw ApiException('Erreur HTTP ${response.statusCode}');
    }
  } catch (e) {
    print('❌ Erreur récupération exercices avec items: $e');
    rethrow;
  }
}

  // Méthode de diagnostic pour les exercices
  Future<Map<String, dynamic>> debugExerciseStructure() async {
    try {
      // D'abord récupérer tous les exercices
      final exercises = await getExercises();
      
      final debug = <String, dynamic>{
        'status': 'success',
        'exercises_count': exercises.length,
        'exercises_summary': [],
      };

      if (exercises.isNotEmpty) {
        // Analyser le premier exercice en détail
        final firstExercise = exercises[0];
        debug['first_exercise_data'] = firstExercise;
        
        // Si on a un ID, récupérer les détails
        if (firstExercise['id'] != null) {
          try {
            final exerciseDetail = await getExercise(firstExercise['id'].toString());
            debug['exercise_detail'] = exerciseDetail;
          } catch (e) {
            debug['exercise_detail_error'] = e.toString();
          }
        }
        
        // Résumé de tous les exercices
        for (var exercise in exercises) {
          debug['exercises_summary'].add({
            'id': exercise['id'],
            'title': exercise['title'],
            'type': exercise['exercise_type'],
            'items_count': exercise['exercise_items']?.length ?? 0,
          });
        }
      } else {
        debug['error'] = 'Aucun exercice trouvé';
      }

      return debug;
    } catch (e) {
      return {
        'status': 'error',
        'error': e.toString(),
      };
    }
  }
  Future<Map<String, dynamic>> testApiEndpoints() async {
  final results = <String, dynamic>{};
  
  try {
    // Test quizzes endpoint
    final quizzesResponse = await http.get(
      Uri.parse('$apiUrl/quiz'),
      headers: {'Content-Type': 'application/json'},
    ).timeout(Duration(seconds: 5));
    
    results['quizzes_status'] = quizzesResponse.statusCode;
    results['quizzes_body'] = quizzesResponse.body;
    
    // Test exercises endpoint
    final exercisesResponse = await http.get(
      Uri.parse('$apiUrl/exercise'),
      headers: {'Content-Type': 'application/json'},
    ).timeout(Duration(seconds: 5));
    
    results['exercises_status'] = exercisesResponse.statusCode;
    results['exercises_body'] = exercisesResponse.body;
    
  } catch (e) {
    results['error'] = e.toString();
  }
  
  return results;
}

  // Méthode de diagnostic pour analyser les champs des exercices
  Future<Map<String, dynamic>> diagnoseExerciseFields() async {
    try {
      final response = await http.get(
        Uri.parse('$apiUrl/exercises'),
        headers: {'Content-Type': 'application/json'},
      ).timeout(Duration(seconds: 10));

      final debug = <String, dynamic>{
        'raw_response': response.body,
        'status_code': response.statusCode,
      };

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        
        if (data is List && data.isNotEmpty) {
          final firstExercise = data[0];
          debug['available_fields'] = firstExercise.keys.toList();
          
          // Analyser chaque champ
          final fieldValues = <String, dynamic>{};
          for (String field in firstExercise.keys) {
            final value = firstExercise[field];
            fieldValues[field] = {
              'value': value,
              'type': value.runtimeType.toString(),
              'is_null': value == null,
            };
          }
          debug['field_values'] = fieldValues;
        }
      }

      return debug;
    } catch (e) {
      return {
        'error': e.toString(),
      };
    }
  }

  // Méthode de test de connexion
  // CORRECTION: Modifier testConnection pour utiliser un endpoint existant
Future<bool> testConnection() async {
    try {
      // Ne pas utiliser _handleRequest pour éviter le rate limiting sur les tests
      final response = await http.get(
        Uri.parse('$_baseUrl/quiz?limit=1'),
        headers: {'Content-Type': 'application/json'},
      ).timeout(Duration(seconds: 5));
      
      return response.statusCode == 200;
    } catch (e) {
      print('❌ Test de connexion échoué: $e');
      return false;
    }
  }

  // Test de connectivité

Future<bool> testConnectionFallback() async {
  try {
    // Utiliser l'endpoint des mots avec limit=1 pour un test léger
    final response = await http.get(
      Uri.parse('$_baseUrl/words?limit=1'),
      headers: _headers,
    ).timeout(Duration(seconds: 5));
    
    final isConnected = response.statusCode == 200;
    print('Test connexion (fallback): ${response.statusCode} - ${isConnected ? 'OK' : 'KO'}');
    return isConnected;
    
  } on TimeoutException catch (e) {
    print('Timeout test connexion (fallback): $e');
    return false;
  } catch (e) {
    print('Erreur test connexion (fallback): $e');
    return false;
  }
}
  // === MÉTHODES CRUD POUR LES MOTS ===

  // Récupérer tous les mots avec filtres
  // Remplacez votre méthode getWords dans ApiService par celle-ci :

Future<List<WordModel>> getWords({
  String? search,
  String? category,
  int? difficulty,
  int? limit,
  int? offset,
}) async {
  final queryParams = <String, String>{};
  if (search != null && search.isNotEmpty) queryParams['search'] = search;
  if (category != null && category.isNotEmpty) queryParams['category'] = category;
  if (difficulty != null) queryParams['difficulty'] = difficulty.toString();
  if (limit != null) queryParams['limit'] = limit.toString();
  if (offset != null) queryParams['offset'] = offset.toString();

  final uri = Uri.parse('$_baseUrl/words').replace(queryParameters: queryParams);
  
  final response = await _handleRequest(() => http.get(uri, headers: _headers));
  final data = json.decode(response.body);
  
  // Debug: afficher la structure de la réponse
  print('Type de data: ${data.runtimeType}');
  print('Contenu de data: $data');
  
  // Gérer différents formats de réponse
  List<dynamic> wordsList;
  
  if (data is List) {
    // Si la réponse est directement un tableau
    wordsList = data;
  } else if (data is Map) {
    // Si la réponse est un objet avec une clé 'words'
    if (data.containsKey('words')) {
      wordsList = data['words'] as List;
    } else if (data.containsKey('data')) {
      wordsList = data['data'] as List;
    } else {
      // Si l'objet contient directement les données
      wordsList = [data];
    }
  } else {
    throw ApiException('Format de réponse inattendu: ${data.runtimeType}');
  }
  
  return wordsList
      .map((wordJson) => WordModel.fromMap(_convertFromApi(wordJson as Map<String, dynamic>)))
      .toList();
}

  // Rechercher des mots
  Future<List<WordModel>> searchWords(String query) async {
    return getWords(search: query);
  }

  // Récupérer des mots par catégorie
  Future<List<WordModel>> getWordsByCategory(String category) async {
    return getWords(category: category);
  }

  // Récupérer un mot spécifique par ID
  Future<WordModel> getWord(int id) async {
    final response = await _handleRequest(() => 
      http.get(Uri.parse('$_baseUrl/words/$id'), headers: _headers)
    );

    final data = json.decode(response.body);
    return WordModel.fromMap(_convertFromApi(data));
  }

  // Ajouter un nouveau mot
  Future<WordModel> createWord(WordModel word) async {
    final response = await _handleRequest(() => http.post(
      Uri.parse('$_baseUrl/words'),
      headers: _headers,
      body: json.encode(_convertToApi(word)),
    ));

    final data = json.decode(response.body);
    // Retourner le mot avec le nouvel ID
    return word.copyWith(id: data['id']);
  }

  // Modifier un mot existant
  Future<void> updateWord(WordModel word) async {
    await _handleRequest(() => http.put(
      Uri.parse('$_baseUrl/words/${word.id}'),
      headers: _headers,
      body: json.encode(_convertToApi(word)),
    ));
  }

  // Supprimer un mot
  Future<void> deleteWord(int id) async {
    await _handleRequest(() => 
      http.delete(Uri.parse('$_baseUrl/words/$id'), headers: _headers)
    );
  }

  // === GESTION DES FAVORIS ===

  // Basculer le statut favori d'un mot
  Future<bool> toggleFavorite(int wordId) async {
    final response = await _handleRequest(() => 
      http.post(Uri.parse('$_baseUrl/favorites/$wordId'), headers: _headers)
    );

    final data = json.decode(response.body);
    return data['isFavorite'] ?? false;
  }

  // Récupérer les mots favoris
 Future<List<WordModel>> getFavoriteWords() async {
  final response = await _handleRequest(() => 
    http.get(Uri.parse('$_baseUrl/favorites'), headers: _headers)
  );

  final data = json.decode(response.body);
  
  // Debug
  print('Favorites response type: ${data.runtimeType}');
  print('Favorites response: $data');
  
  // Gérer différents formats de réponse
  List<dynamic> wordsList;
  
  if (data is List) {
    wordsList = data;
  } else if (data is Map && data.containsKey('favorites')) {
    wordsList = data['favorites'] as List;
  } else if (data is Map && data.containsKey('words')) {
    wordsList = data['words'] as List;
  } else if (data is Map && data.containsKey('data')) {
    wordsList = data['data'] as List;
  } else {
    // Si pas de favoris, retourner liste vide
    return [];
  }
  
  return wordsList
      .map((wordJson) => WordModel.fromMap(_convertFromApi(wordJson as Map<String, dynamic>)))
      .toList();
}

// Récupérer les catégories avec statistiques
Future<List<CategoryStats>> getCategories() async {
  final response = await _handleRequest(() => 
    http.get(Uri.parse('$_baseUrl/categories'), headers: _headers)
  );

  final data = json.decode(response.body);
  
  // Debug
  print('Categories response type: ${data.runtimeType}');
  print('Categories response: $data');
  
  List<dynamic> categoriesList;
  
  if (data is List) {
    categoriesList = data;
  } else if (data is Map && data.containsKey('categories')) {
    categoriesList = data['categories'] as List;
  } else if (data is Map && data.containsKey('data')) {
    categoriesList = data['data'] as List;
  } else {
    return [];
  }
  
  return categoriesList
      .map((json) => CategoryStats.fromJson(json as Map<String, dynamic>))
      .toList();
}

  // === GESTION DES PROGRÈS ===

  // Mettre à jour les progrès d'apprentissage
  Future<void> updateProgress(int wordId, {bool? isCorrect, bool? isLearned}) async {
    await _handleRequest(() => http.post(
      Uri.parse('$_baseUrl/progress/$wordId'),
      headers: _headers,
      body: json.encode({
        'isCorrect': isCorrect,
        'isLearned': isLearned,
      }),
    ));
  }

  // Incrémenter le compteur de vues d'un mot
  Future<void> incrementWordView(int wordId) async {
    // Le serveur PostgreSQL gère cela automatiquement lors de la récupération d'un mot
    await getWord(wordId);
  }

  // === STATISTIQUES ET CATÉGORIES ===

  // Récupérer les catégories avec statistiques
  


  // Récupérer les statistiques générales
  // Dans votre méthode qui traite les statistiques
Future<AppStats> getStats() async {
  try {
    final response = await _handleRequest(() => 
      http.get(Uri.parse('$_baseUrl/stats'), headers: _headers)
    );

    final data = json.decode(response.body);
    
    // Conversion manuelle des nombres
    return AppStats(
      totalWords: int.tryParse(data['totalWords']?.toString() ?? '0') ?? 0,
      totalCategories: int.tryParse(data['totalCategories']?.toString() ?? '0') ?? 0,
      avgDifficulty: double.tryParse(data['avgDifficulty']?.toString() ?? '0') ?? 0.0,
      learnedWords: int.tryParse(data['learnedWords']?.toString() ?? '0') ?? 0,
      totalFavorites: int.tryParse(data['totalFavorites']?.toString() ?? '0') ?? 0,
      wordsThisWeek: int.tryParse(data['wordsThisWeek']?.toString() ?? '0') ?? 0,
      completionRate: int.tryParse(data['completionRate']?.toString() ?? '0') ?? 0,
    );
  } catch (e) {
    print('Erreur API stats: $e');
    rethrow;
  }
}

  // === IMPORT/EXPORT ===

  // Exporter les données
  Future<String> exportData({String format = 'json'}) async {
    final response = await _handleRequest(() => http.get(
      Uri.parse('$_baseUrl/export').replace(queryParameters: {'format': format}),
      headers: _headers,
    ));

    return response.body;
  }

  // === MÉTHODES DE SYNCHRONISATION (SIMPLIFIÉES) ===

  // Synchronisation complète (pour compatibilité, mais plus simple)
  Future<SyncResult> syncWords({int? lastSyncTimestamp}) async {
    // Avec une base centralisée, la "synchronisation" c'est juste récupérer tous les mots
    final words = await getWords();
    
    return SyncResult(
      words: words,
      syncTime: DateTime.now().millisecondsSinceEpoch ~/ 1000,
      total: words.length,
    );
  }
String _convertArrayToString(dynamic data) {
  if (data == null) return '';
  
  if (data is List) {
    // Filtrer les null/empty et convertir en string avec séparateur |
    final nonEmptyItems = data.where((item) => 
      item != null && item.toString().trim().isNotEmpty);
    return nonEmptyItems.map((item) => item.toString().trim()).join('|');
  } else if (data is String) {
    return data.trim();
  }
  
  return data?.toString()?.trim() ?? '';
}
 
// Conversion des données depuis l'API vers le format Flutter
Map<String, dynamic> _convertFromApi(Map<String, dynamic> apiData) {
  // Fonction pour convertir les nombres
  dynamic convertNumber(dynamic value) {
    if (value == null) return 0;
    if (value is int) return value;
    if (value is double) return value;
    if (value is String) {
      return double.tryParse(value) ?? int.tryParse(value) ?? 0;
    }
    return 0;
  }

  // Fonction pour convertir les dates
  dynamic convertDate(dynamic dateValue) {
    if (dateValue == null) return null;
    if (dateValue is int) {
      // Si c'est un timestamp en secondes, convertir en millisecondes
      return dateValue < 10000000000 ? dateValue * 1000 : dateValue;
    }
    if (dateValue is String) {
      // Si c'est une chaîne numérique (timestamp en secondes)
      if (RegExp(r'^\d+$').hasMatch(dateValue)) {
        final timestamp = int.tryParse(dateValue);
        return timestamp != null ? timestamp * 1000 : null;
      }
      // Si c'est une date string ISO
      try {
        return DateTime.parse(dateValue).millisecondsSinceEpoch;
      } catch (e) {
        return null;
      }
    }
    return null;
  }

  return {
    'id': apiData['id'],
    'zarma_word': apiData['zarmaWord'] ?? apiData['zarma_word'],
    'zarma_example': apiData['zarmaExample'] ?? apiData['zarma_example'],
    'french_meaning': apiData['frenchMeaning'] ?? apiData['french_meaning'],
    'french_example': apiData['frenchExample'] ?? apiData['french_example'],
    'category': apiData['category'],
    'pronunciation': apiData['pronunciation'],
    'difficulty_level': convertNumber(apiData['difficultyLevel'] ?? apiData['difficulty_level'] ?? 1),
    'etymology': apiData['etymology'],
    'synonyms': _convertArrayToString(apiData['synonyms']),
    'antonyms': _convertArrayToString(apiData['antonyms']),
    'related_words': _convertArrayToString(apiData['relatedWords'] ?? apiData['related_words']),
    'usage_frequency': convertNumber(apiData['usageFrequency'] ?? apiData['usage_frequency'] ?? 0),
    'audio_path': apiData['audioPath'] ?? apiData['audio_path'],
    'image_path': apiData['imagePath'] ?? apiData['image_path'],
    'is_favorite': apiData['isFavorite'] ?? false,
    'is_learned': apiData['isLearned'] ?? false,
    'view_count': convertNumber(apiData['viewCount'] ?? 0),
    'practice_count': convertNumber(apiData['practiceCount'] ?? 0),
  };
}
  // Conversion des données Flutter vers le format API


  // === UTILITAIRES ===

  // Générer un ID unique pour l'appareil
  Future<String> _getDeviceId() async {
    String? deviceId = _prefs.getString('device_id');
    if (deviceId == null) {
      deviceId = DateTime.now().millisecondsSinceEpoch.toString();
      await _prefs.setString('device_id', deviceId);
    }
    return deviceId;
  }

  // Add this method to your ApiService class in apiservice.dart

/// Récupérer les mots récents/modifiés depuis un timestamp donné
Future<List<WordModel>> getRecentWords(DateTime? since) async {
  final queryParams = <String, String>{};
  
  if (since != null) {
    // Convertir en timestamp Unix (secondes)
    final timestamp = since.millisecondsSinceEpoch ~/ 1000;
    queryParams['since'] = timestamp.toString();
  }

  final uri = Uri.parse('$_baseUrl/words/recent').replace(queryParameters: queryParams);
  
  final response = await _handleRequest(() => http.get(uri, headers: _headers));
  final data = json.decode(response.body);
  
  return (data['words'] as List)
      .map((wordJson) => WordModel.fromMap(_convertFromApi(wordJson)))
      .toList();
}

  // Méthode pour diagnostiquer la connexion
  Future<Map<String, dynamic>> diagnosisConnection() async {
    final diagnosis = <String, dynamic>{};
    
    try {
      diagnosis['configured_url'] = _baseUrl;
      diagnosis['timestamp'] = DateTime.now().toIso8601String();
      
      // Test de base
      final testResult = await testConnection();
      diagnosis['connection_test'] = testResult;
      
      if (testResult) {
        // Test des endpoints principaux
        try {
          final words = await getWords(limit: 1);
          diagnosis['words_endpoint'] = 'OK';
          diagnosis['sample_word_count'] = words.length;
        } catch (e) {
          diagnosis['words_endpoint'] = 'ERROR: $e';
        }
        
        try {
          final categories = await getCategories();
          diagnosis['categories_endpoint'] = 'OK';
          diagnosis['categories_count'] = categories.length;
        } catch (e) {
          diagnosis['categories_endpoint'] = 'ERROR: $e';
        }
      }
      
    } catch (e) {
      diagnosis['error'] = e.toString();
    }
    
    return diagnosis;
  }

  void dispose() {
    _connectionCheckTimer?.cancel();
  }
}

// Classes pour les résultats de synchronisation et statistiques (inchangées)
class SyncResult {
  final List<WordModel> words;
  final int syncTime;
  final int total;

  SyncResult({
    required this.words,
    required this.syncTime,
    required this.total,
  });
}

class CategoryStats {
  final String name;
  final int wordCount;
  final double avgDifficulty;
  final int learnedCount;
  final int progressPercentage;

  CategoryStats({
    required this.name,
    required this.wordCount,
    required this.avgDifficulty,
    required this.learnedCount,
    required this.progressPercentage,
  });

  factory CategoryStats.fromJson(Map<String, dynamic> json) {
    return CategoryStats(
      name: json['name'],
      wordCount: json['wordCount'],
      avgDifficulty: json['avgDifficulty']?.toDouble() ?? 0.0,
      learnedCount: json['learnedCount'],
      progressPercentage: json['progressPercentage'],
    );
  }
}

class AppStats {
  final int totalWords;
  final int totalCategories;
  final double avgDifficulty;
  final int learnedWords;
  final int totalFavorites;
  final int wordsThisWeek;
  final int completionRate;

  AppStats({
    required this.totalWords,
    required this.totalCategories,
    required this.avgDifficulty,
    required this.learnedWords,
    required this.totalFavorites,
    required this.wordsThisWeek,
    required this.completionRate,
  });

  factory AppStats.fromJson(Map<String, dynamic> json) {
    return AppStats(
      totalWords: json['totalWords'],
      totalCategories: json['totalCategories'],
      avgDifficulty: json['avgDifficulty']?.toDouble() ?? 0.0,
      learnedWords: json['learnedWords'],
      totalFavorites: json['totalFavorites'],
      wordsThisWeek: json['wordsThisWeek'],
      completionRate: json['completionRate'],
    );
  }
}

class ApiException implements Exception {
  final String message;
  
  ApiException(this.message);
  
  @override
  String toString() => 'ApiException: $message';
}