import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:zarma_dictionary/models/notification_model.dart';
import 'package:zarma_dictionary/widgets/notification_bottom_sheet.dart';

class NotificationService {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  WebSocketChannel? _channel;
  final StreamController<List<NotificationModel>> _notificationsController = 
      StreamController<List<NotificationModel>>.broadcast();
  final StreamController<NotificationModel> _newNotificationController = 
      StreamController<NotificationModel>.broadcast();

  List<NotificationModel> _notifications = [];
  Timer? _reconnectTimer;
  bool _isConnecting = false;
  String? _serverUrl;

  // Map pour garder trace des notifications lues localement
  final Set<String> _localReadNotifications = <String>{};

  // Streams publics
  Stream<List<NotificationModel>> get notificationsStream => _notificationsController.stream;
  Stream<NotificationModel> get newNotificationStream => _newNotificationController.stream;
  List<NotificationModel> get notifications => List.unmodifiable(_notifications);
  int get unreadCount => _notifications.where((n) => !n.isRead && !n.isExpired).length;

  Future<void> initialize(String serverUrl) async {
    _serverUrl = serverUrl;
    print('🚀 Initialisation NotificationService avec: $serverUrl');
    
    // 1. Charger les IDs des notifications lues localement
    await _loadReadNotificationIds();
    print('📖 IDs notifications lues chargés: ${_localReadNotifications.length}');
    
    // 2. Charger les notifications stockées localement
    await _loadStoredNotifications();
    print('💾 Notifications locales chargées: ${_notifications.length}');
    
    // 3. Charger depuis l'API et fusionner avec les données locales
    await loadNotificationsFromAPI();
    print('🌐 Notifications API chargées et fusionnées: ${_notifications.length}');
    
    // 4. Connecter le WebSocket
    await _connectWebSocket();
    print('🔌 WebSocket initialisé');
    
    print('✅ NotificationService initialisé - Total notifications: ${_notifications.length}');
  }

  // Nouvelle méthode pour sauvegarder les IDs des notifications lues
  Future<void> _saveReadNotificationIds() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setStringList('read_notification_ids', _localReadNotifications.toList());
      print('💾 IDs notifications lues sauvegardés: ${_localReadNotifications.length}');
    } catch (error) {
      print('⚠️ Erreur sauvegarde IDs lus: $error');
    }
  }

  // Nouvelle méthode pour charger les IDs des notifications lues
  Future<void> _loadReadNotificationIds() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final readIds = prefs.getStringList('read_notification_ids') ?? [];
      _localReadNotifications.addAll(readIds);
      print('📖 IDs notifications lues chargés: ${readIds.length}');
    } catch (error) {
      print('⚠️ Erreur chargement IDs lus: $error');
    }
  }

  Future<void> _connectWebSocket() async {
    if (_isConnecting) {
      print('⏳ Connexion WebSocket déjà en cours...');
      return;
    }

    // Fermer l'ancienne connexion si elle existe
    if (_channel != null) {
      try {
        await _channel!.sink.close();
      } catch (e) {
        print('Erreur fermeture ancienne connexion: $e');
      }
      _channel = null;
    }

    try {
      _isConnecting = true;
      print('🔌 Connexion WebSocket vers: ${_serverUrl}/api/ws');

      final wsUrl = _serverUrl!.replaceAll('http', 'ws') + '/api/ws';
      _channel = WebSocketChannel.connect(Uri.parse(wsUrl));

      // Attendre que la connexion soit établie
      await _channel!.ready;
      print('✅ WebSocket connecté avec succès');

      // Écouter les messages
      _channel!.stream.listen(
        _handleWebSocketMessage,
        onError: _handleWebSocketError,
        onDone: _handleWebSocketDisconnect,
      );

      // Envoyer un ping initial après la connexion
      Future.delayed(Duration(seconds: 1), () {
        _sendPing();
      });

      // Timer pour les pings réguliers
      Timer.periodic(Duration(seconds: 30), (timer) {
        if (_channel != null && _channel!.closeCode == null) {
          _sendPing();
        } else {
          print('⚠️ Timer ping annulé - channel fermé');
          timer.cancel();
        }
      });

      _isConnecting = false;

    } catch (error) {
      _isConnecting = false;
      _channel = null;
      print('❌ Erreur connexion WebSocket: $error');
      _scheduleReconnect();
    }
  }

  void _handleWebSocketMessage(dynamic data) {
    try {
      final message = json.decode(data.toString());
      print('📨 Message WebSocket reçu: ${message['type']}');

      switch (message['type']) {
        case 'welcome':
          print('🎉 Message de bienvenue WebSocket reçu');
          print('🆔 Client ID: ${message['clientId']}');
          
          // NE PAS demander l'historique si nous avons déjà des notifications
          if (_notifications.isEmpty) {
            Future.delayed(Duration(seconds: 1), () {
              _requestExistingNotifications();
            });
          }
          break;

        case 'notification':
          print('🔔 Notification reçue');
          try {
            final notificationData = message['data'];
            print('📋 Données notification: $notificationData');
            
            final notification = NotificationModel.fromJson(notificationData);
            print('✅ Notification parsée: ${notification.title} - ${notification.message}');
            
            _addNotification(notification, isFromWebSocket: true);
            _newNotificationController.add(notification);
            
          } catch (e) {
            print('❌ Erreur parsing notification: $e');
            print('📋 Données problématiques: ${message['data']}');
          }
          break;

        case 'notifications_history':
          print('📚 Historique des notifications reçu');
          try {
            final notificationsData = message['data'] as List;
            print('📊 Nombre de notifications historiques: ${notificationsData.length}');
            
            for (int i = 0; i < notificationsData.length; i++) {
              final notifData = notificationsData[i];
              try {
                final notification = NotificationModel.fromJson(notifData);
                print('📨 Notification historique $i: ${notification.title}');
                _addNotification(notification, isFromWebSocket: true);
              } catch (e) {
                print('❌ Erreur notification historique $i: $e');
              }
            }
            print('✅ ${notificationsData.length} notifications historiques ajoutées');
            
          } catch (e) {
            print('❌ Erreur traitement historique: $e');
          }
          break;

        case 'pong':
          print('🏓 Pong reçu du serveur');
          break;

        case 'heartbeat_ack':
          print('💗 Heartbeat ACK reçu');
          break;

        case 'server_shutdown':
          print('⚠️ Serveur en cours d\'arrêt: ${message['message']}');
          break;

        default:
          print('❓ Message WebSocket inconnu: ${message['type']}');
          print('📄 Données: $message');
      }
    } catch (error) {
      print('❌ Erreur traitement message WebSocket: $error');
      print('📄 Message brut: $data');
    }
  }

  void _handleWebSocketError(dynamic error) {
    print('❌ Erreur WebSocket: $error');
    _scheduleReconnect();
  }

  void _handleWebSocketDisconnect() {
    print('🔌 WebSocket déconnecté');
    _channel = null;
    _scheduleReconnect();
  }

  void _scheduleReconnect() {
    if (_reconnectTimer?.isActive == true) return;

    _reconnectTimer = Timer(Duration(seconds: 10), () {
      if (_channel == null && _serverUrl != null) {
        print('🔄 Tentative de reconnexion WebSocket...');
        _connectWebSocket();
      }
    });
  }

  void _requestExistingNotifications() {
    if (_channel != null && _channel!.closeCode == null) {
      try {
        _channel!.sink.add(json.encode({
          'type': 'request_notifications',
          'timestamp': DateTime.now().millisecondsSinceEpoch,
        }));
        print('📨 Demande de notifications existantes envoyée');
      } catch (error) {
        print('❌ Erreur demande notifications: $error');
      }
    } else {
      print('⚠️ Impossible de demander notifications - channel fermé');
    }
  }

  Future<void> loadNotificationsFromAPI() async {
    try {
      print('🌐 Chargement des notifications depuis l\'API...');
      
      final uri = Uri.parse('$_serverUrl/api/notifications');
      final response = await http.get(uri);
      
      print('📡 Réponse API: ${response.statusCode}');
      
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final notificationsData = data['notifications'] as List;
        
        print('📨 ${notificationsData.length} notifications reçues de l\'API');
        
        for (int i = 0; i < notificationsData.length; i++) {
          try {
            final notifData = notificationsData[i];
            print('🔍 Parsing notification API $i: ${notifData['title']}');
            
            final notification = NotificationModel.fromJson(notifData);
            print('✅ Notification API $i parsée: ${notification.title} - ${notification.message}');
            
            // IMPORTANT: Fusionner avec les données locales
            _addNotification(notification, isFromAPI: true);
          } catch (e) {
            print('❌ Erreur parsing notification API $i: $e');
          }
        }
        
        print('✅ Notifications API chargées et fusionnées avec succès');
      } else {
        print('❌ Erreur API notifications: ${response.statusCode}');
        print('📄 Corps réponse: ${response.body}');
      }
    } catch (error) {
      print('❌ Erreur chargement notifications API: $error');
    }
  }

  void _sendPing() {
    if (_channel != null && _channel!.closeCode == null) {
      try {
        _channel!.sink.add(json.encode({
          'type': 'ping',
          'timestamp': DateTime.now().millisecondsSinceEpoch,
        }));
        print('🏓 Ping envoyé');
      } catch (error) {
        print('❌ Erreur envoi ping: $error');
        _scheduleReconnect();
      }
    } else {
      print('⚠️ Channel WebSocket non disponible pour ping');
      _scheduleReconnect();
    }
  }

  void _addNotification(NotificationModel notification, {bool isFromAPI = false, bool isFromWebSocket = false}) {
    print('➕ Ajout notification: ${notification.title}');
    
    // Vérifier si cette notification est marquée comme lue localement
    bool shouldBeRead = _localReadNotifications.contains(notification.id);
    
    // Si la notification doit être marquée comme lue mais ne l'est pas, la corriger
    NotificationModel correctedNotification = notification;
    if (shouldBeRead && !notification.isRead) {
      print('🔄 Correction statut lecture pour: ${notification.id}');
      correctedNotification = NotificationModel(
        id: notification.id,
        title: notification.title,
        message: notification.message,
        type: notification.type,
        priority: notification.priority,
        timestamp: notification.timestamp,
        isRead: true, // FORCER à true
        expiresAt: notification.expiresAt,
        isHistorical: notification.isHistorical,
        target: notification.target,
      );
    }
    
    // Éviter les doublons
    final existingIndex = _notifications.indexWhere((n) => n.id == correctedNotification.id);
    
    if (existingIndex != -1) {
      print('🔄 Notification existante mise à jour: ${correctedNotification.id}');
      // Garder l'état de lecture local si c'est une mise à jour depuis l'API
      if (isFromAPI && _notifications[existingIndex].isRead) {
        correctedNotification = NotificationModel(
          id: correctedNotification.id,
          title: correctedNotification.title,
          message: correctedNotification.message,
          type: correctedNotification.type,
          priority: correctedNotification.priority,
          timestamp: correctedNotification.timestamp,
          isRead: true, // Garder l'état local
          expiresAt: correctedNotification.expiresAt,
          isHistorical: correctedNotification.isHistorical,
          target: correctedNotification.target,
        );
      }
      _notifications[existingIndex] = correctedNotification;
    } else {
      print('🆕 Nouvelle notification ajoutée: ${correctedNotification.id}');
      _notifications.insert(0, correctedNotification);
    }

    // Nettoyer les notifications expirées
    final beforeCount = _notifications.length;
    _notifications.removeWhere((n) => n.isExpired);
    final afterCount = _notifications.length;
    
    if (beforeCount != afterCount) {
      print('🗑️ ${beforeCount - afterCount} notifications expirées supprimées');
    }

    // Trier par priorité et date
    _notifications.sort((a, b) {
      final priorityCompare = b.priorityLevel.compareTo(a.priorityLevel);
      if (priorityCompare != 0) return priorityCompare;
      return b.timestamp.compareTo(a.timestamp);
    });

    // Limiter le nombre de notifications
    if (_notifications.length > 100) {
      _notifications = _notifications.take(100).toList();
      print('✂️ Notifications limitées à 100');
    }

    print('📊 Total notifications après ajout: ${_notifications.length}');
    
    // Mettre à jour le stream
    if (!_notificationsController.isClosed) {
      _notificationsController.add(List.unmodifiable(_notifications));
    }
    _saveNotifications();
  }

  Future<void> markAsRead(String notificationId) async {
    print('📖 Tentative marquage lecture: $notificationId');
    
    final index = _notifications.indexWhere((n) => n.id == notificationId);
    if (index != -1) {
      print('✅ Notification trouvée à l\'index $index');
      print('🔍 État avant: isRead = ${_notifications[index].isRead}');
      
      // Ajouter l'ID à la liste des notifications lues
      _localReadNotifications.add(notificationId);
      await _saveReadNotificationIds();
      
      // Créer manuellement une nouvelle notification
      final originalNotification = _notifications[index];
      final updatedNotification = NotificationModel(
        id: originalNotification.id,
        title: originalNotification.title,
        message: originalNotification.message,
        type: originalNotification.type,
        priority: originalNotification.priority,
        timestamp: originalNotification.timestamp,
        isRead: true, // FORCER à true
        expiresAt: originalNotification.expiresAt,
        isHistorical: originalNotification.isHistorical,
        target: originalNotification.target,
      );
      
      _notifications[index] = updatedNotification;
      
      print('🔍 État après: isRead = ${_notifications[index].isRead}');
      print('🔄 Nouvelle notification créée avec isRead = ${updatedNotification.isRead}');
      
      // Forcer la mise à jour du stream
      if (!_notificationsController.isClosed) {
        _notificationsController.add(List.unmodifiable(_notifications));
      }
      
      await _saveNotifications();

      print('✅ Notification $notificationId marquée comme lue avec succès');
    } else {
      print('❌ Notification $notificationId non trouvée');
    }
  }

  Future<void> markAllAsRead() async {
    print('📚 Marquage de toutes les notifications comme lues');
    
    bool hasChanges = false;
    List<NotificationModel> updatedNotifications = [];
    
    for (int i = 0; i < _notifications.length; i++) {
      final notification = _notifications[i];
      if (!notification.isRead) {
        // Ajouter l'ID à la liste des notifications lues
        _localReadNotifications.add(notification.id);
        
        // Créer manuellement une nouvelle notification
        final updatedNotification = NotificationModel(
          id: notification.id,
          title: notification.title,
          message: notification.message,
          type: notification.type,
          priority: notification.priority,
          timestamp: notification.timestamp,
          isRead: true, // FORCER à true
          expiresAt: notification.expiresAt,
          isHistorical: notification.isHistorical,
          target: notification.target,
        );
        updatedNotifications.add(updatedNotification);
        hasChanges = true;
        print('✅ Notification ${notification.id} marquée comme lue');
      } else {
        updatedNotifications.add(notification);
      }
    }
    
    if (hasChanges) {
      // Sauvegarder les IDs des notifications lues
      await _saveReadNotificationIds();
      
      _notifications = updatedNotifications;
      print('✅ ${_notifications.where((n) => n.isRead).length} notifications marquées comme lues');
      
      // Forcer la mise à jour du stream
      if (!_notificationsController.isClosed) {
        _notificationsController.add(List.unmodifiable(_notifications));
      }
      
      await _saveNotifications();
    }
  }

  void debugPrintNotifications() {
    print('=== DEBUG NOTIFICATIONS ===');
    print('📊 Total: ${_notifications.length}');
    print('📖 IDs lus localement: ${_localReadNotifications.length}');
    for (int i = 0; i < _notifications.length; i++) {
      final n = _notifications[i];
      final isLocalRead = _localReadNotifications.contains(n.id);
      print('$i. ${n.title} - Lu: ${n.isRead} - Local: $isLocalRead - Expiré: ${n.isExpired}');
    }
    print('=========================');
  }

  Future<void> clearExpiredNotifications() async {
    final originalCount = _notifications.length;
    _notifications.removeWhere((n) => n.isExpired);
    
    if (_notifications.length != originalCount) {
      _notificationsController.add(_notifications);
      _saveNotifications();
      print('🗑️ ${originalCount - _notifications.length} notifications expirées supprimées');
    }
  }

  Future<void> _saveNotifications() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final notificationsJson = _notifications.map((n) => n.toJson()).toList();
      await prefs.setString('cached_notifications', json.encode(notificationsJson));
    } catch (error) {
      print('⚠️ Erreur sauvegarde notifications: $error');
    }
  }

  Future<void> _loadStoredNotifications() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final notificationsString = prefs.getString('cached_notifications');
      
      if (notificationsString != null) {
        final notificationsJson = json.decode(notificationsString) as List;
        _notifications = notificationsJson
            .map((json) => NotificationModel.fromJson(json))
            .where((n) => !n.isExpired)
            .toList();
        
        // Appliquer les statuts de lecture locaux
        for (int i = 0; i < _notifications.length; i++) {
          if (_localReadNotifications.contains(_notifications[i].id) && !_notifications[i].isRead) {
            _notifications[i] = NotificationModel(
              id: _notifications[i].id,
              title: _notifications[i].title,
              message: _notifications[i].message,
              type: _notifications[i].type,
              priority: _notifications[i].priority,
              timestamp: _notifications[i].timestamp,
              isRead: true,
              expiresAt: _notifications[i].expiresAt,
              isHistorical: _notifications[i].isHistorical,
              target: _notifications[i].target,
            );
          }
        }
        
        _notifications.sort((a, b) {
          final priorityCompare = b.priorityLevel.compareTo(a.priorityLevel);
          if (priorityCompare != 0) return priorityCompare;
          return b.timestamp.compareTo(a.timestamp);
        });

        _notificationsController.add(_notifications);
        print('📱 ${_notifications.length} notifications chargées du cache');
      }
    } catch (error) {
      print('⚠️ Erreur chargement notifications: $error');
      _notifications = [];
    }
  }

  Future<void> dispose() async {
    _reconnectTimer?.cancel();
    await _channel?.sink.close();
    _channel = null;
    await _notificationsController.close();
    await _newNotificationController.close();
  }
}