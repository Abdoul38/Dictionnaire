import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/notification_model.dart';

class NotificationStorage {
  static const String _notificationsKey = 'stored_notifications';
  static const String _settingsKey = 'notification_settings';

  static Future<void> saveNotifications(List<NotificationModel> notifications) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final notificationsJson = notifications.map((n) => n.toJson()).toList();
      await prefs.setString(_notificationsKey, json.encode(notificationsJson));
    } catch (error) {
      print('Erreur sauvegarde notifications: $error');
    }
  }

  static Future<List<NotificationModel>> loadNotifications() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final notificationsString = prefs.getString(_notificationsKey);
      
      if (notificationsString != null) {
        final notificationsJson = json.decode(notificationsString) as List;
        return notificationsJson
            .map((json) => NotificationModel.fromJson(json))
            .where((n) => !n.isExpired)
            .toList();
      }
    } catch (error) {
      print('Erreur chargement notifications: $error');
    }
    
    return [];
  }

  static Future<void> saveSettings(Map<String, dynamic> settings) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_settingsKey, json.encode(settings));
    } catch (error) {
      print('Erreur sauvegarde paramètres: $error');
    }
  }

  static Future<Map<String, dynamic>> loadSettings() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final settingsString = prefs.getString(_settingsKey);
      
      if (settingsString != null) {
        return json.decode(settingsString) as Map<String, dynamic>;
      }
    } catch (error) {
      print('Erreur chargement paramètres: $error');
    }
    
    return {
      'notifications_enabled': true,
      'sound_enabled': true,
      'vibration_enabled': true,
      'notification_types': {
        'info': true,
        'success': true,
        'warning': true,
        'error': true,
      },
    };
  }

  static Future<void> clearNotifications() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_notificationsKey);
    } catch (error) {
      print('Erreur suppression notifications: $error');
    }
  }

  static Future<void> clearSettings() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_settingsKey);
    } catch (error) {
      print('Erreur suppression paramètres: $error');
    }
  }
}