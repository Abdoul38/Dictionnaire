import '../models/word_model.dart';

class DictionaryData {
  static List<WordModel> getSampleWords() {
    return [
      WordModel(
        zarmaWord: "baani",
        zarmaExample: "Ay ga baani ne cindi.",
        frenchMeaning: "porte",
        frenchExample: "Je ferme la porte.",
        category: "nom",
      ),
      WordModel(
        zarmaWord: "hinkaa",
        zarmaExample: "Hinkaa no ga koy beeri ra.",
        frenchMeaning: "eau",
        frenchExample: "L'eau coule dans la rivière.",
        category: "nom",
      ),
      WordModel(
        zarmaWord: "gooro",
        zarmaExample: "Gooro kul si tonton.",
        frenchMeaning: "noix de cola",
        frenchExample: "Toutes les noix de cola sont amères.",
        category: "nom",
      ),
      WordModel(
        zarmaWord: "kaa",
        zarmaExample: "Kaa no ga hun alhaali.",
        frenchMeaning: "maison",
        frenchExample: "La maison est très belle.",
        category: "nom",
      ),
      WordModel(
        zarmaWord: "ay",
        zarmaExample: "Ay ga koy skul.",
        frenchMeaning: "je",
        frenchExample: "Je vais à l'école.",
        category: "pronom",
      ),
    ];
  }

  static List<String> getCategories() {
    return [
      "nom",
      "verbe",
      "adjectif",
      "adverbe",
      "pronom",
      "préposition",
      "conjonction",
      "interjection"
    ];
  }
}