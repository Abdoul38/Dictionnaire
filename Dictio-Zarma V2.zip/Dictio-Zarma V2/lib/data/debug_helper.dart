// Ajoutez cette classe utilitaire dans un nouveau fichier debug_helper.dart

import 'package:flutter/material.dart';
import 'package:path/path.dart';
import '../services/apiservice.dart';

class ApiDebugHelper {
  
  static Future<void> showConnectionDialog(BuildContext context) async {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => FutureBuilder<Map<String, dynamic>>(
        future: ApiService.instance.diagnosisConnection(),
        builder: (context, snapshot) {
          return AlertDialog(
            title: Text('Diagnostic API'),
            content: Container(
              width: double.maxFinite,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (snapshot.connectionState == ConnectionState.waiting)
                    Center(child: CircularProgressIndicator())
                  else if (snapshot.hasError)
                    Text('Erreur: ${snapshot.error}')
                  else if (snapshot.hasData) ...[
                    Text('URL: ${snapshot.data!['configured_url']}'),
                    Divider(),
                    Text('Statut connexion: ${snapshot.data!['connection_test'] ? "✅ OK" : "❌ Échec"}'),
                    if (snapshot.data!.containsKey('words_endpoint'))
                      Text('Endpoint mots: ${snapshot.data!['words_endpoint']}'),
                    if (snapshot.data!.containsKey('categories_endpoint'))
                      Text('Endpoint catégories: ${snapshot.data!['categories_endpoint']}'),
                    if (snapshot.data!.containsKey('error'))
                      Text('Erreur: ${snapshot.data!['error']}', 
                           style: TextStyle(color: Colors.red)),
                  ],
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text('Fermer'),
              ),
              ElevatedButton(
                onPressed: () async {
                  Navigator.pop(context);
                  await _testQuizAndExercises(context);
                },
                child: Text('Tester Quiz/Exercices'),
              ),
            ],
          );
        },
      ),
    );
  }
  
  static Future<void> _testQuizAndExercises(BuildContext context) async {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: Text('Test Quiz/Exercices'),
        content: FutureBuilder<Map<String, dynamic>>(
          future: _runQuizExerciseTest(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 16),
                  Text('Test en cours...'),
                ],
              );
            } else if (snapshot.hasError) {
              return Text('Erreur: ${snapshot.error}');
            } else if (snapshot.hasData) {
              final results = snapshot.data!;
              return Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Quiz: ${results['quiz_status']}'),
                  Text('Nombre de quiz: ${results['quiz_count']}'),
                  Divider(),
                  Text('Exercices: ${results['exercise_status']}'),
                  Text('Nombre d\'exercices: ${results['exercise_count']}'),
                  if (results['errors'] != null) ...[
                    Divider(),
                    Text('Erreurs:', style: TextStyle(color: Colors.red)),
                    Text('${results['errors']}', 
                         style: TextStyle(color: Colors.red, fontSize: 12)),
                  ],
                ],
              );
            }
            return Text('Aucun résultat');
          },
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Fermer'),
          ),
        ],
      ),
    );
  }
  
  static Future<Map<String, dynamic>> _runQuizExerciseTest() async {
    final results = <String, dynamic>{};
    final errors = <String>[];
    
    try {
      final quizzes = await ApiService.instance.getQuizzes();
      results['quiz_status'] = '✅ OK';
      results['quiz_count'] = quizzes.length;
    } catch (e) {
      results['quiz_status'] = '❌ Erreur';
      results['quiz_count'] = 0;
      errors.add('Quiz: $e');
    }
    
    try {
      final exercises = await ApiService.instance.getExercises();
      results['exercise_status'] = '✅ OK';
      results['exercise_count'] = exercises.length;
    } catch (e) {
      results['exercise_status'] = '❌ Erreur';
      results['exercise_count'] = 0;
      errors.add('Exercices: $e');
    }
    
    if (errors.isNotEmpty) {
      results['errors'] = errors.join('\n');
    }
    
    return results;
  }
}

// Utilisez ce helper dans votre quiz_menu_screen.dart
// Ajoutez ce bouton dans votre AppBar ou quelque part visible :

Widget _buildDebugButton() {
  return IconButton(
    icon: Icon(Icons.bug_report, color: Colors.white),
    onPressed: () => ApiDebugHelper.showConnectionDialog(context as BuildContext),
    tooltip: 'Debug API',
  );
}