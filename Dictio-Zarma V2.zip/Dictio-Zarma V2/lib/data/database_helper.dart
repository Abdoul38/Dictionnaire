import 'dart:async';
import 'dart:io';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import '../models/word_model.dart';
import '../services/apiservice.dart';
import '../models/sync_models.dart';
import '../models/historiquerecherche.dart';

class CacheDatabaseHelper {
  static final CacheDatabaseHelper _instance = CacheDatabaseHelper._internal();
  static Database? _database;

  CacheDatabaseHelper._internal();

  factory CacheDatabaseHelper() => _instance;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
  String databasesPath = await getDatabasesPath();
  String path = join(databasesPath, 'cache_dictionary.db');

  _database = await openDatabase(
    path,
    version: 5, // AUGMENTÉ POUR INCLURE L'HISTORIQUE DE RECHERCHE
    onCreate: _createDatabase,
    onUpgrade: _upgradeDatabase,
  );

  // Initialiser le service API
  await ApiService.instance.initialize();

  return _database!;
}


  Future<Map<String, dynamic>> getSyncConfig() async {
    final db = await database;
    final result = await db.query('sync_config', limit: 1);
    
    if (result.isEmpty) {
      return {
        'auto_sync_enabled': true,
        'sync_on_wifi_only': true,
      };
    }
    
    return result.first;
  }

  Future<void> updateSyncConfig(Map<String, dynamic> config) async {
    final db = await database;
    await db.insert(
      'sync_config',
      {
        'id': 1,
        ...config,
        'updated_at': DateTime.now().millisecondsSinceEpoch ~/ 1000,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  // Remplacez les méthodes getSyncStatus et _getStatusMessage dans database_helper.dart

Future<SyncStatus> getSyncStatus() async {
  final isConnected = await _isConnectedToInternet();
  final canConnect = isConnected ? await ApiService.instance.testConnection() : false;
  
  // Vérifier s'il y a des données en cache
  final db = await database;
  final cachedWordsCount = await db.rawQuery('SELECT COUNT(*) as count FROM cached_words');
  final hasCachedData = (cachedWordsCount.first['count'] as int) > 0;
  final wordsCount = cachedWordsCount.first['count'] as int;
  
  // Vérifier la dernière synchronisation
  final lastSyncResult = await db.query(
    'sync_metadata', 
    where: 'key = ?', 
    whereArgs: ['last_full_sync'],
    limit: 1
  );
  
  DateTime? lastSync;
  if (lastSyncResult.isNotEmpty) {
    final timestamp = int.tryParse(lastSyncResult.first['value'] as String);
    if (timestamp != null) {
      lastSync = DateTime.fromMillisecondsSinceEpoch(timestamp * 1000);
    }
  }
  
  // Déterminer si une synchronisation est nécessaire
  bool needsSync = false;
  if (!hasCachedData && isConnected) {
    needsSync = true; // Première synchronisation
  } else if (lastSync != null && isConnected) {
    // Synchroniser si plus de 24 heures depuis la dernière sync
    final daysSinceSync = DateTime.now().difference(lastSync).inDays;
    needsSync = daysSinceSync >= 1;
  }

  // Générer le message de statut
  final statusMessage = await _getStatusMessage(isConnected, canConnect, hasCachedData, needsSync, lastSync, wordsCount);

  return SyncStatus(
    isConnected: isConnected,
    canConnectToServer: canConnect,
    needsSync: needsSync,
    pendingUploads: 0, // Pas d'uploads pour une base centralisée
    statusMessage: statusMessage,
  );
}

Future<String> _getStatusMessage(bool isConnected, bool canConnect, bool hasCachedData, bool needsSync, DateTime? lastSync, int wordsCount) async {
  if (!isConnected) {
    if (hasCachedData) {
      return 'Mode hors ligne - $wordsCount mots disponibles';
    } else {
      return 'Pas de connexion - Aucune donnée en cache';
    }
  } else if (!canConnect) {
    return 'Serveur inaccessible - Utilisation du cache';
  } else if (needsSync) {
    if (!hasCachedData) {
      return 'Première synchronisation nécessaire';
    } else {
      return 'Synchronisation recommandée';
    }
  } else {
    final timeSinceSync = lastSync != null 
        ? DateTime.now().difference(lastSync).inHours 
        : 0;
    return 'Données à jour (sync il y a ${timeSinceSync}h)';
  }
}

  Future<int> _getCachedWordsCount() async {
    final db = await database;
    final result = await db.rawQuery('SELECT COUNT(*) as count FROM cached_words');
    return result.first['count'] as int;
  }

Future<void> _createDatabase(Database db, int version) async {
  // Table cache des mots - CORRECTION: Suppression des commentaires // dans le SQL
  await db.execute('''
  CREATE TABLE cached_words(
    id INTEGER PRIMARY KEY,
    server_id INTEGER NOT NULL,
    zarma_word TEXT NOT NULL,
    zarma_example TEXT NOT NULL,
    french_meaning TEXT NOT NULL,
    french_example TEXT NOT NULL,
    category TEXT,
    pronunciation TEXT,
    difficulty_level INTEGER DEFAULT 1,
    etymology TEXT,
    synonyms TEXT,
    antonyms TEXT,
    related_words TEXT,
    usage_frequency INTEGER DEFAULT 0,
    audio_path TEXT,
    image_path TEXT,
    is_favorite BOOLEAN DEFAULT FALSE,
    is_learned BOOLEAN DEFAULT FALSE,
    view_count INTEGER DEFAULT 0,
    practice_count INTEGER DEFAULT 0,
    cached_at INTEGER DEFAULT (strftime('%s', 'now')),
    updated_at INTEGER DEFAULT 0,
    needs_sync BOOLEAN DEFAULT FALSE
  )
''');
    
  await db.execute('''
    CREATE TABLE sync_config(
      id INTEGER PRIMARY KEY,
      auto_sync_enabled BOOLEAN DEFAULT TRUE,
      sync_on_wifi_only BOOLEAN DEFAULT TRUE,
      updated_at INTEGER DEFAULT (strftime('%s', 'now'))
    )
  ''');

  // Table des statistiques en cache
  await db.execute('''
    CREATE TABLE cached_stats(
      id INTEGER PRIMARY KEY,
      total_words INTEGER DEFAULT 0,
      total_categories INTEGER DEFAULT 0,
      avg_difficulty REAL DEFAULT 0.0,
      learned_words INTEGER DEFAULT 0,
      total_favorites INTEGER DEFAULT 0,
      words_this_week INTEGER DEFAULT 0,
      completion_rate INTEGER DEFAULT 0,
      cached_at INTEGER DEFAULT (strftime('%s', 'now'))
    )
  ''');

  // Table des favoris
  await db.execute('''
    CREATE TABLE cached_favorites(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      server_word_id INTEGER NOT NULL,
      cached_at INTEGER DEFAULT (strftime('%s', 'now'))
    )
  ''');

  // Table des métadonnées de synchronisation
  await db.execute('''
    CREATE TABLE sync_metadata(
      key TEXT PRIMARY KEY,
      value TEXT,
      updated_at INTEGER DEFAULT (strftime('%s', 'now'))
    )
  ''');

  // Table pour l'historique de recherche
  await db.execute('''
    CREATE TABLE search_history(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      query TEXT NOT NULL,
      search_count INTEGER DEFAULT 1,
      last_searched INTEGER DEFAULT (strftime('%s', 'now')),
      results_count INTEGER DEFAULT 0,
      created_at INTEGER DEFAULT (strftime('%s', 'now'))
    )
  ''');

  // Index pour performances
  await db.execute('CREATE INDEX idx_cached_words_server_id ON cached_words(server_id)');
  await db.execute('CREATE INDEX idx_cached_words_zarma ON cached_words(zarma_word)');
  await db.execute('CREATE UNIQUE INDEX idx_cached_words_unique ON cached_words(server_id)');
  await db.execute('CREATE INDEX idx_search_history_query ON search_history(query)');
  await db.execute('CREATE INDEX idx_search_history_last_searched ON search_history(last_searched DESC)');
}

  // === MÉTHODES PRINCIPALES - OFFLINE FIRST ===

  /// Récupère tous les mots - Cache d'abord, puis API si nécessaire
 Future<List<WordModel>> getAllWords({int? limit, bool forceOnline = false}) async {
  // 1. Toujours essayer le cache d'abord
  List<WordModel> cachedWords = await _getCachedWords(limit: limit);
    
    // 2. Si on a des données en cache et pas de force refresh, les retourner
    if (cachedWords.isNotEmpty && !forceOnline) {
      print('📱 Retour des données du cache (${cachedWords.length} mots)');
      return cachedWords;
    }
    
    // 3. Si pas de cache ou force refresh, essayer l'API
    if (await _isConnectedToInternet()) {
      try {
        print('🌐 Tentative de récupération depuis l\'API...');
        final words = await ApiService.instance.getWords();
        await _updateWordsCache(words);
        await _updateSyncMetadata('last_full_sync', DateTime.now().millisecondsSinceEpoch ~/ 1000);
        print('✅ ${words.length} mots récupérés et mis en cache');
        return words;
      } catch (e) {
        print('❌ Erreur API, utilisation du cache: $e');
        // Retourner le cache même s'il est vide
        return cachedWords;
      }
    }
    
    // 4. Pas de connexion, retourner le cache (même vide)
    print('📵 Pas de connexion, retour du cache (${cachedWords.length} mots)');
    return cachedWords;
  }

  

  Future<List<WordModel>> getWordsByCategory(String category, {bool forceOnline = false}) async {
    List<WordModel> cachedWords = await _getCachedWordsByCategory(category);
    
    if (cachedWords.isNotEmpty && !forceOnline) {
      return cachedWords;
    }

    if (await _isConnectedToInternet()) {
      try {
        final words = await ApiService.instance.getWordsByCategory(category);
        await _addNewWordsToCache(words);
        return words;
      } catch (e) {
        print('Erreur API catégorie: $e');
      }
    }
    
    return cachedWords;
  }

  Future<List<WordModel>> getFavoriteWords({bool forceOnline = false}) async {
    List<WordModel> cachedFavorites = await _getCachedFavoriteWords();
    
    if (await _isConnectedToInternet()) {
      try {
        final words = await ApiService.instance.getFavoriteWords();
        await _updateFavoritesCache(words);
        return words;
      } catch (e) {
        print('Erreur API favoris: $e');
      }
    }
    
    return cachedFavorites;
  }

  // === GESTION DES FAVORIS ===

  Future<bool> toggleFavorite(WordModel word) async {
  try {
    final wordId = word.id;
    if (wordId == null) {
      throw Exception('ID du mot manquant');
    }
    
    print('Toggle favori pour word ID: $wordId');
    
    final currentStatus = await isFavorite(wordId);
    final newStatus = !currentStatus;
    
    print('Statut actuel: $currentStatus, nouveau: $newStatus');
    
    // Toujours mettre à jour le cache local d'abord
    await _updateWordFavoriteInCache(wordId, newStatus);
    
    print('Cache local mis à jour');
    
    // Essayer de synchroniser avec l'API si possible
    if (await _isConnectedToInternet()) {
      try {
        // Vérifier que l'API a cette méthode
        await ApiService.instance.toggleFavorite(wordId);
        print('Favori synchronisé avec le serveur');
      } catch (e) {
        print('Erreur sync favori avec API: $e');
        // Le changement reste en cache, sera synchronisé plus tard
      }
    } else {
      print('Mode hors ligne: favori sauvé en cache uniquement');
    }
    
    return newStatus;
    
  } catch (e, stackTrace) {
    print('Erreur dans toggleFavorite: $e');
    print('Stack trace: $stackTrace');
    rethrow;
  }
}
// 4. Dans database_helper.dart - Corriger isFavorite()
// Dans database_helper.dart - Remplacer la méthode isFavorite
Future<bool> isFavorite(int wordId) async {
  try {
    final db = await database;
    final result = await db.query(
      'cached_favorites',
      where: 'server_word_id = ?',
      whereArgs: [wordId],
    );
    
    final isFav = result.isNotEmpty;
    print('Vérification favori ID $wordId: $isFav');
    return isFav;
    
  } catch (e) {
    print('Erreur vérification favori: $e');
    return false;
  }
}
  
  /// Synchronisation complète - à utiliser avec parcimonie
  Future<void> performFullSync() async {
  if (!await _isConnectedToInternet()) {
    throw Exception('Connexion internet requise pour la synchronisation');
  }
  
  try {
    print('🔄 Début de la synchronisation complète...');
    
    // 1. Récupérer tous les mots
    final words = await ApiService.instance.getWords();
    await _updateWordsCache(words);
    print('✅ ${words.length} mots synchronisés');
    
    // 2. Récupérer les favoris (avec gestion d'erreur)
    try {
      final favorites = await ApiService.instance.getFavoriteWords();
      await _updateFavoritesCache(favorites);
      print('✅ ${favorites.length} favoris synchronisés');
    } catch (e) {
      print('⚠️ Erreur favoris (non bloquant): $e');
    }
    
    // 3. Récupérer les stats (avec gestion d'erreur)
    try {
      final stats = await ApiService.instance.getStats();
      await _updateStatsCache(stats);
      print('✅ Stats synchronisées');
    } catch (e) {
      print('⚠️ Erreur stats (non bloquant): $e');
    }
    
    // 4. Marquer la synchronisation comme terminée
    await _updateSyncMetadata('last_full_sync', DateTime.now().millisecondsSinceEpoch ~/ 1000);
    
    print('✅ Synchronisation complète terminée');
  } catch (e) {
    print('❌ Erreur lors de la synchronisation: $e');
    throw e;
  }
}

  /// Synchronisation légère - vérifie seulement les nouveaux éléments
  Future<void> performLightSync() async {
    if (!await _isConnectedToInternet()) {
      return; // Ne pas lancer d'erreur pour la sync légère
    }
    
    try {
      final lastSync = await _getLastSyncTime();
      
      // Récupérer seulement les mots modifiés depuis la dernière sync
      // Note: L'API devrait supporter un paramètre 'since' pour l'optimisation
      final recentWords = await ApiService.instance.getRecentWords(lastSync);
      
      if (recentWords.isNotEmpty) {
        await _addNewWordsToCache(recentWords);
        await _updateSyncMetadata('last_light_sync', DateTime.now().millisecondsSinceEpoch ~/ 1000);
        print('📥 ${recentWords.length} nouveaux mots synchronisés');
      }
    } catch (e) {
      print('⚠️ Erreur sync légère: $e');
      // Ne pas lancer d'erreur pour permettre l'utilisation hors ligne
    }
  }

  Future<DateTime?> _getLastSyncTime() async {
    final db = await database;
    final result = await db.query(
      'sync_metadata',
      where: 'key = ?',
      whereArgs: ['last_full_sync'],
      limit: 1,
    );
    
    if (result.isNotEmpty) {
      final timestamp = int.tryParse(result.first['value'] as String);
      if (timestamp != null) {
        return DateTime.fromMillisecondsSinceEpoch(timestamp * 1000);
      }
    }
    return null;
  }

  Future<void> _updateSyncMetadata(String key, dynamic value) async {
    final db = await database;
    await db.insert(
      'sync_metadata',
      {
        'key': key,
        'value': value.toString(),
        'updated_at': DateTime.now().millisecondsSinceEpoch ~/ 1000,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  // === MÉTHODES DE CACHE PRIVÉES ===

  Future<List<WordModel>> _getCachedWords({int? limit}) async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query(
      'cached_words',
      orderBy: 'usage_frequency DESC, zarma_word ASC',
    );

    return List.generate(maps.length, (i) {
      return _wordFromCacheMap(maps[i]);
    });
  }

  Future<List<WordModel>> _searchCachedWords(String query) async {
  final db = await database;
  
  // MODIFICATION: Recherche uniquement dans zarma_word et french_meaning
  // Suppression de zarma_example et french_example
  final List<Map<String, dynamic>> maps = await db.query(
    'cached_words',
    where: 'zarma_word LIKE ? OR french_meaning LIKE ?',
    whereArgs: ['%$query%', '%$query%'],
    orderBy: 'usage_frequency DESC, zarma_word ASC',
  );

  return List.generate(maps.length, (i) {
    return _wordFromCacheMap(maps[i]);
  });
}

  Future<List<WordModel>> _getCachedWordsByCategory(String category) async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query(
      'cached_words',
      where: 'category = ?',
      whereArgs: [category],
      orderBy: 'usage_frequency DESC, zarma_word ASC',
    );

    return List.generate(maps.length, (i) {
      return _wordFromCacheMap(maps[i]);
    });
  }

  Future<List<WordModel>> _getCachedFavoriteWords() async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.rawQuery('''
      SELECT cw.* FROM cached_words cw
      INNER JOIN cached_favorites cf ON cw.server_id = cf.server_word_id
      ORDER BY cf.cached_at DESC
    ''');

    return List.generate(maps.length, (i) {
      return _wordFromCacheMap(maps[i]);
    });
  }

  // === MISE À JOUR DU CACHE ===

  /// Remplace complètement le cache des mots
  Future<void> _updateWordsCache(List<WordModel> words) async {
    final db = await database;
    
    await db.transaction((txn) async {
      await txn.delete('cached_words');
      
      for (final word in words) {
        await txn.insert('cached_words', _wordToCacheMap(word));
      }
    });
    
    print('📄 Cache mis à jour avec ${words.length} mots');
  }

  /// Ajoute de nouveaux mots au cache sans supprimer les existants
  Future<void> _addNewWordsToCache(List<WordModel> words) async {
    final db = await database;
    
    for (final word in words) {
      await db.insert(
        'cached_words',
        _wordToCacheMap(word),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    }
    
    print('📄 ${words.length} nouveaux mots ajoutés au cache');
  }

  Future<void> _updateFavoritesCache(List<WordModel> favoriteWords) async {
    final db = await database;
    
    await db.transaction((txn) async {
      await txn.delete('cached_favorites');
      
      for (final word in favoriteWords) {
        await txn.insert('cached_favorites', {
          'server_word_id': word.id,
          'cached_at': DateTime.now().millisecondsSinceEpoch ~/ 1000,
        });
      }
    });
  }

  Future<void> _updateStatsCache(AppStats stats) async {
    final db = await database;
    await db.insert(
      'cached_stats',
      {
        'id': 1,
        'total_words': stats.totalWords,
        'total_categories': stats.totalCategories,
        'avg_difficulty': stats.avgDifficulty,
        'learned_words': stats.learnedWords,
        'total_favorites': stats.totalFavorites,
        'words_this_week': stats.wordsThisWeek,
        'completion_rate': stats.completionRate,
        'cached_at': DateTime.now().millisecondsSinceEpoch ~/ 1000,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> _updateWordFavoriteInCache(int wordId, bool shouldBeFavorite) async {
  try {
    final db = await database;
    
    print('Mise à jour cache favori - ID: $wordId, shouldBeFav: $shouldBeFavorite');
    
    if (shouldBeFavorite) {
      // Ajouter aux favoris
      final result = await db.insert(
        'cached_favorites',
        {
          'server_word_id': wordId,
          'cached_at': DateTime.now().millisecondsSinceEpoch ~/ 1000,
        },
        conflictAlgorithm: ConflictAlgorithm.ignore,
      );
      print('Insert favori result: $result');
    } else {
      // Retirer des favoris
      final result = await db.delete(
        'cached_favorites',
        where: 'server_word_id = ?',
        whereArgs: [wordId],
      );
      print('Delete favori result: $result lignes supprimées');
    }
    
    // Vérifier le résultat
    final verification = await isFavorite(wordId);
    print('Vérification après mise à jour: $verification');
    
  } catch (e, stackTrace) {
    print('Erreur mise à jour cache favori: $e');
    print('Stack trace: $stackTrace');
    rethrow;
  }
}

Future<int> getFavoriteCount() async {
  try {
    final db = await database;
    final result = await db.rawQuery('SELECT COUNT(*) as count FROM cached_favorites');
    return result.first['count'] as int;
  } catch (e) {
    print('Erreur comptage favoris: $e');
    return 0;
  }
}
Future<void> debugFavorites() async {
  try {
    final db = await database;
    final favorites = await db.query('cached_favorites');
    
    print('=== DEBUG FAVORIS ===');
    print('Nombre de favoris en cache: ${favorites.length}');
    
    for (final fav in favorites) {
      print('Favori: ${fav['server_word_id']} - ${fav['cached_at']}');
    }
    
    // Afficher aussi les mots correspondants
    final favoriteWords = await _getCachedFavoriteWords();
    print('Mots favoris:');
    for (final word in favoriteWords) {
      print('  - ${word.zarmaWord} (ID: ${word.id})');
    }
    
    print('===================');
    
  } catch (e) {
    print('Erreur debug favoris: $e');
  }
}
Future<void> checkFavoritesTableStructure() async {
  try {
    final db = await database;
    final tableInfo = await db.rawQuery("PRAGMA table_info(cached_favorites)");
    
    print('=== STRUCTURE TABLE FAVORIS ===');
    for (final column in tableInfo) {
      print('Colonne: ${column['name']} - Type: ${column['type']}');
    }
    print('===============================');
    
  } catch (e) {
    print('Erreur vérification structure: $e');
  }
}


Future<void> testFavoriteSystem(WordModel testWord) async {
  try {
    print('=== TEST SYSTÈME FAVORIS ===');
    
    if (testWord.id == null) {
      print('ERREUR: Mot de test sans ID');
      return;
    }
    
    // Vérifier la structure
    await checkFavoritesTableStructure();
    
    // État initial
    bool initialStatus = await isFavorite(testWord.id!);
    print('Statut initial: $initialStatus');
    
    // Toggle 1
    bool status1 = await toggleFavorite(testWord);
    print('Après toggle 1: $status1');
    
    // Vérification
    bool verification1 = await isFavorite(testWord.id!);
    print('Vérification 1: $verification1');
    
    // Toggle 2
    bool status2 = await toggleFavorite(testWord);
    print('Après toggle 2: $status2');
    
    // Vérification finale
    bool verification2 = await isFavorite(testWord.id!);
    print('Vérification finale: $verification2');
    
    // Debug des favoris
    await debugFavorites();
    
    print('=== FIN TEST ===');
    
  } catch (e, stackTrace) {
    print('Erreur test favoris: $e');
    print('Stack trace: $stackTrace');
  }
}

  // === GESTION DES STATISTIQUES ===

  Future<AppStats> getStats({bool forceOnline = false}) async {
    AppStats cachedStats = await _getCachedStats();
    
    if (await _isConnectedToInternet()) {
      try {
        final stats = await ApiService.instance.getStats();
        await _updateStatsCache(stats);
        return stats;
      } catch (e) {
        print('Erreur API stats: $e');
      }
    }
    
    return cachedStats;
  }

  Future<AppStats> _getCachedStats() async {
    final db = await database;
    final result = await db.query('cached_stats', limit: 1);
    
    if (result.isEmpty) {
      // Calculer les stats à partir du cache local
      final wordsCount = await db.rawQuery('SELECT COUNT(*) as count FROM cached_words');
      final favoritesCount = await db.rawQuery('SELECT COUNT(*) as count FROM cached_favorites');
      
      return AppStats(
        totalWords: wordsCount.first['count'] as int,
        totalCategories: 0, // À calculer si nécessaire
        avgDifficulty: 0.0,
        learnedWords: 0,
        totalFavorites: favoritesCount.first['count'] as int,
        wordsThisWeek: 0,
        completionRate: 0,
      );
    }
    
    final data = result.first;
    return AppStats(
      totalWords: data['total_words'] as int,
      totalCategories: data['total_categories'] as int,
      avgDifficulty: (data['avg_difficulty'] as num).toDouble(),
      learnedWords: data['learned_words'] as int,
      totalFavorites: data['total_favorites'] as int,
      wordsThisWeek: data['words_this_week'] as int,
      completionRate: data['completion_rate'] as int,
    );
  }
Future<void> _upgradeDatabase(Database db, int oldVersion, int newVersion) async {
  if (oldVersion < 3) {
    // Vérifier si la colonne updated_at existe déjà 
    final tableInfo = await db.rawQuery("PRAGMA table_info(cached_words)");
    final columnNames = tableInfo.map((row) => row['name'] as String).toList();
    
    // Ajouter updated_at seulement si elle n'existe pas
    if (!columnNames.contains('updated_at')) {
      await db.execute('ALTER TABLE cached_words ADD COLUMN updated_at INTEGER DEFAULT 0');
    }
    
    // Ajouter needs_sync seulement si elle n'existe pas
    if (!columnNames.contains('needs_sync')) {
      await db.execute('ALTER TABLE cached_words ADD COLUMN needs_sync BOOLEAN DEFAULT FALSE');
    }
    
    // Créer la table sync_metadata si elle n'existe pas
    await db.execute('''
      CREATE TABLE IF NOT EXISTS sync_metadata(
        key TEXT PRIMARY KEY,
        value TEXT,
        updated_at INTEGER DEFAULT (strftime('%s', 'now'))
      )
    ''');
  }
  
  if (oldVersion < 4) {
    // AJOUT DE LA TABLE SEARCH_HISTORY
    await db.execute('''
      CREATE TABLE IF NOT EXISTS search_history(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        query TEXT NOT NULL,
        search_count INTEGER DEFAULT 1,
        last_searched INTEGER DEFAULT (strftime('%s', 'now')),
        results_count INTEGER DEFAULT 0,
        created_at INTEGER DEFAULT (strftime('%s', 'now'))
      )
    ''');
    
    // Ajouter les index pour les performances
    await db.execute('CREATE INDEX IF NOT EXISTS idx_search_history_query ON search_history(query)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_search_history_last_searched ON search_history(last_searched DESC)');
    
    print('✅ Table search_history créée avec succès');
  }
}

Future<void> addToSearchHistory(String query, int resultsCount) async {
  if (query.trim().isEmpty || query.length < 2) return;
  
  try {
    final db = await database;
    final normalizedQuery = query.trim().toLowerCase();
    
    // Vérifier si la recherche existe déjà (insensible à la casse)
    final existing = await db.query(
      'search_history',
      where: 'LOWER(query) = ?',
      whereArgs: [normalizedQuery],
      limit: 1,
    );
    
    final currentTime = DateTime.now().millisecondsSinceEpoch ~/ 1000;
    
    if (existing.isNotEmpty) {
      // Mettre à jour l'entrée existante
      await db.update(
        'search_history',
        {
          'search_count': (existing.first['search_count'] as int) + 1,
          'last_searched': currentTime,
          'results_count': resultsCount,
        },
        where: 'id = ?',
        whereArgs: [existing.first['id']],
      );
      print('🔄 Historique mis à jour: $query (${existing.first['search_count'] as int }x)');
    } else {
      // Créer une nouvelle entrée
      await db.insert('search_history', {
        'query': query.trim(),
        'search_count': 1,
        'last_searched': currentTime,
        'results_count': resultsCount,
        'created_at': currentTime,
      });
      print('➕ Nouvelle entrée historique: $query');
    }
    
    // Limiter l'historique à 100 entrées max
    await _cleanupSearchHistory();
    
  } catch (e) {
    print('❌ Erreur ajout historique: $e');
    // Ne pas lancer d'erreur pour ne pas bloquer la recherche
  }
}

Future<void> _cleanupSearchHistory() async {
  try {
    final db = await database;
    
    // Compter le nombre total d'entrées
    final countResult = await db.rawQuery('SELECT COUNT(*) as count FROM search_history');
    final totalCount = countResult.first['count'] as int;
    
    if (totalCount > 100) {
      // Supprimer les plus anciennes
      final deletedCount = totalCount - 100;
      await db.execute('''
        DELETE FROM search_history 
        WHERE id NOT IN (
          SELECT id FROM search_history 
          ORDER BY last_searched DESC 
          LIMIT 100
        )
      ''');
      print('🧹 Nettoyage historique: $deletedCount entrées supprimées');
    }
  } catch (e) {
    print('❌ Erreur nettoyage historique: $e');
  }
}

/// Récupérer l'historique de recherche
Future<List<SearchHistoryItem>> getSearchHistory({int limit = 20}) async {
  try {
    final db = await database;
    
    final List<Map<String, dynamic>> maps = await db.query(
      'search_history',
      orderBy: 'last_searched DESC',
      limit: limit,
    );
    
    return maps.map((map) => SearchHistoryItem.fromMap(map)).toList();
  } catch (e) {
    print('❌ Erreur récupération historique: $e');
    return [];
  }
}

/// Supprimer une entrée de l'historique
Future<void> removeFromSearchHistory(int id) async {
  try {
    final db = await database;
    final deletedRows = await db.delete(
      'search_history',
      where: 'id = ?',
      whereArgs: [id],
    );
    
    if (deletedRows > 0) {
      print('🗑️ Entrée historique supprimée: ID $id');
    }
  } catch (e) {
    print('❌ Erreur suppression historique: $e');
    throw e;
  }
}

/// Vider tout l'historique de recherche
Future<void> clearSearchHistory() async {
  try {
    final db = await database;
    final deletedRows = await db.delete('search_history');
    print('🗑️ Historique vidé: $deletedRows entrées supprimées');
  } catch (e) {
    print('❌ Erreur vidage historique: $e');
    throw e;
  }
}


/// Rechercher dans l'historique
Future<List<SearchHistoryItem>> searchInHistory(String query) async {
  if (query.trim().isEmpty) return [];
  
  try {
    final db = await database;
    
    final List<Map<String, dynamic>> maps = await db.query(
      'search_history',
      where: 'query LIKE ?',
      whereArgs: ['%${query.trim()}%'],
      orderBy: 'search_count DESC, last_searched DESC',
      limit: 10,
    );
    
    return maps.map((map) => SearchHistoryItem.fromMap(map)).toList();
  } catch (e) {
    print('❌ Erreur recherche dans historique: $e');
    return [];
  }
}

/// Obtenir les recherches populaires
Future<List<SearchHistoryItem>> getPopularSearches({int limit = 10}) async {
  try {
    final db = await database;
    
    final List<Map<String, dynamic>> maps = await db.query(
      'search_history',
      where: 'search_count > 1',
      orderBy: 'search_count DESC, last_searched DESC',
      limit: limit,
    );
    
    return maps.map((map) => SearchHistoryItem.fromMap(map)).toList();
  } catch (e) {
    print('❌ Erreur recherches populaires: $e');
    return [];
  }
}

/// Obtenir les statistiques de l'historique
Future<Map<String, dynamic>> getSearchHistoryStats() async {
  try {
    final db = await database;
    
    // Nombre total de recherches
    final countResult = await db.rawQuery('SELECT COUNT(*) as count FROM search_history');
    final totalSearches = countResult.first['count'] as int;
    
    // Nombre total de requêtes uniques
    final uniqueResult = await db.rawQuery('SELECT COUNT(DISTINCT query) as count FROM search_history');
    final uniqueSearches = uniqueResult.first['count'] as int;
    
    // Recherche la plus populaire
    final popularResult = await db.query(
      'search_history',
      orderBy: 'search_count DESC',
      limit: 1,
    );
    
    // Moyenne des résultats par recherche
    final avgResult = await db.rawQuery('SELECT AVG(results_count) as avg FROM search_history');
    final avgResults = (avgResult.first['avg'] as double?) ?? 0.0;
    
    return {
      'total_searches': totalSearches,
      'unique_searches': uniqueSearches,
      'most_popular_query': popularResult.isNotEmpty ? popularResult.first['query'] : null,
      'most_popular_count': popularResult.isNotEmpty ? popularResult.first['search_count'] : 0,
      'avg_results_per_search': avgResults.round(),
    };
  } catch (e) {
    print('❌ Erreur stats historique: $e');
    return {};
  }
}

// ==================== MODIFICATION DE LA MÉTHODE searchWords ====================

Future<List<WordModel>> searchWords(String query, {bool forceOnline = false}) async {
  if (query.trim().isEmpty) return [];
  
  List<WordModel> results = [];
  
  try {
    // Rechercher dans le cache d'abord
    results = await _searchCachedWords(query);
    
    // Si pas de résultats en cache et connexion disponible, essayer l'API
    if (results.isEmpty && !forceOnline && await _isConnectedToInternet()) {
      try {
        results = await ApiService.instance.searchWords(query);
        // Ajouter les nouveaux mots au cache s'ils n'y sont pas déjà 
        await _addNewWordsToCache(results);
      } catch (e) {
        print('Erreur de recherche API: $e');
      }
    }
    
    print('🔍 Recherche "$query": ${results.length} résultats trouvés');
    
  } catch (e) {
    print('❌ Erreur recherche: $e');
    // En cas d'erreur, on continue avec une liste vide
  }
  
  // Ajouter à l'historique de recherche (même si 0 résultat)
  try {
    await addToSearchHistory(query, results.length);
  } catch (e) {
    print('❌ Erreur ajout historique (non bloquant): $e');
  }
  
  return results;
}

// ==================== MÉTHODES DE DEBUG POUR L'HISTORIQUE ====================

Future<void> debugSearchHistory() async {
  try {
    print('=== DEBUG HISTORIQUE DE RECHERCHE ===');
    
    final db = await database;
    
    // Vérifier si la table existe
    final tables = await db.rawQuery(
      "SELECT name FROM sqlite_master WHERE type='table' AND name='search_history'"
    );
    
    if (tables.isEmpty) {
      print('❌ Table search_history n\'existe pas');
      return;
    }
    
    print('✅ Table search_history existe');
    
    // Structure de la table
    final tableInfo = await db.rawQuery("PRAGMA table_info(search_history)");
    print('Structure de la table:');
    for (final column in tableInfo) {
      print('  ${column['name']}: ${column['type']}');
    }
    
    // Contenu de la table
    final history = await getSearchHistory(limit: 50);
    print('Nombre d\'entrées: ${history.length}');
    
    for (final item in history.take(5)) {
      print('  "${item.query}" - ${item.searchCount}x - ${item.resultsCount} résultats - ${item.timeAgo}');
    }
    
    // Statistiques
    final stats = await getSearchHistoryStats();
    print('Statistiques:');
    stats.forEach((key, value) {
      print('  $key: $value');
    });
    
    print('=====================================');
    
  } catch (e) {
    print('❌ Erreur debug historique: $e');
  }
}

  Future<List<CategoryStats>> getCategories({bool forceOnline = false}) async {
    if (await _isConnectedToInternet()) {
      try {
        final categories = await ApiService.instance.getCategories();
        return categories;
      } catch (e) {
        print('Erreur API catégories: $e');
      }
    }
    
    // Calculer les catégories à partir du cache
    return await getCachedCategories();
  }

  Future<List<CategoryStats>> getCachedCategories() async {
  final db = await database;
  
  final result = await db.rawQuery('''
    SELECT 
      category,
      COUNT(*) as word_count,
      AVG(difficulty_level) as avg_difficulty,
      COUNT(CASE WHEN is_learned = 1 THEN 1 END) as learned_count
    FROM cached_words 
    WHERE category IS NOT NULL AND category != ''
    GROUP BY category
    ORDER BY word_count DESC
  ''');

  return result.map((row) {
    final wordCount = row['word_count'] as int;
    final learnedCount = row['learned_count'] as int;
    final progressPercentage = wordCount > 0 ? ((learnedCount / wordCount) * 100).round() : 0;
    
    return CategoryStats(
      name: row['category'] as String,
      wordCount: wordCount,
      avgDifficulty: (row['avg_difficulty'] as double?) ?? 0.0,
      learnedCount: learnedCount,
      progressPercentage: progressPercentage,
    );
  }).toList();
}

  // === CONVERSION ET UTILITAIRES ===

  // Remplacez votre méthode _wordFromCacheMap dans database_helper.dart

WordModel _wordFromCacheMap(Map<String, dynamic> map) {
  // Fonctions utilitaires pour la conversion sécurisée des types
  int safeInt(dynamic value) {
    if (value == null) return 0;
    if (value is int) return value;
    if (value is double) return value.toInt();
    if (value is String) return int.tryParse(value) ?? 0;
    if (value is bool) return value ? 1 : 0;
    return 0;
  }

  String safeString(dynamic value) {
    if (value == null) return '';
    if (value is String) return value;
    return value.toString();
  }

  bool safeBool(dynamic value) {
    if (value == null) return false;
    if (value is bool) return value;
    if (value is int) return value != 0;
    if (value is String) {
      return value.toLowerCase() == 'true' || value == '1';
    }
    return false;
  }

  // CORRECTION: Fonction pour convertir string séparée par | en List<String>
  List<String> safeStringList(dynamic value) {
    if (value == null) return [];
    if (value is String) {
      if (value.isEmpty) return [];
      return value.split('|').where((item) => item.trim().isNotEmpty).toList();
    }
    if (value is List) {
      return value.whereType<String>().where((item) => item.trim().isNotEmpty).toList();
    }
    return [];
  }

  return WordModel(
    id: safeInt(map['server_id']),
    zarmaWord: safeString(map['zarma_word']),
    zarmaExample: safeString(map['zarma_example']),
    frenchMeaning: safeString(map['french_meaning']),
    frenchExample: safeString(map['french_example']),
    category: safeString(map['category']),
    pronunciation: safeString(map['pronunciation']),
    difficultyLevel: safeInt(map['difficulty_level']),
    etymology: safeString(map['etymology']),
    // CORRECTION: Conversion sécurisée des chaînes en listes
    synonyms: safeStringList(map['synonyms']),
    antonyms: safeStringList(map['antonyms']),
    relatedWords: safeStringList(map['related_words']),
    usageFrequency: safeInt(map['usage_frequency']),
    audioPath: safeString(map['audio_path']),
    imagePath: safeString(map['image_path']),
    isFavorite: safeBool(map['is_favorite']),
    isLearned: safeBool(map['is_learned']),
    viewCount: safeInt(map['view_count']),
    practiceCount: safeInt(map['practice_count']),
  );
}

Future<void> debugWordInsertion(WordModel word) async {
  print('=== DEBUG INSERTION WORD ===');
  print('Word ID: ${word.id}');
  print('Zarma Word: ${word.zarmaWord}');
  print('Synonyms (List): ${word.synonyms}');
  print('Antonyms (List): ${word.antonyms}');
  print('Related Words (List): ${word.relatedWords}');
  
  // Test de conversion
  final cacheMap = _wordToCacheMap(word);
  print('Synonyms (String): ${cacheMap['synonyms']}');
  print('Antonyms (String): ${cacheMap['antonyms']}');
  print('Related Words (String): ${cacheMap['related_words']}');
  
  // Test de reconversion
  final convertedWord = _wordFromCacheMap(cacheMap);
  print('Reconverted Synonyms: ${convertedWord.synonyms}');
  print('Reconverted Antonyms: ${convertedWord.antonyms}');
  print('Reconverted Related: ${convertedWord.relatedWords}');
  print('============================');
}
// Aussi, corrigez votre méthode _wordToCacheMap pour éviter ce problème :

Map<String, dynamic> _wordToCacheMap(WordModel word) {
  // Fonction pour convertir List<String> en String séparée par |
  String listToString(List<String>? list) {
    if (list == null || list.isEmpty) return '';
    return list.join('|');
  }

  return {
    'server_id': word.id,
    'zarma_word': word.zarmaWord ?? '',
    'zarma_example': word.zarmaExample ?? '',
    'french_meaning': word.frenchMeaning ?? '',
    'french_example': word.frenchExample ?? '',
    'category': word.category ?? '',
    'pronunciation': word.pronunciation ?? '',
    'difficulty_level': word.difficultyLevel ?? 1,
    'etymology': word.etymology ?? '',
    // CORRECTION: Convertir les listes en chaînes
    'synonyms': listToString(word.synonyms),
    'antonyms': listToString(word.antonyms),
    'related_words': listToString(word.relatedWords),
    'usage_frequency': word.usageFrequency ?? 0,
    'audio_path': word.audioPath ?? '',
    'image_path': word.imagePath ?? '',
    'is_favorite': false,
    'is_learned': false,
    'view_count': 0,
    'practice_count': 0,
    'cached_at': DateTime.now().millisecondsSinceEpoch ~/ 1000,
    'updated_at': DateTime.now().millisecondsSinceEpoch ~/ 1000,
    'needs_sync': false,
  };
}


  Future<bool> _isConnectedToInternet() async {
  try {
    // 1. Vérifier la connectivité locale
    final connectivityResult = await Connectivity().checkConnectivity();
    if (connectivityResult == ConnectivityResult.none) {
      print('Pas de connectivité réseau');
      return false;
    }
    
    // 2. Tester avec un timeout court - CORRIGÉ
    final canConnect = await ApiService.instance.testConnection().timeout(
      Duration(seconds: 10),
      onTimeout: () => false,
    );
    
    print('Test de connexion API: ${canConnect ? 'OK' : 'KO'}');
    return canConnect;
    
  } catch (e) {
    print('Erreur test connexion: $e');
    return false;
  }
}


  // === MAINTENANCE DU CACHE ===

  Future<void> clearCache() async {
    final db = await database;
    await db.transaction((txn) async {
      await txn.delete('cached_words');
      await txn.delete('cached_stats');
      await txn.delete('cached_favorites');
      await txn.delete('sync_metadata');
    });
    print('🗑️ Cache vidé complètement');
  }

  Future<Map<String, dynamic>> getCacheInfo() async {
    final db = await database;
    
    final wordsCount = await db.rawQuery('SELECT COUNT(*) as count FROM cached_words');
    final favoritesCount = await db.rawQuery('SELECT COUNT(*) as count FROM cached_favorites');
    
    final latestWord = await db.query(
      'cached_words', 
      columns: ['cached_at'], 
      orderBy: 'cached_at DESC', 
      limit: 1
    );

    final lastSync = await _getLastSyncTime();
    
    return {
      'words_cached': wordsCount.first['count'],
      'favorites_cached': favoritesCount.first['count'],
      'last_cache_update': latestWord.isNotEmpty ? latestWord.first['cached_at'] : null,
      'last_sync': lastSync?.millisecondsSinceEpoch,
      'is_online': await _isConnectedToInternet(),
      'cache_size': await _getCacheSize(),
    };
  }

  Future<String> _getCacheSize() async {
    try {
      String databasesPath = await getDatabasesPath();
      String path = join(databasesPath, 'cache_dictionary.db');
      final file = File(path);
      
      if (await file.exists()) {
        final sizeInBytes = await file.length();
        final sizeInMB = sizeInBytes / (1024 * 1024);
        return '${sizeInMB.toStringAsFixed(2)} MB';
      }
    } catch (e) {
      print('Erreur calcul taille cache: $e');
    }
    return 'Inconnu';
  }

  /// Alias pour la compatibilité avec l'ancien code
  Future<void> refreshCache() async {
    await performFullSync();
  }

  Future<String> getConnectionStatus() async {
    final isOnline = await _isConnectedToInternet();
    final cacheInfo = await getCacheInfo();
    
    if (isOnline) {
      return 'En ligne - ${cacheInfo['words_cached']} mots en cache';
    } else {
      return 'Hors ligne - ${cacheInfo['words_cached']} mots disponibles';
    }
  }

  Future<List<WordModel>> getUnsyncedWords() async {
    // Pour une base centralisée, simuler les mots non synchronisés
    // En réalité, on pourrait vérifier les mots ajoutés/modifiés localement
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query(
      'cached_words',
      where: 'needs_sync = ? OR updated_at < cached_at',
      whereArgs: [1],
      orderBy: 'cached_at DESC',
      limit: 50,
    );

    return List.generate(maps.length, (i) {
      return _wordFromCacheMap(maps[i]);
    });
  }

  Future<void> resetSyncStatus() async {
    final db = await database;
    await db.update(
      'cached_words',
      {
        'needs_sync': 0,
        'updated_at': DateTime.now().millisecondsSinceEpoch ~/ 1000,
      },
    );
    
    // Mettre à jour les métadonnées de sync
    await _updateSyncMetadata('last_full_sync', DateTime.now().millisecondsSinceEpoch ~/ 1000);
  }

  /// Vérifie si l'application peut fonctionner (au moins quelques mots en cache)
  Future<bool> canOperate() async {
    final wordsCount = await _getCachedWordsCount();
    return wordsCount > 0;
  }

  /// Vérifie si une synchronisation initiale est nécessaire
  Future<bool> needsInitialSync() async {
    final wordsCount = await _getCachedWordsCount();
    final isOnline = await _isConnectedToInternet();
    return wordsCount == 0 && isOnline;
  }

  /// Méthode pour initialiser l'application au premier démarrage
 Future<void> initializeApp() async {
  try {
    print('🔧 Initialisation de la base de données...');
    
    // S'assurer que la base est initialisée
    final db = await database;
    print('✅ Base de données initialisée');
    
    // Vérifier si on a des données en cache
    final cachedWordsCount = await _getCachedWordsCount();
    print('📦 Mots en cache: $cachedWordsCount');
    
    // Vérifier la connexion
    final isConnected = await _isConnectedToInternet();
    print('🌐 Connexion internet: $isConnected');
    
    if (cachedWordsCount == 0 && !isConnected) {
      throw Exception(
        'Première utilisation impossible sans connexion internet.\n'
        'Connectez-vous à Internet pour télécharger les données initiales.'
      );
    }
    
    if (cachedWordsCount == 0 && isConnected) {
      print('🔄 Première synchronisation nécessaire...');
      
      // Sync initiale avec timeout et retry
      await _performInitialSyncWithRetry();
      
      final newCount = await _getCachedWordsCount();
      if (newCount == 0) {
        throw Exception('Synchronisation initiale échouée: aucune donnée récupérée');
      }
      
      print('✅ $newCount mots synchronisés lors de l\'initialisation');
    } else {
      print('✅ Application opérationnelle avec $cachedWordsCount mots en cache');
      
      // Sync légère en arrière-plan si connecté
      if (isConnected) {
        _performLightSyncInBackground();
      }
    }
    
  } catch (e, stackTrace) {
    print('❌ Erreur dans initializeApp: $e');
    print('Stack trace: $stackTrace');
    
    // Tentative de récupération
    final cachedCount = await _getCachedWordsCount();
    if (cachedCount > 0) {
      print('🛟 Récupération: ${cachedCount} mots disponibles en cache');
      return; // Continuer avec le cache
    }
    
    rethrow; // Re-lancer l'erreur si pas de récupération possible
  }
}

// Nouvelle méthode pour la sync initiale avec retry
Future<void> _performInitialSyncWithRetry({int maxRetries = 3}) async {
  int retryCount = 0;
  
  while (retryCount <= maxRetries) {
    try {
      // Tenter de récupérer les mots avec timeout - CORRIGÉ
      final words = await ApiService.instance.getWords().timeout(
        Duration(seconds: 30),
        onTimeout: () {
          throw TimeoutException('Timeout de synchronisation initiale', Duration(seconds: 30));
        },
      );
      
      if (words.isEmpty) {
        throw Exception('Aucun mot récupéré du serveur');
      }
      
      await _updateWordsCache(words);
      await _updateSyncMetadata('last_full_sync', DateTime.now().millisecondsSinceEpoch ~/ 1000);
      
      print('✅ Synchronisation initiale réussie: ${words.length} mots');
      return; // Succès
      
    } on TimeoutException catch (e) {
      retryCount++;
      print('⏱️ Timeout sync initiale (tentative $retryCount): $e');
      
      if (retryCount > maxRetries) {
        throw Exception('Timeout: le serveur met trop de temps à répondre');
      }
      
    } catch (e) {
      retryCount++;
      print('❌ Erreur sync initiale (tentative $retryCount): $e');
      
      if (retryCount > maxRetries) {
        throw Exception('Synchronisation échouée après $maxRetries tentatives: $e');
      }
    }
    
    // Attendre avant de réessayer (backoff exponentiel)
    final delaySeconds = 2 * retryCount;
    print('⏳ Attente de ${delaySeconds}s avant nouvelle tentative...');
    await Future.delayed(Duration(seconds: delaySeconds));
  }
}

// Sync légère en arrière-plan (sans bloquer)
void _performLightSyncInBackground() {
  Future.microtask(() async {
    try {
      await performLightSync();
      print('🔄 Sync légère en arrière-plan réussie');
    } catch (e) {
      print('⚠️ Sync légère en arrière-plan échouée: $e');
      // Ne pas remonter l'erreur
    }
  });
}
  }
